# ChaloShopping – React Native (Expo) Shopping App

"Apni Pasand, Apne Budget Mein!"

## How to run

This project uses **Expo SDK 57**, compatible with Expo Go 57.

```bash
npm install
npx expo install react react-native @react-navigation/native @react-navigation/native-stack @react-navigation/bottom-tabs react-native-screens react-native-safe-area-context @react-native-async-storage/async-storage expo-audio expo-status-bar @expo-google-fonts/lilita-one expo-font @expo/vector-icons
npm install react-native-confetti-cannon
npx expo start
```

Scan the QR code with the **Expo Go** app on your phone. Your phone and computer should be on the same Wi-Fi network.

## Adding your logo

The logo space is left **empty on purpose** (round white frame with a pink border, already styled).
1. Put your file at `assets/logo.png`
2. In `src/components/AppLogo.js` change `const LOGO_IMAGE = null;` to
   `const LOGO_IMAGE = require('../../assets/logo.png');`

It then appears in the toolbar, splash and login screens.

## Folder structure

```
App.js                         navigation (stack + bottom tabs) and providers
assets/                        put logo.png here
src/
  theme/ThemeContext.js        dark mode, text size, sound setting
  context/AppContext.js        login, cart, wishlist, orders, budget (AsyncStorage)
  data/products.js             clothes + accessories data and pictures
  utils/api.js                 fakestoreapi.com download (Makeup + Trending)
  utils/pricing.js             20% discount rule + price formatting
  utils/sound.js               short sound effects
  components/                  Header, SideMenu, ProductCard, SafeImage, AppLogo ...
  screens/                     ONE FOLDER PER SCREEN
    Splash/  Home/  Categories/  Clothes/  Accessories/  Makeup/
    ProductList/  ProductDetails/  Login/  Cart/  Checkout/
    OrderSuccess/  Wishlist/  Profile/  MyOrders/  ChaloSmart/
```
Every feature has a short comment above it explaining what it does.

## What each screen does

- **Splash** – logo space, name and "20% OFF — Limited Stock!", opens Home after 2.5 seconds.
- **Home** – toolbar with search, dark-mode toggle, wish list and cart badge; category circles, hero card, moving Rs. 1,200 offer banner, Trending Now (from the API), Best Deals.
- **Categories** (tab) – Men's / Women's sections, MakeUp and ChaloSmart.
- **Clothes / Accessories** – Men / Women tabs, then Stitched / Unstitched or Purses/Wallets, Watches, Jewellery, Purses.
- **Makeup** – loads `fakestoreapi.com/products` with `useEffect` + `async/await`; loading, retry and pull-to-refresh.
- **Product list** – search, sort by price, sub category chips.
- **Product details** – picture, price, rating, description, size (clothes), quantity, Add to Cart / Shop Now.
- **Login / Sign up** – validated email + password, saved in AsyncStorage. Appears only when needed (Add to Cart, Cart, My Orders) and the product is added automatically after login.
- **Cart** – quantity up/down, remove, totals, saved between restarts.
- **Checkout** – delivery details, payment choice, subtotal, 20% discount only above Rs. 1,200, final amount (Rs. 1,500 → Rs. 300 off → Rs. 1,200). Place Order saves the order.
- **My Orders** – every order placed by the logged in user.
- **Wish List / Profile** – hearts, settings (dark mode, sound, text size), log out.
- **ChaloSmart** – budget mode: only products that fit your budget.

## Things to know

- **Pictures** come from the web (Unsplash first, then a keyword photo from loremflickr.com). If a picture cannot load, an icon is shown instead of a broken box. To use your own picture, put its link at the front of that product's `images` list in `src/data/products.js`.
- **Makeup**: the API has no makeup items, so the full API list is shown.
- **Prices**: API prices are multiplied by 10 (`src/utils/api.js`) so they look like rupees next to the Rs. 1,200 rule.
- Accounts are stored on the phone in plain text – fine for a demo, not for production.
- **Sounds**: placeholder URLs in `src/utils/sound.js`. Use local files from `assets/sounds` for offline use.
