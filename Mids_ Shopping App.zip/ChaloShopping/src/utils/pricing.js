// pricing.js
// Small helper functions for prices, the 20% discount rule and formatting.

export const DISCOUNT_LIMIT = 1200; // discount applies when subtotal is MORE than this
export const DISCOUNT_RATE = 0.2;   // 20%

// 1500 -> "Rs. 1,500"
export const formatPrice = (n) =>
  'Rs. ' + Math.round(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');

// Works out subtotal, discount and final amount for a list of cart items
export function calcTotals(items) {
  const subtotal = items.reduce((sum, i) => sum + i.price * i.qty, 0);
  const discount = subtotal > DISCOUNT_LIMIT ? subtotal * DISCOUNT_RATE : 0;
  return { subtotal, discount, total: subtotal - discount };
}
