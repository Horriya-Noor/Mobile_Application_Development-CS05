// api.js
// Talks to https://fakestoreapi.com/products (used by Makeup and Home > Trending Now).
// The answer is kept in memory after the first download so both screens share it.

const API_URL = 'https://fakestoreapi.com/products';

// API prices are small dollar amounts, so multiply to get believable Rs. prices
// that sit next to the Rs. 1,200 discount rule.
const PRICE_MULTIPLIER = 10;

let cache = null;

// capital letter for the first word: "men's clothing" -> "Men's clothing"
const nice = (text) => text.charAt(0).toUpperCase() + text.slice(1);

// Downloads the list (or returns the saved copy). Throws an error if the network fails.
export async function fetchApiProducts(force = false) {
  if (cache && !force) return cache;

  const response = await fetch(API_URL);
  if (!response.ok) throw new Error('Server error ' + response.status);
  const data = await response.json();

  // convert API data into the same shape as our local products
  cache = data.map((p) => ({
    id: 'api' + p.id,
    category: 'makeup',
    gender: 'female',
    sub: p.category,
    name: p.title,
    price: Math.round(p.price * PRICE_MULTIPLIER),
    images: [p.image],
    image: p.image,
    description: p.description,
    brand: nice(p.category),
    rating: p.rating ? p.rating.rate : 4,
    ratingCount: p.rating ? p.rating.count : 0,
    contain: true, // API pictures have a plain background, show them fully on white
  }));
  return cache;
}
export async function fetchMakeupProducts() {
  const response = await fetch(
    'https://dummyjson.com/products/category/beauty'
  );

  if (!response.ok) {
    throw new Error('Failed to fetch makeup products');
  }

  const data = await response.json();

  return data.products.map((product) => ({
    id: String(product.id),

    // Product title
    title: product.title,
    name: product.title,
    price: product.price,
    image: product.thumbnail,
    description: product.description,
    category: 'makeup',
    sub: product.brand || 'Beauty',
    rating: product.rating?.rate || 0,
  }));
}