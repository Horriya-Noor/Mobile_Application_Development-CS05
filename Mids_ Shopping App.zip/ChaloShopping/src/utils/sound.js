// sound.js
// Fast reusable sound effects for ChaloShopping

import { createAudioPlayer, preload } from 'expo-audio';

const SOUNDS = {
  add: 'https://actions.google.com/sounds/v1/cartoon/pop.ogg',

  success:
    'https://actions.google.com/sounds/v1/cartoon/cartoon_success_fanfair.ogg',
};

// Preload sounds
Object.entries(SOUNDS).forEach(([name, sound]) => {
  preload(sound).catch((error) => {
    console.warn(`Could not preload ${name} sound:`, error);
  });
});

// Create players once
const players = {};

Object.entries(SOUNDS).forEach(([name, url]) => {
  try {
    players[name] = createAudioPlayer({
      uri: url,
    });
  } catch (error) {
    console.warn(`Could not create ${name} player:`, error);
  }
});

export function playSound(name) {
  try {
    const player = players[name];

    if (!player) {
      console.warn(`Sound "${name}" not found.`);
      return;
    }

    player.seekTo(0);
    player.play();
  } catch (error) {
    console.warn(`Could not play "${name}" sound:`, error);
  }
}