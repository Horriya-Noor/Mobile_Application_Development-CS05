// ThemeContext.js
// Handles DARK MODE and adjustable TEXT SIZE for the whole app.
// Both settings are saved in AsyncStorage so they survive app restarts.

import React, { createContext, useContext, useEffect, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

// Colour palettes taken from the Figma design (pink theme)
const lightColors = {
  bg: '#FFDDE0',        // page background (soft pink)
  card: '#FFFFFF',      // product cards
  primary: '#FF4D6D',   // header / bottom bar / buttons
  primaryText: '#FFFFFF',
  text: '#1F1F1F',
  subText: '#6B6B6B',
  green: '#0B6B3A',     // prices, "Add to cart"
  inputBg: '#FFE9EB',
  border: '#1F1F1F',
  chip: '#FF8FA3',
  banner: '#FFF200',    // yellow offer banner
  bannerText: '#1F1F1F',
};

const darkColors = {
  bg: '#1B1215',
  card: '#2A1C21',
  primary: '#D63A58',
  primaryText: '#FFFFFF',
  text: '#F5E9EC',
  subText: '#B9A5AB',
  green: '#4ADE80',
  inputBg: '#33232A',
  border: '#F5E9EC',
  chip: '#8E3347',
  banner: '#5A4A00',
  bannerText: '#FFF6B0',
};

// Decorative font used for big headings like "Womens' Section"
// (loaded in App.js from @expo-google-fonts/lilita-one)
export const HEADING_FONT = 'LilitaOne_400Regular';

const ThemeContext = createContext();

export function ThemeProvider({ children }) {
  const [dark, setDark] = useState(false);
  const [scale, setScale] = useState(1); // 1 = normal text size
  const [soundOn, setSoundOn] = useState(true); // sound effects on/off

  // Load saved settings once when the app starts
  useEffect(() => {
    (async () => {
      const saved = await AsyncStorage.getItem('settings');
      if (saved) {
        const s = JSON.parse(saved);
        setDark(!!s.dark);
        setScale(s.scale || 1);
        if (s.soundOn === false) setSoundOn(false);
      }
    })();
  }, []);

  // Save whenever settings change
  useEffect(() => {
    AsyncStorage.setItem('settings', JSON.stringify({ dark, scale, soundOn }));
  }, [dark, scale, soundOn]);

  // fs(14) -> font size 14 multiplied by the user's chosen text scale
  const fs = (size) => Math.round(size * scale);

  const value = {
    dark,
    toggleDark: () => setDark((d) => !d),
    scale,
    setScale,
    soundOn,
    toggleSound: () => setSoundOn((s) => !s),
    fs,
    colors: dark ? darkColors : lightColors,
  };

  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
}

// Small hook so every screen can write: const { colors, fs } = useTheme();
export const useTheme = () => useContext(ThemeContext);
