// AppContext.js
// Shared app state: logged in user, cart, wishlist, orders, budget and the small
// "Added to Cart" notification. Everything important is saved in AsyncStorage,
// so it is still there after the app is closed and opened again.

import React, { createContext, useContext, useEffect, useRef, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { playSound } from '../utils/sound';
import { calcTotals } from '../utils/pricing';
import { useTheme } from '../theme/ThemeContext';

const AppContext = createContext();

// reads JSON from storage, returns fallback if nothing is saved
const read = async (key, fallback) => {
  try {
    const value = await AsyncStorage.getItem(key);
    return value ? JSON.parse(value) : fallback;
  } catch (e) {
    return fallback;
  }
};

// one cart line is identified by product + size (same shirt in M and L = two lines)
const lineKey = (id, size) => `${id}|${size || ''}`;

export function AppProvider({ children }) {
  const { soundOn } = useTheme();

  const [loading, setLoading] = useState(true); // true until saved data is loaded
  const [user, setUser] = useState(null);
  const [cart, setCart] = useState([]);
  const [wishlist, setWishlist] = useState([]);
  const [orders, setOrders] = useState([]);
  const [budget, setBudgetState] = useState(0);
  const [toast, setToast] = useState('');
  const toastTimer = useRef(null);
  const pendingRef = useRef(null); // what to do right after the user logs in

  // ----- load everything saved from the last time the app was used -----
  useEffect(() => {
    (async () => {
      setUser(await read('session', null));
      const savedCart = await read('cart', []);
      // older saved items may not have a key yet
      setCart(savedCart.map((i) => ({ ...i, key: i.key || lineKey(i.id, i.size) })));
      setWishlist(await read('wishlist', []));
      setOrders(await read('orders', []));
      setBudgetState(await read('budget', 0));
      setLoading(false);
    })();
  }, []);

  // ----- save cart and wishlist whenever they change -----
  useEffect(() => {
    if (!loading) AsyncStorage.setItem('cart', JSON.stringify(cart));
  }, [cart, loading]);

  useEffect(() => {
    if (!loading) AsyncStorage.setItem('wishlist', JSON.stringify(wishlist));
  }, [wishlist, loading]);

  // ----- small notification at the top of the screen -----
  const notify = (message) => {
    setToast(message);
    clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(''), 1600);
  };

  // plays a sound only if the user has sound turned on
  const play = (name) => {
    if (soundOn) playSound(name);
  };

  // ================= AUTH (demo only, no backend) =================
  const startSession = async (email, name, remember) => {
    const u = { email, name };
    setUser(u);
    if (remember) await AsyncStorage.setItem('session', JSON.stringify(u));
  };

  // returns an error message, or null when everything went fine
  const signup = async (name, email, password, remember) => {
    const users = await read('users', []);
    if (users.find((u) => u.email === email)) return 'This email is already registered';
    users.push({ name, email, password });
    await AsyncStorage.setItem('users', JSON.stringify(users));
    await startSession(email, name, remember);
    return null;
  };

  const login = async (email, password, remember) => {
    const users = await read('users', []);
    const found = users.find((u) => u.email === email && u.password === password);
    if (!found) return 'Wrong email or password';
    await startSession(email, found.name || email.split('@')[0], remember);
    return null;
  };

  const logout = async () => {
    setUser(null);
    await AsyncStorage.removeItem('session');
  };

  // ---- "login first, then continue" ----
  // Screens call this before a protected action. When the user is logged in it returns
  // true. Otherwise it remembers `pending` (for example the product to add), opens the
  // Login screen and returns false. After a successful login the Login screen calls
  // runPending() which finishes the job automatically.
  const requireLogin = (navigation, pending) => {
    if (user) return true;
    pendingRef.current = pending || null;
    navigation.navigate('Login');
    return false;
  };

  // runs the remembered action once; returns it so Login knows where to go next
  const runPending = () => {
    const p = pendingRef.current;
    pendingRef.current = null;
    if (p && p.type === 'add') addToCart(p.product, p.size, p.qty);
    return p;
  };

  // ================= CART =================
  const addToCart = (product, size, qty = 1) => {
    const key = lineKey(product.id, size);
    setCart((old) => {
      const exists = old.find((i) => i.key === key);
      if (exists) return old.map((i) => (i.key === key ? { ...i, qty: i.qty + qty } : i));
      return [...old, { ...product, key, qty, size }];
    });
    notify('Added to Cart ✓');
    play('add');
  };

  // delta is +1 or -1; quantity 0 removes the item
  const changeQty = (key, delta) => {
    setCart((old) =>
      old.map((i) => (i.key === key ? { ...i, qty: i.qty + delta } : i)).filter((i) => i.qty > 0)
    );
  };

  const removeFromCart = (key) => {
    setCart((old) => old.filter((i) => i.key !== key));
    notify('Removed from cart');
  };

  const clearCart = () => setCart([]);

  // ================= WISHLIST =================
  const isWished = (id) => wishlist.some((p) => p.id === id);

  const toggleWishlist = (product) => {
    if (isWished(product.id)) {
      setWishlist((old) => old.filter((p) => p.id !== product.id));
      notify('Removed from Wishlist');
    } else {
      setWishlist((old) => [...old, product]);
      notify('Saved to Wishlist ♥');
    }
  };

  // ================= ORDERS =================
  // Saves the current cart as an order (with the delivery details) and empties the cart.
  const placeOrder = async (details) => {
    const { subtotal, discount, total } = calcTotals(cart);
    const order = {
      id: 'CS' + Date.now().toString().slice(-8),
      email: user ? user.email : 'guest',
      date: new Date().toISOString(),
      status: 'Confirmed',
      items: cart.map((i) => ({
        id: i.id, name: i.name, price: i.price, qty: i.qty, size: i.size,
        images: i.images || [i.image], contain: i.contain,
      })),
      subtotal, discount, total,
      ...details, // name, phone, address, payment
    };
    const next = [order, ...orders];
    setOrders(next);
    await AsyncStorage.setItem('orders', JSON.stringify(next));
    setCart([]);
    return order;
  };

  // only the orders of the logged in user
  const myOrders = user ? orders.filter((o) => o.email === user.email) : [];

  // ================= BUDGET (ChaloSmart) =================
  const setBudget = (amount) => {
    setBudgetState(amount);
    AsyncStorage.setItem('budget', JSON.stringify(amount));
  };

  const cartCount = cart.reduce((sum, i) => sum + i.qty, 0); // number on the cart badge

  const value = {
    loading, user, login, signup, logout, requireLogin, runPending,
    cart, cartCount, addToCart, changeQty, removeFromCart, clearCart,
    wishlist, isWished, toggleWishlist,
    orders: myOrders, placeOrder,
    budget, setBudget,
    toast, notify, play,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export const useApp = () => useContext(AppContext);
