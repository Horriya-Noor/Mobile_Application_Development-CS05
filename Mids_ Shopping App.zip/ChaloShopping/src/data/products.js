// products.js
// Local product data for Clothes and Accessories (Makeup + Trending come from the API).
//
// PICTURES: every product has an `images` list. The app tries the first photo (an
// Unsplash web photo), and if it cannot load it tries the next one (a keyword photo
// from loremflickr.com). If all of them fail, SafeImage shows an icon instead.
// To use your own picture, put its web link (or require('../../assets/x.jpg'))
// at the FRONT of that product's `images` list.

const unsplash = (id, w = 600) =>
  `https://images.unsplash.com/photo-${id}?auto=format&fit=crop&w=${w}&q=80`;

const flickr = (tags, lock, w = 600, h = 750) =>
  `https://loremflickr.com/${w}/${h}/${tags}?lock=${lock}`;

// builds the list [best photo, backup photo] for one picture
const pics = (unsplashId, tags, lock, w, h) =>
  unsplashId ? [unsplash(unsplashId, w), flickr(tags, lock, w, h)] : [flickr(tags, lock, w, h)];

let counter = 0;

// helper that builds one product object
const add = (category, gender, sub, name, price, unsplashId, tags, description, extra = {}) => {
  counter += 1;
  const images = pics(unsplashId, tags, counter);
  return {
    id: `p${counter}`,
    category,
    gender,
    sub,
    name,
    price,
    images,
    image: images[0],
    description,
    brand: 'ChaloShopping',
    rating: 4 + ((counter * 3) % 10) / 10, // 4.0 - 4.9, stable for each product
    ratingCount: 40 + counter * 7,
    ...extra,
  };
};

export const PRODUCTS = [
  // ---------- CLOTHES : FEMALE ----------
  add('clothes', 'female', 'stitched', 'Turkish Frocks', 4000, '1595777457583-95e059d581b8', 'dress,woman', 'Ready-to-wear embroidered frock with a flowing silhouette.'),
  add('clothes', 'female', 'stitched', 'Chiffon Frocks', 3500, '1572804013309-59a88b7e92f1', 'gown,woman', 'Light chiffon frock with hand finished embroidery.', { deal: true }),
  add('clothes', 'female', 'stitched', 'Long Dresses', 4000, '1496747611176-843222e1e57c', 'longdress,fashion', 'Full length dress, perfect for weddings and parties.'),
  add('clothes', 'female', 'stitched', 'Lawn Dresses', 3000, null, 'summerdress,woman', 'Soft printed lawn dress for everyday summer wear.'),
  add('clothes', 'female', 'stitched', 'Summer Dress', 2099, '1515372039744-b8f02a3ae446', 'sundress,woman', 'Breezy casual dress in a comfortable cotton blend.', { deal: true }),
  add('clothes', 'female', 'unstitched', 'Lawn 26 | D-2601-B', 4000, '1558171813-4c088753af8e', 'fabric,embroidery', 'Embroidered Jacquard Lawn Shirt, Dyed Cambric Trouser, Burnout Silk Dupatta', { brand: 'Maria B.' }),
  add('clothes', 'female', 'unstitched', 'Cotton 3-Piece', 2800, null, 'fabric,cotton', 'Three piece cotton suit with printed dupatta.'),
  add('clothes', 'female', 'unstitched', 'Printed Lawn', 1800, null, 'textile,print', 'Digital printed lawn, 2 piece unstitched fabric.', { deal: true }),
  add('clothes', 'female', 'unstitched', 'Khaddar Suit', 3200, null, 'wool,cloth', 'Warm khaddar suit for the winter season.'),

  // ---------- CLOTHES : MALE ----------
  add('clothes', 'male', 'stitched', 'Formal Shirt', 2099, '1596755094514-f87e34085b2c', 'shirt,men', 'Crisp white formal shirt with a slim fit.'),
  add('clothes', 'male', 'stitched', 'Casual Shirt', 1500, '1602810318383-e386cc2a3ccf', 'tshirt,men', 'Everyday casual shirt in soft cotton.'),
  add('clothes', 'male', 'stitched', 'Cotton Kurta', 2500, null, 'kurta,men', 'Classic stitched cotton kurta.', { deal: true }),
  add('clothes', 'male', 'stitched', 'Waistcoat', 3200, null, 'waistcoat,suit', 'Formal waistcoat for weddings and events.'),
  add('clothes', 'male', 'unstitched', 'Wash & Wear Fabric', 2200, '1620799140408-edc6dcb6d633', 'fabric,roll', 'Wrinkle free wash and wear suit fabric.'),
  add('clothes', 'male', 'unstitched', 'Cotton Suit Fabric', 1900, null, 'cotton,fabric', 'Breathable cotton fabric, 4 meters.'),
  add('clothes', 'male', 'unstitched', 'Khaddar Fabric', 2800, null, 'cloth,wool', 'Thick khaddar fabric for winter.', { deal: true }),

  // ---------- ACCESSORIES : MALE ----------
  add('accessories', 'male', 'wallets', 'Leather Wallet', 999, '1627123424574-724758594e93', 'wallet,leather', 'Genuine leather bifold wallet.', { deal: true }),
  add('accessories', 'male', 'wallets', 'Card Holder', 650, null, 'cardholder,wallet', 'Slim card holder with 6 slots.'),
  add('accessories', 'male', 'wallets', 'Travel Wallet', 1400, null, 'leather,wallet', 'Large travel wallet for cash, cards and passport.'),
  add('accessories', 'male', 'watches', 'Classic Watch', 2499, '1523275335684-37898b6baf30', 'wristwatch', 'Stainless steel analog watch with date display.'),
  add('accessories', 'male', 'watches', 'Sports Watch', 1799, '1524592094714-0f0654e20314', 'sportwatch', 'Water resistant sports watch.', { deal: true }),
  add('accessories', 'male', 'watches', 'Digital Watch', 1199, '1547996160-81dfa63595aa', 'digitalwatch', 'Simple digital watch with alarm and stopwatch.'),

  // ---------- ACCESSORIES : FEMALE ----------
  add('accessories', 'female', 'jewellery', 'Necklace Set', 1799, '1515562141207-7a88fb7ce338', 'necklace,gold', 'Gold plated necklace set with matching earrings.'),
  add('accessories', 'female', 'jewellery', 'Pearl Earrings', 899, '1535632066927-ab7c9ab60908', 'earrings,pearl', 'Elegant pearl drop earrings.', { deal: true }),
  add('accessories', 'female', 'jewellery', 'Silver Bracelet', 750, '1599643478518-a784e5dc4c8f', 'bracelet,silver', 'Light silver bracelet for daily wear.'),
  add('accessories', 'female', 'jewellery', 'Bridal Jhumkay', 2600, '1611591437281-460bfbe1220a', 'jhumka,jewellery', 'Heavy bridal jhumkay with kundan work.'),
  add('accessories', 'female', 'purses', 'Leather Handbag', 2200, '1584917865442-de89df76afd3', 'handbag', 'Spacious faux leather handbag.'),
  add('accessories', 'female', 'purses', 'Party Clutch', 1300, '1548036328-c9fa89d128fa', 'clutch,purse', 'Sparkly clutch for parties.', { deal: true }),
  add('accessories', 'female', 'purses', 'Tote Bag', 1650, '1590874103328-eac38a683ce7', 'totebag', 'Canvas tote bag for daily use.'),

  // ---------- MAKEUP (the Makeup screen itself uses the API) ----------
  add('makeup', 'female', 'kit', 'Makeup Kit', 1299, '1522335789203-aabd1fc54bc9', 'makeup,palette', 'Complete makeup kit with eyeshadow, blush and brushes.'),
];

// Offline backup for "Trending Now" on Home (used only when the API cannot be reached)
export const TRENDING = ['Summer Dress', 'Classic Watch', 'Makeup Kit', 'Leather Handbag'].map((name) =>
  PRODUCTS.find((p) => p.name === name)
);

// Pictures for the round category icons on Home
export const CATEGORY_IMAGES = {
  clothes: pics('1490481651871-ab68de25d43d', 'clothes,fashion', 101, 200, 200),
  accessories: pics('1523170335258-f5ed11844a49', 'watch,jewellery', 102, 200, 200),
  makeup: pics('1487412947147-5cebf100ffc2', 'makeup,lipstick', 103, 200, 200),
  all: pics('1441984904996-e0b6ba687e04', 'shop,store', 104, 200, 200),
};

// Sub categories shown on the Clothes / Accessories screens
export const SUBCATEGORIES = {
  clothes: {
    male: [
      { key: 'stitched', label: 'Stitched', images: pics('1596755094514-f87e34085b2c', 'shirt,men', 111, 400, 400) },
      { key: 'unstitched', label: 'Unstitched', images: pics('1620799140408-edc6dcb6d633', 'fabric', 112, 400, 400) },
    ],
    female: [
      { key: 'stitched', label: 'Stitched', images: pics('1595777457583-95e059d581b8', 'dress,woman', 113, 400, 400) },
      { key: 'unstitched', label: 'Unstitched', images: pics('1558171813-4c088753af8e', 'fabric,lawn', 114, 400, 400) },
    ],
  },
  accessories: {
    male: [
      { key: 'wallets', label: 'Purses / Wallets', images: pics('1627123424574-724758594e93', 'wallet', 115, 400, 400) },
      { key: 'watches', label: 'Watches', images: pics('1523275335684-37898b6baf30', 'wristwatch', 116, 400, 400) },
    ],
    female: [
      { key: 'jewellery', label: 'Jewellery', images: pics('1515562141207-7a88fb7ce338', 'jewellery', 117, 400, 400) },
      { key: 'purses', label: 'Purses', images: pics('1584917865442-de89df76afd3', 'handbag', 118, 400, 400) },
    ],
  },
};

// Pictures used on the Categories screen and the Home hero card
export const EXTRA_IMAGES = {
  menClothes: pics('1489987707025-afc232f7ea0f', 'menshirt', 121, 400, 400),
  menAccessories: pics('1523275335684-37898b6baf30', 'watch,men', 122, 400, 400),
  womenClothes: pics('1496747611176-843222e1e57c', 'womendress', 123, 400, 400),
  womenAccessories: pics('1515562141207-7a88fb7ce338', 'jewellery,fashion', 124, 400, 400),
  womenMakeup: pics('1522335789203-aabd1fc54bc9', 'cosmetics', 125, 400, 400),
  hero: pics('1483985988355-763728e1935b', 'shopping,bags,woman', 126, 400, 560),
};
