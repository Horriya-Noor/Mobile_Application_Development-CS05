// AccessoriesScreen.js
// Accessories -> Men (Purses/Wallets, Watches) / Women (Jewellery, Purses) -> product list.
// The tabs and cards come from the shared SectionTabs component.

import React from 'react';
import SectionTabs from '../../components/SectionTabs';

export default function AccessoriesScreen({ route }) {
  return <SectionTabs category="accessories" title="Accessories" gender={route.params?.gender} />;
}
