// CategoriesScreen.js
// The Categories tab: Mens' Section, Womens' Section, MakeUp and the ChaloSmart shortcut.
// Every card opens the matching screen.

import React from 'react';
import { ScrollView, View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import Header from '../../components/Header';
import Screen from '../../components/Screen';
import CategoryCard from '../../components/CategoryCard';
import { EXTRA_IMAGES } from '../../data/products';
import { useTheme, HEADING_FONT } from '../../theme/ThemeContext';

export default function CategoriesScreen({ navigation }) {
  const { colors, fs } = useTheme();

  return (
    <Screen>
      <Header />
      <ScrollView contentContainerStyle={{ padding: 10, paddingBottom: 30 }}>
        <Text style={[styles.main, { color: colors.green, fontSize: fs(18) }]}>Shop by Category</Text>

        {/* ----- Men ----- */}
        <Text style={[styles.heading, { color: colors.text, fontSize: fs(28) }]}>Mens' Section</Text>
        <View style={styles.row}>
          <CategoryCard
            images={EXTRA_IMAGES.menClothes}
            title="Men Clothes"
            subtitle="Stitched, Unstitched"
            onPress={() => navigation.navigate('Clothes', { gender: 'male' })}
          />
          <CategoryCard
            images={EXTRA_IMAGES.menAccessories}
            title="Men Accessories"
            subtitle="Purses/Wallets, Watches"
            onPress={() => navigation.navigate('Accessories', { gender: 'male' })}
          />
        </View>

        {/* ----- Women ----- */}
        <Text style={[styles.heading, { color: colors.text, fontSize: fs(28) }]}>Womens' Section</Text>
        <View style={styles.row}>
          <CategoryCard
            images={EXTRA_IMAGES.womenClothes}
            title="Clothes"
            subtitle="Stitched, Unstitched"
            onPress={() => navigation.navigate('Clothes', { gender: 'female' })}
          />
          <CategoryCard
            images={EXTRA_IMAGES.womenAccessories}
            title="Accessories"
            subtitle="Jewellery, Purses"
            onPress={() => navigation.navigate('Accessories', { gender: 'female' })}
          />
        </View>
        <View style={styles.row}>
          <CategoryCard
            images={EXTRA_IMAGES.womenMakeup}
            title="MakeUp"
            subtitle="All type of makeup"
            onPress={() => navigation.navigate('Makeup')}
          />
          {/* empty half so the MakeUp card keeps the same size as the others */}
          <View style={{ flex: 1, margin: 6 }} />
        </View>

        {/* shortcut to the budget feature */}
        <TouchableOpacity
          style={[styles.smart, { borderColor: colors.primary, backgroundColor: colors.card }]}
          onPress={() => navigation.navigate('ChaloSmart')}
        >
          <Ionicons name="wallet-outline" size={24} color={colors.primary} />
          <Text style={{ color: colors.text, fontWeight: '800', fontSize: fs(14), marginLeft: 10 }}>
            ChaloSmart — Shop Within Your Budget
          </Text>
        </TouchableOpacity>
      </ScrollView>
    </Screen>
  );
}

const styles = StyleSheet.create({
  main: { fontWeight: '900', textAlign: 'center', marginTop: 4 },
  heading: { fontFamily: HEADING_FONT, marginTop: 12, marginLeft: 6 },
  row: { flexDirection: 'row', marginTop: 8 },
  smart: { flexDirection: 'row', marginTop: 22, padding: 14, borderRadius: 10, borderWidth: 1.5, borderStyle: 'solid', alignItems: 'center', justifyContent: 'center' },
});
