// ProfileScreen.js
// Account card, quick links (My Orders, Wish List, Cart), settings (dark mode, sound,
// text size) and log in / log out. Opening "My Orders" asks for login when needed.

import React from 'react';
import { ScrollView, View, Text, Switch, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import Header from '../../components/Header';
import Screen from '../../components/Screen';
import { useApp } from '../../context/AppContext';
import { useTheme } from '../../theme/ThemeContext';

// text size choices (scale is multiplied with every font size in the app)
const TEXT_SIZES = [
  { label: 'Small', value: 0.85 },
  { label: 'Normal', value: 1 },
  { label: 'Large', value: 1.2 },
  { label: 'Extra Large', value: 1.4 },
];

export default function ProfileScreen({ navigation }) {
  const { colors, fs, dark, toggleDark, scale, setScale, soundOn, toggleSound } = useTheme();
  const { user, logout, orders, wishlist, cartCount, requireLogin, notify } = useApp();

  const onLogout = async () => {
    await logout();
    notify('Logged out');
  };

  // a tappable row with an icon, a label and an arrow
  const link = (icon, label, onPress, value) => (
    <TouchableOpacity style={[styles.card, styles.row, { backgroundColor: colors.card }]} onPress={onPress}>
      <Ionicons name={icon} size={22} color={colors.primary} />
      <Text style={[styles.rowLabel, { color: colors.text, fontSize: fs(14) }]}>{label}</Text>
      {value !== undefined && <Text style={{ color: colors.subText, fontSize: fs(12), marginRight: 6 }}>{value}</Text>}
      <Ionicons name="chevron-forward" size={18} color={colors.subText} />
    </TouchableOpacity>
  );

  return (
    <Screen>
      <Header />
      <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 30 }}>
        {/* user card */}
        <View style={[styles.card, { backgroundColor: colors.card, alignItems: 'center' }]}>
          <Ionicons name="person-circle" size={80} color={colors.primary} />
          <Text style={{ color: colors.text, fontSize: fs(18), fontWeight: '900' }}>{user ? user.name : 'Guest'}</Text>
          <Text style={{ color: colors.subText, fontSize: fs(12) }}>{user ? user.email : 'You are not logged in'}</Text>
          {!user && (
            <TouchableOpacity style={[styles.loginBtn, { backgroundColor: colors.primary }]} onPress={() => navigation.navigate('Login')}>
              <Text style={{ color: '#fff', fontWeight: '900', fontSize: fs(13) }}>LOG IN / SIGN UP</Text>
            </TouchableOpacity>
          )}
        </View>

        <Text style={[styles.heading, { color: colors.text, fontSize: fs(15) }]}>My Shopping</Text>
        {link('receipt-outline', 'My Orders', () => requireLogin(navigation) && navigation.navigate('MyOrders'), user ? orders.length : undefined)}
        {link('heart-outline', 'Wish List', () => navigation.navigate('Wishlist'), wishlist.length)}
        {link('cart-outline', 'My Cart', () => navigation.navigate('Cart'), cartCount)}

        <Text style={[styles.heading, { color: colors.text, fontSize: fs(15) }]}>Settings</Text>

        {/* dark mode switch */}
        <View style={[styles.card, styles.row, { backgroundColor: colors.card }]}>
          <Ionicons name="moon-outline" size={22} color={colors.text} />
          <Text style={[styles.rowLabel, { color: colors.text, fontSize: fs(14) }]}>Dark Mode</Text>
          <Switch value={dark} onValueChange={toggleDark} trackColor={{ true: colors.primary }} />
        </View>

        {/* sound switch */}
        <View style={[styles.card, styles.row, { backgroundColor: colors.card }]}>
          <Ionicons name="volume-medium-outline" size={22} color={colors.text} />
          <Text style={[styles.rowLabel, { color: colors.text, fontSize: fs(14) }]}>Sound Effects</Text>
          <Switch value={soundOn} onValueChange={toggleSound} trackColor={{ true: colors.primary }} />
        </View>

        {/* text size */}
        <View style={[styles.card, { backgroundColor: colors.card }]}>
          <Text style={{ color: colors.text, fontSize: fs(14), fontWeight: '800' }}>Text Size</Text>
          <View style={styles.sizeRow}>
            {TEXT_SIZES.map((s) => (
              <TouchableOpacity
                key={s.label}
                onPress={() => setScale(s.value)}
                style={[styles.sizeChip, { backgroundColor: scale === s.value ? colors.primary : colors.chip }]}
              >
                <Text style={{ color: '#fff', fontWeight: '700', fontSize: fs(11) }}>{s.label}</Text>
              </TouchableOpacity>
            ))}
          </View>
          <Text style={{ color: colors.subText, fontSize: fs(14), marginTop: 10 }}>Preview: Apni Pasand, Apne Budget Mein!</Text>
        </View>

        {/* log out */}
        {user && (
          <TouchableOpacity style={[styles.button, { backgroundColor: '#D32F2F' }]} onPress={onLogout}>
            <Ionicons name="log-out-outline" size={18} color="#fff" />
            <Text style={{ color: '#fff', fontWeight: '900', fontSize: fs(14), marginLeft: 8 }}>LOG OUT</Text>
          </TouchableOpacity>
        )}
      </ScrollView>
    </Screen>
  );
}

const styles = StyleSheet.create({
  card: { padding: 14, borderRadius: 10, marginBottom: 10, elevation: 2 },
  heading: { fontWeight: '900', marginTop: 8, marginBottom: 8 },
  row: { flexDirection: 'row', alignItems: 'center' },
  rowLabel: { flex: 1, marginLeft: 12, fontWeight: '600' },
  loginBtn: { marginTop: 12, paddingHorizontal: 26, paddingVertical: 10, borderRadius: 22 },
  sizeRow: { flexDirection: 'row', flexWrap: 'wrap', marginTop: 10 },
  sizeChip: { paddingHorizontal: 14, paddingVertical: 6, borderRadius: 16, marginRight: 8, marginBottom: 6 },
  button: { flexDirection: 'row', justifyContent: 'center', paddingVertical: 13, borderRadius: 24, alignItems: 'center', marginTop: 8 },
});
