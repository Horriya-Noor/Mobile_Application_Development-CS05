// HomeScreen.js
// Home: toolbar (dark mode + cart badge), greeting, category circles, hero card,
// moving offer banner, ChaloSmart button, Trending Now (from the API) and Best Deals.

import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, ScrollView, ActivityIndicator, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import Screen from '../../components/Screen';
import Header from '../../components/Header';
import SafeImage from '../../components/SafeImage';
import MovingBanner from '../../components/MovingBanner';
import ProductCard from '../../components/ProductCard';
import { PRODUCTS, TRENDING, CATEGORY_IMAGES, EXTRA_IMAGES } from '../../data/products';
import { fetchApiProducts } from '../../utils/api';
import { useApp } from '../../context/AppContext';
import { useTheme, HEADING_FONT } from '../../theme/ThemeContext';

// the round categories under "SHOP BY CATEGORY"
const CATEGORIES = [
  { label: 'CLOTHES', screen: 'Clothes', images: CATEGORY_IMAGES.clothes },
  { label: 'ACCESSORIES', screen: 'Accessories', images: CATEGORY_IMAGES.accessories },
  { label: 'MAKEUP', screen: 'Makeup', images: CATEGORY_IMAGES.makeup },
  { label: 'ALL', screen: 'Categories', images: CATEGORY_IMAGES.all },
];

// products with the "deal" flag, shown in the "Best Deals" row
const DEALS = PRODUCTS.filter((p) => p.deal);

export default function HomeScreen({ navigation }) {
  const { colors, fs } = useTheme();
  const { user } = useApp();

  const [trending, setTrending] = useState([]);
  const [status, setStatus] = useState('loading'); // 'loading' | 'ok' | 'offline'

  // ----- Trending Now: the best rated products from the API -----
  const loadTrending = async () => {
    setStatus('loading');
    try {
      const all = await fetchApiProducts();
      setTrending([...all].sort((a, b) => b.rating - a.rating).slice(0, 6));
      setStatus('ok');
    } catch (e) {
      setTrending(TRENDING); // no internet: show our own products instead
      setStatus('offline');
    }
  };

  useEffect(() => {
    loadTrending();
  }, []);

  // a horizontal row of product cards
  const row = (data) => (
    <FlatList
      horizontal
      data={data}
      keyExtractor={(item) => item.id}
      showsHorizontalScrollIndicator={false}
      contentContainerStyle={{ paddingHorizontal: 6 }}
      renderItem={({ item }) => <ProductCard product={item} style={{ width: 158, maxWidth: 158, flex: 0 }} />}
    />
  );

  return (
    <Screen>
      <Header />

      <ScrollView showsVerticalScrollIndicator={false}>
        {/* greeting */}
        <View style={styles.greeting}>
          <Text style={[styles.hello, { color: colors.text, fontSize: fs(18) }]}>
            Hello, {user ? user.name : 'Guest'} 👋
          </Text>
          <Text style={{ color: colors.subText, fontSize: fs(12) }}>Apni Pasand, Apne Budget Mein!</Text>
        </View>

        <Text style={[styles.heading, { color: colors.green, fontSize: fs(16) }]}>SHOP BY CATEGORY</Text>

        {/* category circles */}
        <View style={styles.categories}>
          {CATEGORIES.map((c) => (
            <TouchableOpacity key={c.label} style={styles.category} onPress={() => navigation.navigate(c.screen)}>
              <SafeImage uris={c.images} style={[styles.circle, { borderColor: colors.primary }]} iconSize={24} />
              <Text style={[styles.categoryText, { color: colors.primary, fontSize: fs(10) }]}>{c.label}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* hero card */}
        <View style={[styles.hero, { backgroundColor: colors.chip }]}>
          <SafeImage uris={EXTRA_IMAGES.hero} style={styles.heroImage} iconSize={40} />
          <View style={styles.heroText}>
            <Text style={[styles.quote, { fontSize: fs(15) }]}>"Everything You Love, All in One Place."</Text>
            <Text style={[styles.quoteSub, { fontSize: fs(10) }]}>Discover great products at prices you'll love.</Text>
            <TouchableOpacity style={styles.heroButton} onPress={() => navigation.navigate('Categories')}>
              <Text style={[styles.heroButtonText, { fontSize: fs(11) }]}>Let's Start Shopping</Text>
              <Ionicons name="arrow-forward" size={16} color="#fff" />
            </TouchableOpacity>
          </View>
        </View>

        {/* moving offer banner for the Rs. 1,200 rule */}
        <MovingBanner text="20% OFF on Shopping Above Rs. 1,200 — Available Till 20 October" />

        {/* ChaloSmart budget mode button */}
        <TouchableOpacity
  style={[
    styles.smart,
    {
      backgroundColor: colors.card,
      borderColor: colors.primary,
      borderWidth: 2,
      borderStyle: 'solid',
    },
  ]}
  onPress={() => navigation.navigate('ChaloSmart')}
>
  <Ionicons
    name="wallet-outline"   size={28}  color={colors.primary} />

  <View style={{ marginLeft: 12 }}>
    <Text style={[  styles.smartTitle, {  color: colors.text,   fontSize: fs(15),  },  ]} > ChaloSmart </Text>

    <Text  style={{ color: colors.subText, fontSize: fs(12), }}>
      Shop Within Your Budget
    </Text>
  </View>

  <Ionicons name="chevron-forward" size={22} color={colors.primary} style={{ marginLeft: 'auto' }} />
</TouchableOpacity>

        {/* trending products (API) */}
        <View style={styles.sectionHeader}>
          <Text style={[styles.sectionTitle, { color: colors.text, fontSize: fs(15) }]}>Trending Now</Text>
          <TouchableOpacity onPress={() => navigation.navigate('Makeup')}>
            <Text style={{ color: colors.primary, fontSize: fs(12), fontWeight: '700' }}>See All →</Text>
          </TouchableOpacity>
        </View>
        {status === 'loading' ? (
          <ActivityIndicator color={colors.primary} style={{ marginVertical: 40 }} />
        ) : (
          <>
            {status === 'offline' && (
              <TouchableOpacity onPress={loadTrending} style={styles.offline}>
                <Ionicons name="cloud-offline-outline" size={16} color={colors.subText} />
                <Text style={{ color: colors.subText, fontSize: fs(11), marginLeft: 6 }}>
                  Showing saved picks. Tap to retry.
                </Text>
              </TouchableOpacity>
            )}
            {row(trending)}
          </>
        )}

        {/* best deals (local products) */}
        <View style={styles.sectionHeader}>
          <Text style={[styles.sectionTitle, { color: colors.text, fontSize: fs(15) }]}>🔥 Best Deals</Text>
        </View>
        {row(DEALS)}

        <View style={{ height: 24 }} />
      </ScrollView>
    </Screen>
  );
}

const styles = StyleSheet.create({
  greeting: { paddingHorizontal: 14, paddingTop: 12 },
  hello: { fontFamily: HEADING_FONT },
  heading: { textAlign: 'center', fontWeight: '900', marginTop: 16 },
  categories: { flexDirection: 'row', justifyContent: 'space-around', marginVertical: 14 },
  category: { alignItems: 'center' },
  circle: { width: 68, height: 68, borderRadius: 34, borderWidth: 2 },
  categoryText: { fontWeight: '800', marginTop: 6 },
  hero: { flexDirection: 'row', alignItems: 'center', paddingRight: 10, height: 190 },
  heroImage: { width: 130, height: 190 },
  heroText: { flex: 1, paddingLeft: 10 },
  quote: { fontWeight: '900', color: '#111' },
  quoteSub: { color: '#7A3B46', marginTop: 6 },
  heroButton: {
    marginTop: 14, backgroundColor: '#0B6B3A', flexDirection: 'row', alignItems: 'center',
    justifyContent: 'space-between', paddingVertical: 8, paddingHorizontal: 12, borderRadius: 22,
  },
  heroButtonText: { color: '#fff', fontWeight: '800' },
  smart: {
    flexDirection: 'row', alignItems: 'center', margin: 12, padding: 12,
    borderRadius: 10, borderWidth: 1.5, borderStyle: 'dashed',
  },
  smartTitle: { fontWeight: '900' },
  sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', paddingHorizontal: 14, marginTop: 6, marginBottom: 4 },
  sectionTitle: { fontWeight: '800' },
  offline: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 14, paddingBottom: 4 },
});
