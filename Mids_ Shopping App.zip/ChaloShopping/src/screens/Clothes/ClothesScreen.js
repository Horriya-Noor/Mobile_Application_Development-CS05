// ClothesScreen.js
// Clothes -> Men / Women tabs -> Stitched / Unstitched -> product list.
// The tabs and cards come from the shared SectionTabs component.

import React from 'react';
import SectionTabs from '../../components/SectionTabs';

export default function ClothesScreen({ route }) {
  return <SectionTabs category="clothes" title="Clothes" gender={route.params?.gender} />;
}
