// MyOrdersScreen.js
// The list of orders the logged in user has placed (saved in AsyncStorage when the user
// pressed Place Order). Each card shows the order number, date, status, items and amounts.

import React from 'react';
import { FlatList, View, Text, StyleSheet } from 'react-native';
import Screen from '../../components/Screen';
import BackRow from '../../components/BackRow';
import SafeImage from '../../components/SafeImage';
import EmptyState from '../../components/EmptyState';
import { useApp } from '../../context/AppContext';
import { useTheme } from '../../theme/ThemeContext';
import { formatPrice } from '../../utils/pricing';

// "2026-10-18T10:20:00Z" -> "18 Oct 2026"
const niceDate = (iso) =>
  new Date(iso).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });

export default function MyOrdersScreen({ navigation }) {
  const { colors, fs } = useTheme();
  const { orders } = useApp();

  return (
    <Screen bottom>
      <BackRow title="My Orders" />
      <FlatList
        data={orders}
        keyExtractor={(o) => o.id}
        contentContainerStyle={{ padding: 12, paddingBottom: 30 }}
        ListEmptyComponent={
          <EmptyState
            icon="receipt-outline"
            title="No orders yet"
            subtitle="Orders you place will appear here."
            buttonLabel="Start Shopping"
            onPress={() => navigation.navigate('Main', { screen: 'Categories' })}
          />
        }
        renderItem={({ item: order }) => (
          <View style={[styles.card, { backgroundColor: colors.card }]}>
            {/* order number + status */}
            <View style={styles.top}>
              <View>
                <Text style={{ color: colors.text, fontWeight: '900', fontSize: fs(14) }}>Order #{order.id}</Text>
                <Text style={{ color: colors.subText, fontSize: fs(11) }}>{niceDate(order.date)} · {order.payment}</Text>
              </View>
              <View style={[styles.status, { backgroundColor: '#D7F5DF' }]}>
                <Text style={{ color: '#0B6B3A', fontWeight: '800', fontSize: fs(10) }}>{order.status}</Text>
              </View>
            </View>

            {/* items */}
            {order.items.map((i, idx) => (
              <View key={idx} style={styles.item}>
                <SafeImage uris={i.images} style={[styles.thumb, i.contain && { backgroundColor: '#fff' }]} resizeMode={i.contain ? 'contain' : 'cover'} iconSize={18} />
                <Text numberOfLines={1} style={{ flex: 1, color: colors.text, fontSize: fs(12), marginLeft: 10 }}>
                  {i.name}{i.size ? ` (${i.size})` : ''} × {i.qty}
                </Text>
                <Text style={{ color: colors.text, fontSize: fs(12), fontWeight: '700' }}>{formatPrice(i.price * i.qty)}</Text>
              </View>
            ))}

            {/* amounts */}
            <View style={[styles.divider, { backgroundColor: colors.subText }]} />
            {order.discount > 0 && (
              <View style={styles.line}>
                <Text style={{ color: colors.subText, fontSize: fs(12) }}>Discount (20%)</Text>
                <Text style={{ color: colors.green, fontSize: fs(12), fontWeight: '700' }}>- {formatPrice(order.discount)}</Text>
              </View>
            )}
            <View style={styles.line}>
              <Text style={{ color: colors.text, fontSize: fs(13), fontWeight: '900' }}>Total paid</Text>
              <Text style={{ color: colors.green, fontSize: fs(13), fontWeight: '900' }}>{formatPrice(order.total)}</Text>
            </View>
            {order.address ? (
              <Text style={{ color: colors.subText, fontSize: fs(11), marginTop: 6 }}>Deliver to: {order.address}</Text>
            ) : null}
          </View>
        )}
      />
    </Screen>
  );
}

const styles = StyleSheet.create({
  card: { padding: 12, borderRadius: 10, marginBottom: 12, elevation: 2 },
  top: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  status: { paddingHorizontal: 10, paddingVertical: 3, borderRadius: 10 },
  item: { flexDirection: 'row', alignItems: 'center', paddingVertical: 4 },
  thumb: { width: 38, height: 44, borderRadius: 4 },
  divider: { height: 1, opacity: 0.3, marginVertical: 8 },
  line: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 2 },
});
