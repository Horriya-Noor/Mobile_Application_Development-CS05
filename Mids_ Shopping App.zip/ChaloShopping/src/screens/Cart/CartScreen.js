// CartScreen.js
// Items in the cart with quantity up/down, remove, totals (20% discount above Rs. 1,200)
// and the ChaloSmart budget check. The cart is saved, so it is still here after a restart.
// A visitor who is not logged in is asked to log in first.

import React from 'react';
import { FlatList, View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import Header from '../../components/Header';
import BackRow from '../../components/BackRow';
import Screen from '../../components/Screen';
import SafeImage from '../../components/SafeImage';
import QtyStepper from '../../components/QtyStepper';
import EmptyState from '../../components/EmptyState';
import BudgetNote from '../../components/BudgetNote';
import { useApp } from '../../context/AppContext';
import { useTheme } from '../../theme/ThemeContext';
import { calcTotals, formatPrice, DISCOUNT_LIMIT } from '../../utils/pricing';

export default function CartScreen({ navigation }) {
  const { colors, fs } = useTheme();
  const { user, cart, changeQty, removeFromCart, clearCart, budget } = useApp();
  const { subtotal, discount, total } = calcTotals(cart);

  // ----- not logged in: ask for login -----
  if (!user) {
    return (
      <Screen>
        <Header />
        <EmptyState
          icon="lock-closed-outline"
          title="Log in to see your cart"
          subtitle="Your cart is saved to your account."
          buttonLabel="Log In / Sign Up"
          onPress={() => navigation.navigate('Login')}
        />
      </Screen>
    );
  }

  // one line in the totals box
  const totalRow = (label, value, bold, color) => (
    <View style={styles.totalRow}>
      <Text style={{ color: colors.text, fontSize: fs(13), fontWeight: bold ? '900' : '500' }}>{label}</Text>
      <Text style={{ color: color || colors.text, fontSize: fs(13), fontWeight: bold ? '900' : '600' }}>{value}</Text>
    </View>
  );

  return (
    <Screen>
      <Header />
      <BackRow title="My Cart" />

      <FlatList
        data={cart}
        keyExtractor={(item) => item.key}
        contentContainerStyle={{ padding: 10, paddingBottom: 30 }}
        ListEmptyComponent={
          <EmptyState
            icon="cart-outline"
            title="Your cart is empty"
            subtitle="Add something you like and it will show up here."
            buttonLabel="Start Shopping"
            onPress={() => navigation.navigate('Categories')}
          />
        }
        renderItem={({ item }) => (
          <View style={[styles.row, { backgroundColor: colors.card }]}>
            <SafeImage
              uris={item.images || [item.image]}
              style={[styles.image, item.contain && { backgroundColor: '#fff' }]}
              resizeMode={item.contain ? 'contain' : 'cover'}
            />
            <View style={{ flex: 1, marginLeft: 10 }}>
              <Text numberOfLines={2} style={{ color: colors.text, fontWeight: '800', fontSize: fs(13) }}>{item.name}</Text>
              {item.size ? <Text style={{ color: colors.subText, fontSize: fs(11) }}>Size: {item.size}</Text> : null}
              <Text style={{ color: colors.green, fontWeight: '800', fontSize: fs(13), marginTop: 2 }}>
                {formatPrice(item.price)}
              </Text>
              {/* quantity up / down (down to 0 removes the item) */}
              <View style={{ marginTop: 8 }}>
                <QtyStepper value={item.qty} onMinus={() => changeQty(item.key, -1)} onPlus={() => changeQty(item.key, 1)} />
              </View>
            </View>

            <View style={{ alignItems: 'flex-end', justifyContent: 'space-between', alignSelf: 'stretch' }}>
              <TouchableOpacity onPress={() => removeFromCart(item.key)} hitSlop={10}>
                <Ionicons name="trash-outline" size={22} color="#D32F2F" />
              </TouchableOpacity>
              <Text style={{ color: colors.text, fontWeight: '900', fontSize: fs(12) }}>
                {formatPrice(item.price * item.qty)}
              </Text>
            </View>
          </View>
        )}
        ListFooterComponent={
          cart.length > 0 ? (
            <View>
              <BudgetNote cartTotal={subtotal} budget={budget} />

              <View style={[styles.totals, { backgroundColor: colors.card }]}>
                {totalRow('Subtotal', formatPrice(subtotal))}
                {totalRow('Discount (20%)', discount > 0 ? '- ' + formatPrice(discount) : 'Rs. 0', false, discount > 0 ? colors.green : undefined)}
                {totalRow('Final Amount', formatPrice(total), true, colors.green)}
                {discount === 0 && (
                  <Text style={{ color: colors.subText, fontSize: fs(11), marginTop: 6 }}>
                    Spend more than {formatPrice(DISCOUNT_LIMIT)} to get 20% off
                    {subtotal > 0 ? ` (add ${formatPrice(DISCOUNT_LIMIT - subtotal + 1)} more)` : ''}
                  </Text>
                )}
              </View>

              <TouchableOpacity
                style={[styles.checkout, { backgroundColor: colors.green }]}
                onPress={() => navigation.navigate('Checkout')}
              >
                <Text style={{ color: '#fff', fontWeight: '900', fontSize: fs(14) }}>PROCEED TO CHECKOUT</Text>
              </TouchableOpacity>

              <TouchableOpacity style={styles.clear} onPress={clearCart}>
                <Text style={{ color: colors.subText, fontSize: fs(12), textDecorationLine: 'underline' }}>Clear cart</Text>
              </TouchableOpacity>
            </View>
          ) : null
        }
      />
    </Screen>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', padding: 8, borderRadius: 8, marginBottom: 10, elevation: 2 },
  image: { width: 76, height: 90, borderRadius: 6 },
  totals: { padding: 12, borderRadius: 8, marginTop: 6 },
  totalRow: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 4 },
  checkout: { marginTop: 14, paddingVertical: 13, borderRadius: 24, alignItems: 'center' },
  clear: { alignItems: 'center', marginTop: 14 },
});
