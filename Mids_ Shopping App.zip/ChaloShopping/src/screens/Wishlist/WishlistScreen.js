// WishlistScreen.js
// Products saved with the heart icon. Each one can be moved straight into the cart
// (the Login screen opens first if needed) or removed with the heart.

import React from 'react';
import { FlatList, View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import Header from '../../components/Header';
import BackRow from '../../components/BackRow';
import Screen from '../../components/Screen';
import SafeImage from '../../components/SafeImage';
import EmptyState from '../../components/EmptyState';
import { useApp } from '../../context/AppContext';
import { useTheme } from '../../theme/ThemeContext';
import { formatPrice } from '../../utils/pricing';

export default function WishlistScreen({ navigation }) {
  const { colors, fs } = useTheme();
  const { wishlist, toggleWishlist, addToCart, requireLogin } = useApp();

  // add to cart (login needed), then remove from the wishlist
  const moveToCart = (product) => {
    const size = product.category === 'clothes' ? 'M' : undefined;
    if (!requireLogin(navigation, { type: 'add', product, size, qty: 1 })) return;
    addToCart(product, size, 1);
    toggleWishlist(product); // it was in the list, so this removes it
  };

  return (
    <Screen>
      <Header />
      <BackRow title="Wish List" />

      <FlatList
        data={wishlist}
        keyExtractor={(item) => item.id}
        contentContainerStyle={{ padding: 10, paddingBottom: 30 }}
        ListEmptyComponent={
          <EmptyState
            icon="heart-outline"
            title="Your wishlist is empty"
            subtitle="Tap the heart on any product to save it here"
            buttonLabel="Browse Categories"
            onPress={() => navigation.navigate('Categories')}
          />
        }
        renderItem={({ item }) => (
          <TouchableOpacity
            activeOpacity={0.9}
            style={[styles.row, { backgroundColor: colors.card }]}
            onPress={() => navigation.navigate('ProductDetails', { product: item })}
          >
            <SafeImage
              uris={item.images || [item.image]}
              style={[styles.image, item.contain && { backgroundColor: '#fff' }]}
              resizeMode={item.contain ? 'contain' : 'cover'}
            />
            <View style={{ flex: 1, marginLeft: 10 }}>
              <Text numberOfLines={2} style={[styles.name, { color: colors.text, fontSize: fs(14) }]}>{item.name}</Text>
              <Text style={[styles.price, { color: colors.green, fontSize: fs(14) }]}>{formatPrice(item.price)}</Text>
              <TouchableOpacity style={[styles.moveBtn, { backgroundColor: colors.primary }]} onPress={() => moveToCart(item)}>
                <Ionicons name="cart-outline" size={16} color="#fff" />
                <Text style={{ color: '#fff', fontWeight: '800', marginLeft: 6, fontSize: fs(11) }}>Move to Cart</Text>
              </TouchableOpacity>
            </View>
            <TouchableOpacity onPress={() => toggleWishlist(item)} hitSlop={10}>
              <Ionicons name="heart" size={26} color={colors.primary} />
            </TouchableOpacity>
          </TouchableOpacity>
        )}
      />
    </Screen>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', padding: 8, borderRadius: 8, marginBottom: 10, elevation: 2 },
  image: { width: 80, height: 90, borderRadius: 6 },
  name: { fontWeight: '800' },
  price: { fontWeight: '800', marginTop: 4 },
  moveBtn: {
    flexDirection: 'row', alignItems: 'center', alignSelf: 'flex-start',
    marginTop: 8, paddingHorizontal: 12, paddingVertical: 6, borderRadius: 16,
  },
});
