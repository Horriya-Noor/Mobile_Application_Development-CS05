// OrderSuccessScreen.js
// "Order Placed Successfully!" with confetti that falls for about 3 seconds,
// the order number, the amount payable and buttons to see the order or keep shopping.

import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import ConfettiCannon from 'react-native-confetti-cannon';
import { Ionicons } from '@expo/vector-icons';
import Screen from '../../components/Screen';
import { formatPrice } from '../../utils/pricing';
import { useTheme, HEADING_FONT } from '../../theme/ThemeContext';

export default function OrderSuccessScreen({ navigation, route }) {
  const { colors, fs } = useTheme();
  const total = route.params?.total || 0;
  const orderId = route.params?.orderId;

  // go back to Home and clear the history so back does not return to checkout
  const continueShopping = () => navigation.reset({ index: 0, routes: [{ name: 'Main' }] });

  // open the orders list (Home stays underneath)
  const viewOrders = () =>
    navigation.reset({ index: 1, routes: [{ name: 'Main' }, { name: 'MyOrders' }] });

  return (
    <Screen bottom>
      <View style={styles.center}>
        <Ionicons name="checkmark-circle" size={96} color={colors.green} />
        <Text style={[styles.title, { color: colors.text, fontSize: fs(24) }]}>🎉 Order Placed Successfully! 🎉</Text>
        {orderId ? (
          <Text style={{ color: colors.subText, fontSize: fs(13), marginTop: 10 }}>Order No. {orderId}</Text>
        ) : null}
        <Text style={{ color: colors.text, fontSize: fs(15), fontWeight: '800', marginTop: 6 }}>
          Amount payable: {formatPrice(total)}
        </Text>

        <TouchableOpacity style={[styles.button, { backgroundColor: colors.primary }]} onPress={continueShopping}>
          <Text style={{ color: '#fff', fontWeight: '900', fontSize: fs(14) }}>Continue Shopping</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.outline, { borderColor: colors.primary }]} onPress={viewOrders}>
          <Text style={{ color: colors.primary, fontWeight: '900', fontSize: fs(14) }}>View My Orders</Text>
        </TouchableOpacity>
      </View>

      {/* confetti shoots from the top of the screen once */}
      <ConfettiCannon count={180} origin={{ x: -10, y: 0 }} fadeOut autoStart fallSpeed={2500} />
    </Screen>
  );
}

const styles = StyleSheet.create({
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 24 },
  title: { fontFamily: HEADING_FONT, textAlign: 'center', marginTop: 16 },
  button: { marginTop: 30, paddingHorizontal: 32, paddingVertical: 13, borderRadius: 26 },
  outline: { marginTop: 12, paddingHorizontal: 32, paddingVertical: 11, borderRadius: 26, borderWidth: 2 },
});
