// ChaloSmartScreen.js
// "Shop Within Your Budget": set a budget, see only the products that fit,
// and get warned when the cart goes over the budget.

import React, { useState } from 'react';
import { FlatList, View, Text, TextInput, TouchableOpacity, ScrollView, StyleSheet } from 'react-native';
import Header from '../../components/Header';
import BackRow from '../../components/BackRow';
import Screen from '../../components/Screen';
import SafeImage from '../../components/SafeImage';
import BudgetNote from '../../components/BudgetNote';
import { PRODUCTS } from '../../data/products';
import { useApp } from '../../context/AppContext';
import { useTheme } from '../../theme/ThemeContext';
import { calcTotals, formatPrice } from '../../utils/pricing';

// price ranges used to group products (min is not included, max is)
const RANGES = [
  { key: 'all', label: 'All', min: -1, max: Infinity },
  { key: 'u1', label: 'Under Rs. 1,000', min: -1, max: 1000 },
  { key: 'r2', label: 'Rs. 1,000–2,000', min: 1000, max: 2000 },
  { key: 'r3', label: 'Rs. 2,000–3,000', min: 2000, max: 3000 },
];

export default function ChaloSmartScreen({ navigation }) {
  const { colors, fs } = useTheme();
  const { budget, setBudget, cart, addToCart, requireLogin } = useApp();

  const [input, setInput] = useState(budget ? String(budget) : '');
  const [range, setRange] = useState('all');

  // how much is already in the cart and how much budget is left
  const { subtotal } = calcTotals(cart);
  const remaining = budget - subtotal;

  const applyBudget = () => {
    const amount = parseInt(input, 10);
    setBudget(amount > 0 ? amount : 0);
  };

  // products that fit in the budget and in the chosen price range, cheapest first
  const r = RANGES.find((x) => x.key === range);
  const list = PRODUCTS.filter(
    (p) => budget > 0 && p.price <= budget && p.price > r.min && p.price <= r.max
  ).sort((a, b) => a.price - b.price);

  // ADD button (login first if needed, then the product is added automatically)
  const onAdd = (product) => {
    const size = product.category === 'clothes' ? 'M' : undefined;
    if (requireLogin(navigation, { type: 'add', product, size, qty: 1 })) addToCart(product, size, 1);
  };

  const header = (
    <View>
      <Text style={[styles.title, { color: colors.text, fontSize: fs(20) }]}>🎯 ChaloSmart</Text>
      <Text style={{ color: colors.subText, fontSize: fs(12), marginBottom: 12 }}>Apni Pasand, Apne Budget Mein!</Text>

      {/* set budget */}
      <View style={styles.budgetRow}>
        <TextInput
          value={input}
          onChangeText={setInput}
          keyboardType="numeric"
          placeholder="Enter budget e.g. 3000"
          placeholderTextColor={colors.subText}
          style={[styles.input, { backgroundColor: colors.inputBg, borderColor: colors.border, color: colors.text, fontSize: fs(14) }]}
        />
        <TouchableOpacity style={[styles.setBtn, { backgroundColor: colors.primary }]} onPress={applyBudget}>
          <Text style={{ color: '#fff', fontWeight: '900', fontSize: fs(13) }}>SET</Text>
        </TouchableOpacity>
      </View>

      {budget > 0 && (
        <View>
          <Text style={{ color: colors.text, fontSize: fs(13), fontWeight: '700' }}>
            Budget: {formatPrice(budget)}   |   In cart: {formatPrice(subtotal)}
          </Text>
          {remaining >= 0 && (
            <Text style={{ color: colors.green, fontSize: fs(13), fontWeight: '800', marginTop: 2 }}>
              You can still afford {formatPrice(remaining)} more
            </Text>
          )}
          <BudgetNote cartTotal={subtotal} budget={budget} />

          {/* price range chips */}
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginVertical: 8 }}>
            {RANGES.map((x) => (
              <TouchableOpacity
                key={x.key}
                onPress={() => setRange(x.key)}
                style={[styles.chip, { backgroundColor: range === x.key ? colors.primary : colors.chip }]}
              >
                <Text style={{ color: '#fff', fontWeight: '700', fontSize: fs(11) }}>{x.label}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>
      )}
    </View>
  );

  return (
    <Screen>
      <Header />
      <BackRow title="Budget Mode" />

      <FlatList
        data={list}
        keyExtractor={(item) => item.id}
        contentContainerStyle={{ padding: 12, paddingBottom: 30 }}
        keyboardShouldPersistTaps="handled"
        ListHeaderComponent={header}
        ListEmptyComponent={
          <Text style={{ textAlign: 'center', color: colors.subText, marginTop: 30, fontSize: fs(13) }}>
            {budget > 0 ? 'No products in this range' : 'Set a budget to see products you can afford'}
          </Text>
        }
        renderItem={({ item }) => {
          const within = item.price <= remaining; // simple smart logic
          return (
            <TouchableOpacity
              activeOpacity={0.9}
              style={[styles.row, { backgroundColor: colors.card }]}
              onPress={() => navigation.navigate('ProductDetails', { product: item })}
            >
              <SafeImage uris={item.images} style={styles.image} />
              <View style={{ flex: 1, marginLeft: 10 }}>
                <Text numberOfLines={1} style={{ color: colors.text, fontWeight: '800', fontSize: fs(13) }}>{item.name}</Text>
                <Text style={{ color: colors.green, fontWeight: '800', fontSize: fs(13) }}>{formatPrice(item.price)}</Text>
                <Text style={{ fontSize: fs(11), fontWeight: '800', color: within ? colors.green : '#D32F2F', marginTop: 2 }}>
                  {within ? 'Within Budget ✓' : 'Over Budget'}
                  {item.deal ? '   🔥 Best Deal' : ''}
                </Text>
              </View>
              <TouchableOpacity style={[styles.addBtn, { backgroundColor: colors.primary }]} onPress={() => onAdd(item)}>
                <Text style={{ color: '#fff', fontWeight: '800', fontSize: fs(11) }}>ADD</Text>
              </TouchableOpacity>
            </TouchableOpacity>
          );
        }}
      />
    </Screen>
  );
}

const styles = StyleSheet.create({
  title: { fontWeight: '900' },
  budgetRow: { flexDirection: 'row', marginBottom: 10 },
  input: { flex: 1, borderWidth: 1.5, borderRadius: 8, paddingHorizontal: 12, paddingVertical: 8 },
  setBtn: { marginLeft: 10, paddingHorizontal: 20, borderRadius: 8, justifyContent: 'center' },
  chip: { paddingHorizontal: 14, paddingVertical: 6, borderRadius: 16, marginRight: 8 },
  row: { flexDirection: 'row', alignItems: 'center', padding: 8, borderRadius: 8, marginBottom: 10, elevation: 2 },
  image: { width: 60, height: 70, borderRadius: 6 },
  addBtn: { paddingHorizontal: 16, paddingVertical: 8, borderRadius: 16 },
});
