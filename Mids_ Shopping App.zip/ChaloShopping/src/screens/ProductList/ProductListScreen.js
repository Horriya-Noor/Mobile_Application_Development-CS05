// ProductListScreen.js
// Grid of products for a chosen sub category, or for a search from the toolbar.
// Params: category, gender, sub, search
// Features: search box, sort by price (Popular / Low to High / High to Low), sub category chips.

import React, { useEffect, useState } from 'react';
import { FlatList, View, Text, TextInput, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import Header from '../../components/Header';
import BackRow from '../../components/BackRow';
import Screen from '../../components/Screen';
import ProductCard from '../../components/ProductCard';
import EmptyState from '../../components/EmptyState';
import { PRODUCTS, SUBCATEGORIES } from '../../data/products';
import { useTheme, HEADING_FONT } from '../../theme/ThemeContext';

// the three sort choices
const SORTS = ['Popular', 'Price: Low to High', 'Price: High to Low'];

export default function ProductListScreen({ route }) {
  const { colors, fs } = useTheme();
  const { category, gender, sub, search } = route.params || {};

  const [query, setQuery] = useState(search || '');
  const [activeSub, setActiveSub] = useState(sub);
  const [sortIndex, setSortIndex] = useState(0);

  // when the screen is opened again with new options (menu / toolbar search), update it
  useEffect(() => {
    setQuery(search || '');
    setActiveSub(sub);
    setSortIndex(0);
  }, [search, sub, category, gender]);

  // ----- choose which products to show -----
  let list = PRODUCTS.filter((p) => {
    if (category && p.category !== category) return false;
    if (gender && p.gender !== gender) return false;
    if (activeSub && p.sub !== activeSub) return false;
    const q = query.trim().toLowerCase();
    return !q || p.name.toLowerCase().includes(q) || p.brand.toLowerCase().includes(q);
  });

  // ----- sort by price -----
  if (sortIndex === 1) list = [...list].sort((a, b) => a.price - b.price);
  if (sortIndex === 2) list = [...list].sort((a, b) => b.price - a.price);

  const chips = category && gender && SUBCATEGORIES[category] ? SUBCATEGORIES[category][gender] : [];
  const title = !category ? 'All Products' : gender === 'male' ? "Mens' Section" : "Womens' Section";
  const barTitle = !category ? 'Products' : category.charAt(0).toUpperCase() + category.slice(1);

  return (
    <Screen>
      <Header />
      <BackRow title={barTitle} />

      <FlatList
        data={list}
        keyExtractor={(item) => item.id}
        numColumns={2}
        contentContainerStyle={{ padding: 8, paddingBottom: 30 }}
        keyboardShouldPersistTaps="handled"
        ListHeaderComponent={
          <View>
            {/* search inside this list */}
            <View style={[styles.search, { backgroundColor: colors.card, borderColor: colors.chip }]}>
              <Ionicons name="search" size={18} color={colors.subText} />
              <TextInput
                value={query}
                onChangeText={setQuery}
                placeholder="Search in this list"
                placeholderTextColor={colors.subText}
                style={[styles.searchInput, { color: colors.text, fontSize: fs(13) }]}
              />
              {query ? (
                <TouchableOpacity onPress={() => setQuery('')} hitSlop={8}>
                  <Ionicons name="close-circle" size={18} color={colors.subText} />
                </TouchableOpacity>
              ) : null}
            </View>

            <Text style={[styles.title, { color: colors.green, fontSize: fs(24) }]}>{title}</Text>

            {/* sub category chips (tap again to clear) */}
            {chips.length > 0 && (
              <View style={styles.chips}>
                {chips.map((c) => {
                  const active = activeSub === c.key;
                  return (
                    <TouchableOpacity
                      key={c.key}
                      onPress={() => setActiveSub(active ? undefined : c.key)}
                      style={[styles.chip, { backgroundColor: active ? colors.primary : colors.chip }]}
                    >
                      <Text style={{ color: '#fff', fontWeight: '700', fontSize: fs(11) }}>{c.label}</Text>
                    </TouchableOpacity>
                  );
                })}
              </View>
            )}

            {/* sort by price */}
            <View style={styles.sortRow}>
              <Ionicons name="options-outline" size={18} color={colors.text} />
              <Text style={{ color: colors.text, fontSize: fs(12), marginLeft: 6, marginRight: 4 }}>Sort:</Text>
              {SORTS.map((s, i) => (
                <TouchableOpacity
                  key={s}
                  onPress={() => setSortIndex(i)}
                  style={[styles.sortChip, { backgroundColor: sortIndex === i ? colors.primary : colors.card }]}
                >
                  <Text style={{ color: sortIndex === i ? '#fff' : colors.text, fontSize: fs(10), fontWeight: '700' }}>
                    {s}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>

            <Text style={{ color: colors.subText, fontSize: fs(11), marginLeft: 6, marginBottom: 4 }}>
              {list.length} {list.length === 1 ? 'item' : 'items'}
            </Text>
          </View>
        }
        renderItem={({ item }) => <ProductCard product={item} />}
        ListEmptyComponent={
          <EmptyState icon="search-outline" title="No products found" subtitle="Try a different word or clear the filters" />
        }
      />
    </Screen>
  );
}

const styles = StyleSheet.create({
  search: { flexDirection: 'row', alignItems: 'center', borderWidth: 1, borderRadius: 20, paddingHorizontal: 12, height: 38, margin: 6 },
  searchInput: { flex: 1, marginLeft: 8, padding: 0 },
  title: { fontFamily: HEADING_FONT, marginLeft: 6, marginTop: 4 },
  chips: { flexDirection: 'row', marginVertical: 8, marginLeft: 4 },
  chip: { paddingHorizontal: 14, paddingVertical: 5, borderRadius: 14, marginRight: 8 },
  sortRow: { flexDirection: 'row', alignItems: 'center', flexWrap: 'wrap', marginLeft: 4, marginBottom: 6 },
  sortChip: { paddingHorizontal: 9, paddingVertical: 4, borderRadius: 12, marginRight: 6, marginVertical: 2 },
});
