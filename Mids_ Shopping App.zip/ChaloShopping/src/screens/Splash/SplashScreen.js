// SplashScreen.js
// First screen: pink background, white splash shape, logo space, app name and the offer.
// After 2.5 seconds it moves to Home automatically (login is only asked for later,
// when the user tries to add to cart or opens Cart / Profile).

import React, { useEffect, useRef } from 'react';
import { View, Text, Animated, StyleSheet } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { LogoFull } from '../../components/AppLogo';
import { useTheme, HEADING_FONT } from '../../theme/ThemeContext';

export default function SplashScreen({ navigation }) {
  const { colors, fs } = useTheme();
  const fade = useRef(new Animated.Value(0)).current;
  const scale = useRef(new Animated.Value(0.85)).current;

  useEffect(() => {
    // logo + name fade and grow in once
    Animated.parallel([
      Animated.timing(fade, { toValue: 1, duration: 700, useNativeDriver: true }),
      Animated.spring(scale, { toValue: 1, useNativeDriver: true }),
    ]).start();

    // go to Home after 2.5 seconds
    const timer = setTimeout(() => navigation.replace('Main'), 2500);
    return () => clearTimeout(timer);
  }, []);

  return (
    <View style={[styles.container, { backgroundColor: colors.primary }]}>
      <StatusBar style="light" />

      {/* the white "splash" shape is built from a few overlapping circles */}
      <View style={styles.blobBig} />
      <View style={[styles.blobSmall, { top: '24%', left: '8%', width: 70, height: 70 }]} />
      <View style={[styles.blobSmall, { top: '60%', right: '4%', width: 90, height: 90 }]} />
      <View style={[styles.blobSmall, { top: '70%', left: '14%', width: 40, height: 40 }]} />
      <View style={[styles.blobSmall, { top: '18%', right: '14%', width: 30, height: 30 }]} />

      <Animated.View style={{ alignItems: 'center', opacity: fade, transform: [{ scale }] }}>
        <LogoFull size={1.1} />
        <View style={styles.offer}>
          <Text style={[styles.offerText, { fontSize: fs(18) }]}>20% OFF — Limited Stock!</Text>
        </View>
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  blobBig: { position: 'absolute', width: 340, height: 340, borderRadius: 170, backgroundColor: '#FFDDE0' },
  blobSmall: { position: 'absolute', borderRadius: 100, backgroundColor: '#FFDDE0' },
  offer: { marginTop: 18, backgroundColor: '#FFF200', paddingHorizontal: 16, paddingVertical: 6, borderRadius: 20 },
  offerText: { fontFamily: HEADING_FONT, color: '#2B2B2B' },
});
