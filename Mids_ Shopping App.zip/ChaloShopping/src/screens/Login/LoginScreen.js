// LoginScreen.js
// Login and Sign up in one screen (switch with the link at the bottom).
// Email + password are checked before sending (valid email, 6+ characters, matching
// confirm password on sign up). Users are saved in AsyncStorage (demo, no real backend).
// If the user came here from "Add to Cart", the product is added automatically after login.

import React, { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet, ScrollView, KeyboardAvoidingView, Platform,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import Screen from '../../components/Screen';
import { LogoFull } from '../../components/AppLogo';
import { useApp } from '../../context/AppContext';
import { useTheme } from '../../theme/ThemeContext';

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export default function LoginScreen({ navigation }) {
  const { login, signup, runPending, notify } = useApp();
  const { colors, fs } = useTheme();

  const [mode, setMode] = useState('login'); // 'login' or 'signup'
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [remember, setRemember] = useState(true);
  const [errors, setErrors] = useState({}); // one message per field
  const [busy, setBusy] = useState(false);

  // ----- validation: returns an object with an error text for each wrong field -----
  const validate = () => {
    const e = {};
    if (mode === 'signup' && name.trim().length < 2) e.name = 'Enter your name';
    if (!EMAIL_PATTERN.test(email.trim())) e.email = 'Enter a valid email like name@mail.com';
    if (password.length < 6) e.password = 'Password must be at least 6 characters';
    if (mode === 'signup' && confirm !== password) e.confirm = 'Passwords do not match';
    return e;
  };

  const submit = async () => {
    const e = validate();
    setErrors(e);
    if (Object.keys(e).length > 0) return;

    setBusy(true);
    const cleanEmail = email.trim().toLowerCase();
    const result =
      mode === 'login'
        ? await login(cleanEmail, password, remember)
        : await signup(name.trim(), cleanEmail, password, remember);
    setBusy(false);

    if (result) {
      setErrors({ form: result }); // result is an error message from the server logic
      return;
    }

    // ----- logged in: finish what the user wanted to do (e.g. add the product) -----
    const pending = runPending();
    if (pending && pending.goCart) navigation.navigate('Main', { screen: 'Cart' });
    else if (navigation.canGoBack()) navigation.goBack();
    else navigation.replace('Main');
  };

  const switchMode = () => {
    setMode(mode === 'login' ? 'signup' : 'login');
    setErrors({});
  };

  const inputStyle = (field) => [
    styles.input,
    { backgroundColor: colors.inputBg, borderColor: errors[field] ? '#B00020' : colors.border, color: colors.text, fontSize: fs(14) },
  ];
  const errorText = (field) =>
    errors[field] ? <Text style={[styles.error, { fontSize: fs(11) }]}>{errors[field]}</Text> : null;

  return (
    <Screen bottom>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
          {/* close button: go back without logging in */}
          <TouchableOpacity style={styles.close} onPress={() => (navigation.canGoBack() ? navigation.goBack() : navigation.replace('Main'))}>
            <Ionicons name="close" size={26} color={colors.text} />
          </TouchableOpacity>

          <LogoFull size={0.8} />
          <Text style={[styles.tagline, { color: colors.text, fontSize: fs(16) }]}>
            {mode === 'login' ? 'Welcome back!' : 'Create your account'}
          </Text>

          {mode === 'signup' && (
            <>
              <TextInput
                style={inputStyle('name')}
                placeholder="Full name"
                placeholderTextColor={colors.subText}
                value={name}
                onChangeText={setName}
              />
              {errorText('name')}
            </>
          )}

          <TextInput
            style={inputStyle('email')}
            placeholder="Email"
            placeholderTextColor={colors.subText}
            autoCapitalize="none"
            keyboardType="email-address"
            value={email}
            onChangeText={setEmail}
          />
          {errorText('email')}

          <View>
            <TextInput
              style={inputStyle('password')}
              placeholder="Password"
              placeholderTextColor={colors.subText}
              secureTextEntry={!showPass}
              value={password}
              onChangeText={setPassword}
            />
            <TouchableOpacity style={styles.eye} onPress={() => setShowPass(!showPass)}>
              <Ionicons name={showPass ? 'eye-off-outline' : 'eye-outline'} size={22} color={colors.text} />
            </TouchableOpacity>
          </View>
          {errorText('password')}

          {mode === 'signup' && (
            <>
              <TextInput
                style={[inputStyle('confirm'), { marginTop: 14 }]}
                placeholder="Confirm password"
                placeholderTextColor={colors.subText}
                secureTextEntry={!showPass}
                value={confirm}
                onChangeText={setConfirm}
              />
              {errorText('confirm')}
            </>
          )}

          <View style={styles.rememberRow}>
            <TouchableOpacity style={styles.remember} onPress={() => setRemember(!remember)}>
              <Ionicons name={remember ? 'checkbox' : 'square-outline'} size={22} color={colors.text} />
              <Text style={[styles.rememberText, { color: colors.text, fontSize: fs(12) }]}>Remember Me</Text>
            </TouchableOpacity>
            {mode === 'login' && (
              <TouchableOpacity onPress={() => notify('Demo app: no password reset')}>
                <Text style={[styles.forget, { color: colors.green, fontSize: fs(12) }]}>Forget Password?</Text>
              </TouchableOpacity>
            )}
          </View>

          {errors.form ? <Text style={[styles.error, { fontSize: fs(12), marginTop: 10 }]}>{errors.form}</Text> : null}

          <TouchableOpacity
            style={[styles.button, { backgroundColor: colors.primary, opacity: busy ? 0.6 : 1 }]}
            onPress={submit}
            disabled={busy}
          >
            <Text style={[styles.buttonText, { fontSize: fs(16) }]}>{mode === 'login' ? 'LOG IN' : 'SIGN UP'}</Text>
          </TouchableOpacity>

          <View style={styles.dividerRow}>
            <View style={[styles.line, { backgroundColor: colors.subText }]} />
            <Text style={[styles.dividerText, { color: colors.subText, fontSize: fs(12) }]}>or continue with</Text>
            <View style={[styles.line, { backgroundColor: colors.subText }]} />
          </View>

          {/* social buttons are just for the design (demo) */}
          <View style={styles.socialRow}>
            <TouchableOpacity style={styles.social} onPress={() => notify('Demo only: use email login')}>
              <Ionicons name="logo-google" size={28} color="#DB4437" />
            </TouchableOpacity>
            <TouchableOpacity style={styles.social} onPress={() => notify('Demo only: use email login')}>
              <Ionicons name="logo-facebook" size={28} color="#1877F2" />
            </TouchableOpacity>
          </View>

          <View style={styles.switchRow}>
            <Text style={{ color: colors.text, fontSize: fs(13) }}>
              {mode === 'login' ? "Don't have an account? " : 'Already have an account? '}
            </Text>
            <TouchableOpacity onPress={switchMode}>
              <Text style={[styles.link, { color: colors.green, fontSize: fs(13) }]}>
                {mode === 'login' ? 'Sign Up' : 'Log In'}
              </Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </Screen>
  );
}

const styles = StyleSheet.create({
  content: { padding: 24, alignItems: 'stretch' },
  close: { alignSelf: 'flex-end' },
  tagline: { fontWeight: '800', textAlign: 'center', marginVertical: 16 },
  input: { borderWidth: 1.5, borderRadius: 8, paddingHorizontal: 12, paddingVertical: 10, marginTop: 14 },
  error: { color: '#B00020', marginTop: 4, fontWeight: '600' },
  eye: { position: 'absolute', right: 12, top: 24 },
  rememberRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 14 },
  remember: { flexDirection: 'row', alignItems: 'center' },
  rememberText: { marginLeft: 6, fontWeight: '700' },
  forget: { fontWeight: '800' },
  button: { marginTop: 20, paddingVertical: 12, borderRadius: 8, borderWidth: 2, borderColor: '#222', alignItems: 'center' },
  buttonText: { color: '#fff', fontWeight: '800', letterSpacing: 1 },
  dividerRow: { flexDirection: 'row', alignItems: 'center', marginTop: 22 },
  line: { flex: 1, height: 1 },
  dividerText: { marginHorizontal: 10 },
  socialRow: { flexDirection: 'row', justifyContent: 'center', marginTop: 16 },
  social: {
    width: 56, height: 56, borderRadius: 28, backgroundColor: '#fff', marginHorizontal: 12,
    alignItems: 'center', justifyContent: 'center', elevation: 4,
  },
  switchRow: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', marginTop: 20 },
  link: { fontWeight: '800', textDecorationLine: 'underline' },
});
