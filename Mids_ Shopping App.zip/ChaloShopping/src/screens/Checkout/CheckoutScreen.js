// CheckoutScreen.js
// Delivery details, payment choice, order summary and the amounts:
// subtotal, 20% discount (only above Rs. 1,200) and the final payable amount.
// Example: Rs. 1,500 -> Rs. 300 off -> Rs. 1,200 payable.
// "Place Order" saves the order (AsyncStorage) and empties the cart.

import React, { useState } from 'react';
import { ScrollView, View, Text, TextInput, TouchableOpacity, KeyboardAvoidingView, Platform, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import Screen from '../../components/Screen';
import BackRow from '../../components/BackRow';
import { useApp } from '../../context/AppContext';
import { useTheme } from '../../theme/ThemeContext';
import { calcTotals, formatPrice } from '../../utils/pricing';

const PAYMENTS = ['Cash on Delivery', 'Easypaisa / JazzCash', 'Debit / Credit Card'];

export default function CheckoutScreen({ navigation }) {
  const { colors, fs } = useTheme();
  const { user, cart, placeOrder, notify, play } = useApp();
  const { subtotal, discount, total } = calcTotals(cart);

  const [name, setName] = useState(user ? user.name : '');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [payment, setPayment] = useState(PAYMENTS[0]);
  const [errors, setErrors] = useState({});
  const [busy, setBusy] = useState(false);

  // ----- check the delivery details -----
  const validate = () => {
    const e = {};
    if (name.trim().length < 2) e.name = 'Enter your name';
    if (phone.replace(/\D/g, '').length < 10) e.phone = 'Enter a valid phone number';
    if (address.trim().length < 8) e.address = 'Enter your full address';
    return e;
  };

  // ----- Place Order: save the order, empty the cart, show the success screen -----
  const onPlaceOrder = async () => {
    if (cart.length === 0) {
      notify('Your cart is empty');
      return;
    }
    const e = validate();
    setErrors(e);
    if (Object.keys(e).length > 0) return;

    setBusy(true);
    const order = await placeOrder({ name: name.trim(), phone: phone.trim(), address: address.trim(), payment });
    play('success'); // sound plays once
    navigation.replace('OrderSuccess', { total: order.total, orderId: order.id });
  };

  // one line in the amounts box
  const line = (label, value, bold, color) => (
    <View style={styles.line}>
      <Text style={{ color: colors.text, fontSize: fs(14), fontWeight: bold ? '900' : '500' }}>{label}</Text>
      <Text style={{ color: color || colors.text, fontSize: fs(14), fontWeight: bold ? '900' : '600' }}>{value}</Text>
    </View>
  );

  const field = (key, value, setValue, placeholder, extra = {}) => (
    <View>
      <TextInput
        value={value}
        onChangeText={setValue}
        placeholder={placeholder}
        placeholderTextColor={colors.subText}
        style={[
          styles.input,
          { backgroundColor: colors.inputBg, color: colors.text, fontSize: fs(13), borderColor: errors[key] ? '#B00020' : colors.chip },
        ]}
        {...extra}
      />
      {errors[key] ? <Text style={styles.error}>{errors[key]}</Text> : null}
    </View>
  );

  return (
    <Screen bottom>
      <BackRow title="Checkout" />
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <ScrollView contentContainerStyle={{ padding: 12, paddingBottom: 30 }} keyboardShouldPersistTaps="handled">
          {/* delivery details */}
          <Text style={[styles.heading, { color: colors.text, fontSize: fs(16) }]}>Delivery Details</Text>
          <View style={[styles.box, { backgroundColor: colors.card }]}>
            {field('name', name, setName, 'Full name')}
            {field('phone', phone, setPhone, 'Phone number', { keyboardType: 'phone-pad' })}
            {field('address', address, setAddress, 'Full address with city', { multiline: true })}
          </View>

          {/* payment choice */}
          <Text style={[styles.heading, { color: colors.text, fontSize: fs(16) }]}>Payment Method</Text>
          <View style={[styles.box, { backgroundColor: colors.card }]}>
            {PAYMENTS.map((p) => (
              <TouchableOpacity key={p} style={styles.payRow} onPress={() => setPayment(p)}>
                <Ionicons name={payment === p ? 'radio-button-on' : 'radio-button-off'} size={22} color={colors.primary} />
                <Text style={{ color: colors.text, fontSize: fs(13), marginLeft: 10 }}>{p}</Text>
              </TouchableOpacity>
            ))}
          </View>

          {/* order summary */}
          <Text style={[styles.heading, { color: colors.text, fontSize: fs(16) }]}>Order Summary</Text>
          <View style={[styles.box, { backgroundColor: colors.card }]}>
            {cart.map((item) => (
              <View key={item.key} style={styles.line}>
                <Text numberOfLines={1} style={{ flex: 1, color: colors.text, fontSize: fs(13) }}>
                  {item.name}
                  {item.size ? ` (${item.size})` : ''} × {item.qty}
                </Text>
                <Text style={{ color: colors.text, fontSize: fs(13), fontWeight: '700' }}>
                  {formatPrice(item.price * item.qty)}
                </Text>
              </View>
            ))}
          </View>

          <View style={[styles.box, { backgroundColor: colors.card }]}>
            {line('Subtotal', formatPrice(subtotal))}
            {line('Discount (20%)', discount > 0 ? '- ' + formatPrice(discount) : 'Rs. 0', false, discount > 0 ? colors.green : undefined)}
            <View style={[styles.divider, { backgroundColor: colors.subText }]} />
            {line('Final Payable Amount', formatPrice(total), true, colors.green)}
          </View>

          <TouchableOpacity
            style={[styles.button, { backgroundColor: colors.green, opacity: busy ? 0.6 : 1 }]}
            onPress={onPlaceOrder}
            disabled={busy}
          >
            <Text style={{ color: '#fff', fontWeight: '900', fontSize: fs(15) }}>PLACE ORDER</Text>
          </TouchableOpacity>
        </ScrollView>
      </KeyboardAvoidingView>
    </Screen>
  );
}

const styles = StyleSheet.create({
  heading: { fontWeight: '900', marginBottom: 8, marginTop: 4 },
  box: { padding: 12, borderRadius: 8, marginBottom: 14, elevation: 2 },
  input: { borderWidth: 1, borderRadius: 8, paddingHorizontal: 12, paddingVertical: 9, marginBottom: 10 },
  error: { color: '#B00020', fontSize: 11, marginTop: -6, marginBottom: 8, fontWeight: '600' },
  payRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 7 },
  line: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 5 },
  divider: { height: 1, marginVertical: 6, opacity: 0.4 },
  button: { paddingVertical: 14, borderRadius: 26, alignItems: 'center', marginTop: 6 },
});
