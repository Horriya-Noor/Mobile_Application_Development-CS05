// ProductDetailsScreen.js
// Big picture, price, rating, description, size (clothes only), quantity and the
// Add to Cart / Shop Now buttons, plus "You may also like".
// If the user is not logged in, Add to Cart opens the Login screen first and the
// product is added automatically as soon as the login succeeds.

import React, { useEffect, useRef, useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import Header from '../../components/Header';
import BackRow from '../../components/BackRow';
import Screen from '../../components/Screen';
import SafeImage from '../../components/SafeImage';
import QtyStepper from '../../components/QtyStepper';
import ProductCard from '../../components/ProductCard';
import { PRODUCTS } from '../../data/products';
import { useApp } from '../../context/AppContext';
import { useTheme } from '../../theme/ThemeContext';
import { formatPrice } from '../../utils/pricing';

const SIZES = ['XS', 'S', 'M', 'L', 'XL'];

export default function ProductDetailsScreen({ route, navigation }) {
  const { product } = route.params;
  const { colors, fs } = useTheme();
  const { addToCart, requireLogin, toggleWishlist, isWished } = useApp();
  const scrollRef = useRef(null);

  const [size, setSize] = useState('M');
  const [qty, setQty] = useState(1);

  // a different product was opened: reset size, quantity and scroll to the top
  useEffect(() => {
    setSize('M');
    setQty(1);
    scrollRef.current?.scrollTo({ y: 0, animated: false });
  }, [product.id]);

  const showSizes = product.category === 'clothes';
  const chosenSize = showSizes ? size : undefined;
  const wished = isWished(product.id);

  // other products of the same kind
  const related = PRODUCTS.filter(
    (p) => p.id !== product.id && p.category === product.category && p.gender === product.gender
  ).slice(0, 6);

  // ----- Add to Cart: login first if needed (the product is added after login) -----
  const onAddToCart = () => {
    const pending = { type: 'add', product, size: chosenSize, qty };
    if (requireLogin(navigation, pending)) addToCart(product, chosenSize, qty);
  };

  // ----- Shop Now: same, then open the cart -----
  const onShopNow = () => {
    const pending = { type: 'add', product, size: chosenSize, qty, goCart: true };
    if (requireLogin(navigation, pending)) {
      addToCart(product, chosenSize, qty);
      navigation.navigate('Cart');
    }
  };

  return (
    <Screen>
      <Header />
      <ScrollView ref={scrollRef} showsVerticalScrollIndicator={false}>
        <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.chip }]}>
          <BackRow title={product.name} />

          {/* big picture with the wishlist heart */}
          <View>
            <SafeImage
              uris={product.images || [product.image]}
              style={[styles.image, product.contain && { backgroundColor: '#fff' }]}
              resizeMode={product.contain ? 'contain' : 'cover'}
              iconSize={60}
            />
            <TouchableOpacity style={styles.heart} onPress={() => toggleWishlist(product)}>
              <Ionicons name={wished ? 'heart' : 'heart-outline'} size={24} color={colors.primary} />
            </TouchableOpacity>
          </View>

          <View style={{ padding: 14 }}>
            <Text style={{ color: colors.text, fontSize: fs(17), fontWeight: '900' }}>{product.name}</Text>
            <Text style={[styles.brand, { color: colors.subText, fontSize: fs(12) }]}>
              Brand: <Text style={{ fontWeight: '800', color: colors.text }}>{product.brand}</Text>
            </Text>

            {/* price + rating */}
            <View style={styles.priceRow}>
              <Text style={[styles.price, { color: colors.green, fontSize: fs(20) }]}>{formatPrice(product.price)}</Text>
              <View style={styles.rating}>
                {[1, 2, 3, 4, 5].map((n) => (
                  <Ionicons
                    key={n}
                    name={n <= Math.round(product.rating || 4) ? 'star' : 'star-outline'}
                    size={16}
                    color="#F5B400"
                  />
                ))}
                <Text style={{ color: colors.subText, fontSize: fs(11), marginLeft: 5 }}>
                  {Number(product.rating || 4).toFixed(1)}
                  {product.ratingCount ? ` (${product.ratingCount})` : ''}
                </Text>
              </View>
            </View>

            {/* description */}
            <Text style={[styles.label, { color: colors.text, fontSize: fs(13), marginTop: 12 }]}>Description</Text>
            <Text style={{ color: colors.text, fontSize: fs(12), lineHeight: fs(18), marginTop: 4 }}>
              {product.description}
            </Text>

            {/* size chips (clothes only) */}
            {showSizes && (
              <View style={styles.block}>
                <Text style={[styles.label, { color: colors.text, fontSize: fs(13) }]}>Size</Text>
                <View style={styles.chipRow}>
                  {SIZES.map((s) => (
                    <TouchableOpacity
                      key={s}
                      onPress={() => setSize(s)}
                      style={[
                        styles.sizeChip,
                        { borderColor: colors.border },
                        size === s && { backgroundColor: colors.primary, borderColor: colors.primary },
                      ]}
                    >
                      <Text style={{ fontSize: fs(11), fontWeight: '800', color: size === s ? '#fff' : colors.text }}>{s}</Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </View>
            )}

            {/* quantity */}
            <View style={[styles.block, styles.qtyRow]}>
              <Text style={[styles.label, { color: colors.text, fontSize: fs(13) }]}>Quantity</Text>
              <QtyStepper value={qty} size={30} onMinus={() => setQty(Math.max(1, qty - 1))} onPlus={() => setQty(Math.min(10, qty + 1))} />
            </View>
            <Text style={{ color: colors.subText, fontSize: fs(11), marginTop: 6, textAlign: 'right' }}>
              Total: {formatPrice(product.price * qty)}
            </Text>

            {/* buttons */}
            <View style={styles.buttons}>
              <TouchableOpacity style={[styles.addBtn, { backgroundColor: colors.green }]} onPress={onAddToCart}>
                <Ionicons name="cart-outline" size={16} color="#fff" />
                <Text style={[styles.addText, { fontSize: fs(12) }]}>ADD TO CART</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.shopBtn, { borderColor: colors.border }]} onPress={onShopNow}>
                <Text style={[styles.shopText, { color: colors.text, fontSize: fs(12) }]}>SHOP NOW</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>

        {/* more products like this one */}
        {related.length > 0 && (
          <View style={{ marginBottom: 24 }}>
            <Text style={{ color: colors.text, fontWeight: '800', fontSize: fs(15), marginLeft: 14, marginBottom: 4 }}>
              You may also like
            </Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ paddingHorizontal: 6 }}>
              {related.map((p) => (
                <ProductCard key={p.id} product={p} style={{ width: 150, maxWidth: 150, flex: 0 }} />
              ))}
            </ScrollView>
          </View>
        )}
      </ScrollView>
    </Screen>
  );
}

const styles = StyleSheet.create({
  card: { margin: 10, borderRadius: 10, borderWidth: 1, overflow: 'hidden' },
  image: { width: '100%', height: 360 },
  heart: {
    position: 'absolute', top: 10, right: 10, backgroundColor: '#fff',
    width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center', elevation: 3,
  },
  brand: { marginTop: 4 },
  priceRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 8 },
  price: { fontWeight: '900' },
  rating: { flexDirection: 'row', alignItems: 'center' },
  label: { fontWeight: '800' },
  block: { marginTop: 14 },
  chipRow: { flexDirection: 'row', flexWrap: 'wrap', marginTop: 8 },
  sizeChip: { borderWidth: 1, borderRadius: 6, paddingHorizontal: 14, paddingVertical: 6, marginRight: 8 },
  qtyRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  buttons: { flexDirection: 'row', justifyContent: 'center', marginTop: 18 },
  addBtn: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 24, paddingVertical: 11, borderRadius: 22, marginRight: 12 },
  addText: { color: '#fff', fontWeight: '900', marginLeft: 6 },
  shopBtn: { paddingHorizontal: 28, paddingVertical: 11, borderRadius: 22, borderWidth: 1.5 },
  shopText: { fontWeight: '900' },
});
