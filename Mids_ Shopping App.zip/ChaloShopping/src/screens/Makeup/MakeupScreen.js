// MakeupScreen.js
// Displays ONLY makeup/beauty products.

import React, { useEffect, useState } from 'react';
import {
  FlatList,
  View,
  Text,
  ActivityIndicator,
  TouchableOpacity,
  StyleSheet,
} from 'react-native';

import { Ionicons } from '@expo/vector-icons';
import Header from '../../components/Header';
import BackRow from '../../components/BackRow';
import Screen from '../../components/Screen';
import ProductCard from '../../components/ProductCard';
import { fetchMakeupProducts } from '../../utils/api';
import { useTheme, HEADING_FONT } from '../../theme/ThemeContext';

export default function MakeupScreen() {
  const { colors, fs } = useTheme();

  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState('');

  const loadProducts = async () => {
    try {
      setError('');

      const data = await fetchMakeupProducts();

      setProducts(data);
    } catch (e) {
      console.log('Makeup API Error:', e);
      setError(
        'Could not load makeup products. Check your internet connection.'
      );
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  // Load makeup products when screen opens
  useEffect(() => {
    loadProducts();
  }, []);

  // Retry
  const retry = () => {
    setLoading(true);
    loadProducts();
  };

  return (
    <Screen>
      <Header />

      <BackRow title="Makeup" />

      {loading ? (
        <View style={styles.center}>
          <ActivityIndicator
            size="large"
            color={colors.primary}
          />

          <Text
            style={{
              color: colors.subText,
              marginTop: 10,
              fontSize: fs(12),
            }}
          >
            Loading makeup products…
          </Text>
        </View>
      ) : error ? (
        <View style={styles.errorContainer}>
          <Ionicons
            name="cloud-offline-outline"
            size={54}
            color={colors.primary}
          />

          <Text
            style={{
              color: colors.text,
              fontSize: fs(14),
              textAlign: 'center',
              marginTop: 10,
            }}
          >
            {error}
          </Text>

          <TouchableOpacity
            style={[
              styles.retry,
              { backgroundColor: colors.primary },
            ]}
            onPress={retry}
          >
            <Text
              style={{
                color: '#fff',
                fontWeight: '800',
                fontSize: fs(13),
              }}
            >
              Try again
            </Text>
          </TouchableOpacity>
        </View>
      ) : (
        <FlatList
          data={products}
          keyExtractor={(item) => String(item.id)}
          numColumns={2}
          contentContainerStyle={{
            padding: 8,
            paddingBottom: 30,
          }}
          refreshing={refreshing}
          onRefresh={() => {
            setRefreshing(true);
            loadProducts();
          }}
          ListHeaderComponent={
            <View>
              <Text
                style={[
                  styles.title,
                  {
                    color: colors.green,
                    fontSize: fs(24),
                  },
                ]}
              >
                Makeup
              </Text>

              <Text
                style={{
                  color: colors.subText,
                  fontSize: fs(12),
                  marginLeft: 8,
                  marginTop: 3,
                  marginBottom: 10,
                }}
              >
                Beauty & Makeup Products
              </Text>
            </View>
          }
          renderItem={({ item }) => (
            <ProductCard product={item} />
          )}
          ListEmptyComponent={
            <View style={styles.empty}>
              <Ionicons
                name="bag-outline"
                size={50}
                color={colors.primary}
              />

              <Text
                style={{
                  color: colors.text,
                  fontSize: fs(14),
                  marginTop: 10,
                }}
              >
                No makeup products found.
              </Text>
            </View>
          }
        />
      )}
    </Screen>
  );
}

const styles = StyleSheet.create({
  center: {
    alignItems: 'center',
    marginTop: 50,
  },

  errorContainer: {
    alignItems: 'center',
    marginTop: 50,
    paddingHorizontal: 30,
  },

  title: {
    fontFamily: HEADING_FONT,
    marginLeft: 8,
  },

  retry: {
    marginTop: 14,
    paddingHorizontal: 26,
    paddingVertical: 10,
    borderRadius: 20,
  },

  empty: {
    alignItems: 'center',
    marginTop: 50,
  },
});