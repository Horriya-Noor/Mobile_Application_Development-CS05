// Header.js
// Pink toolbar shown on top of every main screen. From left to right:
//   menu (opens the side menu) | logo | search box | dark mode | wishlist | cart (with badge)

import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { LogoBadge } from './AppLogo';
import SideMenu from './SideMenu';
import { useApp } from '../context/AppContext';
import { useTheme } from '../theme/ThemeContext';

// one round toolbar icon with an optional number badge
function BarIcon({ name, onPress, badge }) {
  const { fs } = useTheme();
  return (
    <TouchableOpacity onPress={onPress} style={styles.icon} hitSlop={6}>
      <Ionicons name={name} size={24} color="#fff" />
      {badge > 0 && (
        <View style={styles.badge}>
          <Text style={[styles.badgeText, { fontSize: fs(9) }]}>{badge > 99 ? '99+' : badge}</Text>
        </View>
      )}
    </TouchableOpacity>
  );
}

export default function Header() {
  const navigation = useNavigation();
  const { colors, fs, dark, toggleDark } = useTheme();
  const { cartCount, wishlist } = useApp();
  const [menuOpen, setMenuOpen] = useState(false);
  const [text, setText] = useState('');

  // pressing Search on the keyboard looks through all products
  const search = () => {
    if (text.trim()) navigation.navigate('ProductList', { search: text.trim() });
  };

  return (
    <View style={[styles.bar, { backgroundColor: colors.primary }]}>
      {/* menu */}
      <TouchableOpacity onPress={() => setMenuOpen(true)} hitSlop={6}>
        <Ionicons name="menu" size={30} color="#fff" />
      </TouchableOpacity>

      {/* logo  */}
      <View style={{ marginLeft: 8 }}>
        <LogoBadge size={38} />
      </View>

      {/* search */}
      <View style={styles.searchBox}>
        <TextInput
          value={text}
          onChangeText={setText}
          onSubmitEditing={search}
          placeholder="Search products"
          placeholderTextColor="#888"
          returnKeyType="search"
          style={[styles.input, { fontSize: fs(12) }]}
        />
        <TouchableOpacity onPress={search} hitSlop={8}>
          <Ionicons name="search" size={16} color="#888" />
        </TouchableOpacity>
      </View>

      {/* dark / light mode toggle */}
      <BarIcon name={dark ? 'sunny-outline' : 'moon-outline'} onPress={toggleDark} />

      <SideMenu visible={menuOpen} onClose={() => setMenuOpen(false)} />
    </View>
  );
}

const styles = StyleSheet.create({
  bar: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 12, paddingVertical: 8 },
  searchBox: {
    flex: 1, flexDirection: 'row', alignItems: 'center', backgroundColor: '#fff',
    borderRadius: 18, marginHorizontal: 8, paddingHorizontal: 10, height: 34,
  },
  input: { flex: 1, padding: 0, color: '#222' },
  icon: { marginLeft: 8, width: 28, height: 30, alignItems: 'center', justifyContent: 'center' },
  badge: {
    position: 'absolute', top: -2, right: -4, minWidth: 16, height: 16, borderRadius: 8,
    backgroundColor: '#FFF200', alignItems: 'center', justifyContent: 'center', paddingHorizontal: 3,
  },
  badgeText: { color: '#1F1F1F', fontWeight: '900' },
});
