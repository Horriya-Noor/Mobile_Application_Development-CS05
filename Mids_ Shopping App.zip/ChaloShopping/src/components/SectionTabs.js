// SectionTabs.js
// Shared by the Clothes and Accessories screens.
// Men | Women tabs at the top, then the sub category cards of the chosen tab.
// (Clothes: Stitched / Unstitched. Accessories: Purses/Wallets, Watches, Jewellery, Purses)
// Tapping a card opens the product list for it.

import React, { useEffect, useState } from 'react';
import { ScrollView, View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import Header from './Header';
import BackRow from './BackRow';
import Screen from './Screen';
import CategoryCard from './CategoryCard';
import { PRODUCTS, SUBCATEGORIES } from '../data/products';
import { useTheme, HEADING_FONT } from '../theme/ThemeContext';

// gender = 'male' | 'female' (which tab is open first)
export default function SectionTabs({ category, title, gender }) {
  const navigation = useNavigation();
  const { colors, fs } = useTheme();
  const [tab, setTab] = useState(gender || 'male');

  // when the screen is opened again from the menu with another gender, switch the tab
  useEffect(() => {
    if (gender) setTab(gender);
  }, [gender]);

  const heading = tab === 'male' ? "Mens' Section" : "Womens' Section";
  const subs = SUBCATEGORIES[category][tab];

  // how many products are inside one sub category
  const count = (sub) =>
    PRODUCTS.filter((p) => p.category === category && p.gender === tab && p.sub === sub).length;

  return (
    <Screen>
      <Header />
      <BackRow title={title} />

      <ScrollView contentContainerStyle={{ padding: 10, paddingBottom: 30 }}>
        {/* Men / Women tabs */}
        <View style={[styles.tabs, { backgroundColor: colors.chip }]}>
          {[['male', 'Men'], ['female', 'Women']].map(([key, label]) => (
            <TouchableOpacity
              key={key}
              onPress={() => setTab(key)}
              style={[styles.tab, tab === key && { backgroundColor: colors.primary }]}
            >
              <Text style={{ color: '#fff', fontWeight: '800', fontSize: fs(13) }}>{label}</Text>
            </TouchableOpacity>
          ))}
        </View>

        <Text style={[styles.heading, { color: colors.text, fontSize: fs(26) }]}>{heading}</Text>

        {/* sub category cards */}
        <View style={styles.row}>
          {subs.map((sub) => (
            <CategoryCard
              key={sub.key}
              images={sub.images}
              height={150}
              title={sub.label}
              subtitle={`${count(sub.key)} items`}
              onPress={() => navigation.navigate('ProductList', { category, gender: tab, sub: sub.key })}
            />
          ))}
        </View>

        {/* shortcut: everything in this category for the chosen tab */}
        <TouchableOpacity
          style={[styles.all, { borderColor: colors.primary, backgroundColor: colors.card }]}
          onPress={() => navigation.navigate('ProductList', { category, gender: tab })}
        >
          <Text style={{ color: colors.text, fontWeight: '800', fontSize: fs(13) }}>
            View all {tab === 'male' ? "Men's" : "Women's"} {title}
          </Text>
          <Ionicons name="arrow-forward" size={18} color={colors.primary} />
        </TouchableOpacity>
      </ScrollView>
    </Screen>
  );
}

const styles = StyleSheet.create({
  tabs: { flexDirection: 'row', borderRadius: 22, padding: 4, alignSelf: 'center', width: '70%' },
  tab: { flex: 1, alignItems: 'center', paddingVertical: 8, borderRadius: 18 },
  heading: { fontFamily: HEADING_FONT, marginTop: 16, marginLeft: 6 },
  row: { flexDirection: 'row', marginTop: 8 },
  all: {
  flexDirection: 'row',
  alignItems: 'center',
  justifyContent: 'space-between',
  margin: 6,
  marginTop: 16,
  padding: 14,
  borderRadius: 10,
  borderWidth: 1.5,
  borderStyle: 'solid',
},
});
