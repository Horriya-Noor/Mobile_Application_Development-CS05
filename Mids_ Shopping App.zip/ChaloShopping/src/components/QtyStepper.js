// QtyStepper.js
// The  [ - ]  2  [ + ]  quantity control (used on Product Details and in the Cart).

import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../theme/ThemeContext';

export default function QtyStepper({ value, onMinus, onPlus, size = 26 }) {
  const { colors, fs } = useTheme();
  return (
    <View style={styles.row}>
      <TouchableOpacity
        style={[styles.btn, { width: size, height: size, borderRadius: size / 2, backgroundColor: colors.chip }]}
        onPress={onMinus}
      >
        <Ionicons name="remove" size={size * 0.6} color="#fff" />
      </TouchableOpacity>
      <Text style={[styles.value, { color: colors.text, fontSize: fs(14) }]}>{value}</Text>
      <TouchableOpacity
        style={[styles.btn, { width: size, height: size, borderRadius: size / 2, backgroundColor: colors.primary }]}
        onPress={onPlus}
      >
        <Ionicons name="add" size={size * 0.6} color="#fff" />
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center' },
  btn: { alignItems: 'center', justifyContent: 'center' },
  value: { fontWeight: '800', marginHorizontal: 12, minWidth: 16, textAlign: 'center' },
});
