// SafeImage.js
// Picture that never shows a broken box.
//   - `uris` is a list of web links: if the first one cannot load, the next one is tried.
//   - If all of them fail, a small picture icon is shown instead.
//   - While loading, a soft pink background is visible.

import React, { useEffect, useState } from 'react';
import { View, Image, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../theme/ThemeContext';

export default function SafeImage({ uris = [], style, resizeMode = 'cover', iconSize = 30 }) {
  const { colors } = useTheme();
  const list = (uris || []).filter(Boolean);
  const [index, setIndex] = useState(0);

  // start again from the first link when a different product is shown
  useEffect(() => {
    setIndex(0);
  }, [list[0]]);

  const failed = index >= list.length;

  return (
    <View style={[{ backgroundColor: colors.inputBg, alignItems: 'center', justifyContent: 'center', overflow: 'hidden' }, style]}>
      {failed ? (
        <Ionicons name="image-outline" size={iconSize} color={colors.subText} />
      ) : (
        <Image
          source={{ uri: list[index] }}
          style={StyleSheet.absoluteFill}
          resizeMode={resizeMode}
          onError={() => setIndex((i) => i + 1)} // try the next link
        />
      )}
    </View>
  );
}
