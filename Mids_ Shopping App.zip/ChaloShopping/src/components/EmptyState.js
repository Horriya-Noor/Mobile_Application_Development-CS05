// EmptyState.js
// Friendly message with an icon and an optional button.
// Used for an empty cart / wishlist / orders and for "please log in" screens.

import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../theme/ThemeContext';

export default function EmptyState({ icon, title, subtitle, buttonLabel, onPress }) {
  const { colors, fs } = useTheme();
  return (
    <View style={styles.wrap}>
      <View style={[styles.circle, { backgroundColor: colors.card, borderColor: colors.chip }]}>
        <Ionicons name={icon} size={44} color={colors.primary} />
      </View>
      <Text style={[styles.title, { color: colors.text, fontSize: fs(16) }]}>{title}</Text>
      {subtitle ? <Text style={[styles.sub, { color: colors.subText, fontSize: fs(12) }]}>{subtitle}</Text> : null}
      {buttonLabel ? (
        <TouchableOpacity style={[styles.button, { backgroundColor: colors.primary }]} onPress={onPress}>
          <Text style={{ color: '#fff', fontWeight: '800', fontSize: fs(13) }}>{buttonLabel}</Text>
        </TouchableOpacity>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { alignItems: 'center', marginTop: 60, paddingHorizontal: 30 },
  circle: { width: 96, height: 96, borderRadius: 48, borderWidth: 1.5, alignItems: 'center', justifyContent: 'center' },
  title: { fontWeight: '900', marginTop: 16, textAlign: 'center' },
  sub: { marginTop: 6, textAlign: 'center' },
  button: { marginTop: 18, paddingHorizontal: 28, paddingVertical: 11, borderRadius: 22 },
});
