// BudgetNote.js
// Shows the ChaloSmart budget message.
// Gives a voice warning when the user goes over budget.

import React, { useEffect, useRef } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import * as Speech from 'expo-speech';

import { useTheme } from '../theme/ThemeContext';
import { formatPrice } from '../utils/pricing';
import { playSound } from '../utils/sound';

export default function BudgetNote({ cartTotal, budget }) {
  const { fs } = useTheme();

  // Remember the previous total so we know when the cart changes
  const previousTotal = useRef(cartTotal);

  if (!budget) return null;

  const within = cartTotal <= budget;
  const amountOver = cartTotal - budget;

  useEffect(() => {
    // Only react when the cart total changes
    if (cartTotal === previousTotal.current) {
      return;
    }

    previousTotal.current = cartTotal;

    // User is over budget
    if (cartTotal > budget) {
      const overAmount = cartTotal - budget;

      // Stop any previous speech
      Speech.stop();

      // Play short warning sound
      playSound('warning');

      // Speak immediately
      Speech.speak(
        `Warning! You have shopped over your budget by ${Math.round(
          overAmount
        )} rupees. Please remove some items.`,
        {
          language: 'en-US',
          pitch: 1.0,
          rate: 1.0,
        }
      );
    } else {
      // Stop warning voice if user comes back under budget
      Speech.stop();
    }
  }, [cartTotal, budget]);

  return (
    <View
      style={[
        styles.box,
        {
          backgroundColor: within ? '#D7F5DF' : '#FFD6D6',
        },
      ]}
    >
      <Text
        style={[
          styles.title,
          {
            fontSize: fs(13),
            color: within ? '#0B6B3A' : '#B00020',
          },
        ]}
      >
        {within
          ? 'You are within budget'
          : `Budget exceeded by ${formatPrice(amountOver)}`}
      </Text>

      {within && (
        <Text
          style={[
            styles.sub,
            {
              fontSize: fs(12),
            },
          ]}
        >
          You can still afford {formatPrice(budget - cartTotal)} more
        </Text>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  box: {
    padding: 10,
    borderRadius: 8,
    marginVertical: 6,
  },

  title: {
    fontWeight: '800',
  },

  sub: {
    color: '#333',
    marginTop: 2,
  },
});