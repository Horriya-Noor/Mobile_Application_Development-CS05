// SideMenu.js
// The slide-in menu opened by the hamburger icon. It now has every part of the app:
// Shop (Home, Categories, Makeup, ChaloSmart), Men, Women and My Account
// (Orders, Wishlist, Cart, Profile, dark mode, log in / log out).

import React from 'react';
import { Modal, View, Text, ScrollView, TouchableOpacity, Switch, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useApp } from '../context/AppContext';
import { useTheme } from '../theme/ThemeContext';

export default function SideMenu({ visible, onClose }) {
  const navigation = useNavigation();
  const insets = useSafeAreaInsets();
  const { user, logout, notify, cartCount, wishlist } = useApp();
  const { colors, fs, dark, toggleDark } = useTheme();

  // close the menu, then open the chosen screen
  const go = (screen, params) => {
    onClose();
    navigation.navigate(screen, params);
  };

  // one row of the menu: icon + label (+ optional number)
  const item = (icon, label, screen, params, count) => (
    <TouchableOpacity style={styles.item} onPress={() => go(screen, params)}>
      <Ionicons name={icon} size={19} color="#2B2B2B" />
      <Text style={[styles.itemText, { fontSize: fs(13) }]}>{label}</Text>
      {count > 0 ? (
        <View style={styles.count}>
          <Text style={{ color: '#fff', fontSize: fs(10), fontWeight: '800' }}>{count}</Text>
        </View>
      ) : null}
    </TouchableOpacity>
  );

  const section = (label) => <Text style={[styles.section, { fontSize: fs(12) }]}>{label}</Text>;

  const onLogout = async () => {
    await logout();
    onClose();
    notify('Logged out');
  };

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
      <View style={{ flex: 1, flexDirection: 'row' }}>
        <View style={[styles.panel, { paddingTop: insets.top + 16, backgroundColor: colors.chip }]}>
          <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: insets.bottom + 20 }}>
            {/* greeting */}
            <View style={styles.hello}>
              <Ionicons name="person-circle" size={46} color="#1F4D2B" />
              <Text style={[styles.helloText, { fontSize: fs(15) }]}>Hello {user ? user.name : 'Guest'}</Text>
            </View>

            {section('Shop')}
            {item('home-outline', 'Home', 'Home')}
            {item('grid-outline', 'All Categories', 'Categories')}
            {item('color-palette-outline', 'MakeUp', 'Makeup')}
            {item('wallet-outline', 'ChaloSmart Budget', 'ChaloSmart')}

            {section('Males')}
            {item('shirt-outline', 'Clothes', 'Clothes', { gender: 'male' })}
            {item('watch-outline', 'Accessories', 'Accessories', { gender: 'male' })}

            {section('Females')}
            {item('shirt-outline', 'Clothes', 'Clothes', { gender: 'female' })}
            {item('diamond-outline', 'Accessories', 'Accessories', { gender: 'female' })}

            {section('My Account')}
            {item('receipt-outline', 'My Orders', 'MyOrders')}
            {item('heart-outline', 'Wish List', 'Wishlist', undefined, wishlist.length)}
            {item('cart-outline', 'My Cart', 'Cart', undefined, cartCount)}
            {item('person-outline', 'Profile & Settings', 'Profile')}

            {/* dark mode switch right inside the menu */}
            <View style={styles.item}>
              <Ionicons name="moon-outline" size={19} color="#2B2B2B" />
              <Text style={[styles.itemText, { fontSize: fs(13) }]}>Dark Mode</Text>
              <Switch value={dark} onValueChange={toggleDark} trackColor={{ true: colors.primary }} />
            </View>

            {/* log in / log out */}
            {user ? (
              <TouchableOpacity style={styles.item} onPress={onLogout}>
                <Ionicons name="log-out-outline" size={19} color="#B00020" />
                <Text style={[styles.itemText, { fontSize: fs(13), color: '#B00020' }]}>Log Out</Text>
              </TouchableOpacity>
            ) : (
              item('log-in-outline', 'Log In / Sign Up', 'Login')
            )}
          </ScrollView>
        </View>
        {/* tapping the dark area closes the menu */}
        <TouchableOpacity style={styles.backdrop} onPress={onClose} />
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  panel: { width: 250, paddingHorizontal: 18 },
  hello: { alignItems: 'center', marginBottom: 6 },
  helloText: { fontWeight: '800', color: '#1F4D2B', marginTop: 4 },
  section: { fontWeight: '800', color: '#2B2B2B', marginTop: 14, marginBottom: 4 },
  item: { flexDirection: 'row', alignItems: 'center', paddingVertical: 8 },
  itemText: { marginLeft: 10, color: '#2B2B2B', fontWeight: '600', flex: 1 },
  count: { backgroundColor: '#1F4D2B', borderRadius: 10, minWidth: 20, height: 20, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 5 },
  backdrop: { flex: 1, backgroundColor: 'rgba(0,0,0,0.4)' },
});
