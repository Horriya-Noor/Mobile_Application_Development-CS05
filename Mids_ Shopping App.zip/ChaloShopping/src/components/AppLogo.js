
import React from 'react';
import { View, Text, Image, StyleSheet } from 'react-native';
import { useTheme } from '../theme/ThemeContext';

const LOGO_IMAGE = require('../../assets/logo.png');

function LogoSlot({ size }) {
  const { colors } = useTheme();
  return (
    <View
      style={[
        styles.slot,
        { width: size, height: size, borderRadius: size / 2, borderColor: colors.primary },
      ]}
    >
      {LOGO_IMAGE ? (
        <Image source={LOGO_IMAGE} style={{ width: size * 0.8, height: size * 0.8 }} resizeMode="contain" />
      ) : null}
    </View>
  );
}

// Small round logo used in the header bar
export function LogoBadge({ size = 44 }) {
  return <LogoSlot size={size} />;
}

// Big logo with the app name (Splash and Login screens)
export function LogoFull({ size = 1 }) {
  const { colors } = useTheme();
  return (
    <View style={styles.full}>
      <LogoSlot size={110 * size} />
      <Text style={[styles.name, { fontSize: 32 * size }]}>
        <Text style={{ color: '#2B2B2B' }}>Chalo</Text>
        <Text style={{ color: colors.primary }}>Shopping</Text>
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  slot: {
    backgroundColor: '#fff',
    borderWidth: 2,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  },
  full: { alignItems: 'center' },
  name: { fontWeight: '900', marginTop: 10 },
});
