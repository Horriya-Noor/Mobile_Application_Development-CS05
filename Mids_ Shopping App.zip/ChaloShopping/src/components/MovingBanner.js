// MovingBanner.js
// Continuous yellow offer banner with no gap between repeated text.

import React, { useEffect, useRef, useState } from 'react';
import {
  Animated,
  Easing,
  View,
  Dimensions,
  StyleSheet,
} from 'react-native';
import { useTheme } from '../theme/ThemeContext';

const { width: SCREEN_WIDTH } = Dimensions.get('window');

export default function MovingBanner({ text }) {
  const { colors, fs } = useTheme();

  const translateX = useRef(new Animated.Value(0)).current;

  const [textWidth, setTextWidth] = useState(0);

  useEffect(() => {
    if (!textWidth) return;

    translateX.setValue(0);

    const animation = Animated.loop(
      Animated.timing(translateX, {
        toValue: -textWidth,
        duration: 12000,
        easing: Easing.linear,
        useNativeDriver: true,
      })
    );

    animation.start();

    return () => {
      animation.stop();
    };
  }, [textWidth, translateX]);

  // Create enough copies to always fill the banner
  const numberOfCopies =
    textWidth > 0
      ? Math.ceil(SCREEN_WIDTH / textWidth) + 2
      : 3;

  return (
    <View
      style={[
        styles.banner,
        { backgroundColor: colors.banner },
      ]}
    >
      <Animated.View
        style={[
          styles.row,
          {
            transform: [{ translateX }],
          },
        ]}
      >
        {Array.from({ length: numberOfCopies }).map((_, index) => (
          <Animated.Text
            key={index}
            numberOfLines={1}
            onLayout={(event) => {
              if (index === 0 && !textWidth) {
                setTextWidth(event.nativeEvent.layout.width);
              }
            }}
            style={[
              styles.text,
              {
                color: colors.bannerText,
                fontSize: fs(12),
              },
            ]}
          >
            {text}
          </Animated.Text>
        ))}
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  banner: {
    height: 30,
    justifyContent: 'center',
    overflow: 'hidden',
  },

  row: {
    flexDirection: 'row',
    alignItems: 'center',
  },

  text: {
    fontWeight: '800',
    flexShrink: 0,
    margin: 0,
    padding: 0,
  },
});