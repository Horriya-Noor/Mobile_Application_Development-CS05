// BackRow.js
// Back arrow + page title, used under the header on inner screens.

import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { useTheme } from '../theme/ThemeContext';

export default function BackRow({ title }) {
  const navigation = useNavigation();
  const { colors, fs } = useTheme();

  // go back if possible, otherwise open Home (for example after a deep jump)
  const goBack = () => {
    if (navigation.canGoBack()) navigation.goBack();
    else navigation.navigate('Home');
  };

  return (
    <View style={styles.row}>
      <TouchableOpacity onPress={goBack} hitSlop={10}>
        <Ionicons name="arrow-back" size={26} color={colors.text} />
      </TouchableOpacity>
      <Text numberOfLines={1} style={[styles.title, { color: colors.text, fontSize: fs(16) }]}>{title}</Text>
      <View style={{ width: 26 }} />
    </View>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 12 },
  title: { fontWeight: '800', flex: 1, textAlign: 'center', marginHorizontal: 8 },
});
