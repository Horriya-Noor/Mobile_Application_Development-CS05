// ProductCard.js
// Reusable product card used on every product list (picture, name, rating, price, heart).

import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { useApp } from '../context/AppContext';
import { useTheme } from '../theme/ThemeContext';
import { formatPrice } from '../utils/pricing';
import SafeImage from './SafeImage';

export default function ProductCard({ product, style }) {
  const navigation = useNavigation();
  const { colors, fs } = useTheme();
  const { toggleWishlist, isWished } = useApp();
  const wished = isWished(product.id);

  return (
    <TouchableOpacity
      activeOpacity={0.9}
      style={[styles.card, { backgroundColor: colors.card }, style]}
      onPress={() => navigation.navigate('ProductDetails', { product })}
    >
      <View>
        <SafeImage
          uris={product.images || [product.image]}
          style={[styles.image, product.contain && { backgroundColor: '#fff' }]}
          resizeMode={product.contain ? 'contain' : 'cover'}
        />
        {/* "Deal" tag for discounted picks */}
        {product.deal ? (
          <View style={[styles.deal, { backgroundColor: colors.banner }]}>
            <Text style={{ color: colors.bannerText, fontWeight: '900', fontSize: fs(9) }}>🔥 DEAL</Text>
          </View>
        ) : null}
        {/* heart icon: tap to save / remove from wishlist */}
        <TouchableOpacity style={styles.heart} onPress={() => toggleWishlist(product)} hitSlop={6}>
          <Ionicons name={wished ? 'heart' : 'heart-outline'} size={18} color={colors.primary} />
        </TouchableOpacity>
      </View>

      <Text numberOfLines={1} style={[styles.name, { color: colors.text, fontSize: fs(13) }]}>
        {product.name}
      </Text>

      <View style={styles.ratingRow}>
        <Ionicons name="star" size={12} color="#F5B400" />
        <Text style={{ color: colors.subText, fontSize: fs(10), marginLeft: 3 }}>
          {Number(product.rating || 4).toFixed(1)}
        </Text>
      </View>

      <View style={styles.row}>
        <Text style={[styles.price, { color: colors.green, fontSize: fs(13) }]}>{formatPrice(product.price)}</Text>
        <View style={[styles.zoom, { backgroundColor: colors.chip }]}>
          <Ionicons name="search" size={13} color="#fff" />
        </View>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: { flex: 1, maxWidth: '50%', margin: 6, borderRadius: 8, padding: 6, elevation: 2 },
  image: { width: '100%', height: 140, borderRadius: 6 },
  deal: { position: 'absolute', top: 6, left: 6, borderRadius: 8, paddingHorizontal: 6, paddingVertical: 2 },
  heart: {
    position: 'absolute', top: 6, right: 6, backgroundColor: '#fff', borderRadius: 14,
    width: 28, height: 28, alignItems: 'center', justifyContent: 'center',
  },
  name: { fontWeight: '800', marginTop: 6, textAlign: 'center' },
  ratingRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', marginTop: 2 },
  row: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 4 },
  price: { fontWeight: '800' },
  zoom: { width: 24, height: 24, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
});
