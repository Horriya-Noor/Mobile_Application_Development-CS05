// CategoryCard.js
// Square card with a picture, a title and a small subtitle (used on category screens).

import React from 'react';
import { Text, TouchableOpacity, StyleSheet } from 'react-native';
import { useTheme } from '../theme/ThemeContext';
import SafeImage from './SafeImage';

export default function CategoryCard({ images, title, subtitle, onPress, height = 100 }) {
  const { colors, fs } = useTheme();

  return (
    <TouchableOpacity
      activeOpacity={0.85}
      onPress={onPress}
      style={[styles.card, { backgroundColor: colors.card, borderColor: colors.chip }]}
    >
      <SafeImage uris={images} style={{ width: '100%', height, borderRadius: 6 }} />
      <Text style={[styles.title, { color: colors.text, fontSize: fs(12) }]}>{title}</Text>
      {subtitle ? <Text style={[styles.sub, { color: colors.subText, fontSize: fs(10) }]}>{subtitle}</Text> : null}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: { flex: 1, margin: 6, padding: 6, borderRadius: 8, borderWidth: 1, alignItems: 'center', elevation: 2 },
  title: { fontWeight: '800', marginTop: 6, textAlign: 'center' },
  sub: { textAlign: 'center', marginTop: 2 },
});
