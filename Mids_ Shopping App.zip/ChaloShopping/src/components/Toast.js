// Toast.js
// The small "Added to Cart ✓" message that appears at the top of the screen.

import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { useApp } from '../context/AppContext';
import { useTheme } from '../theme/ThemeContext';

export default function Toast() {
  const { toast } = useApp();
  const { fs } = useTheme();

  if (!toast) return null;

  return (
    <View pointerEvents="none" style={styles.wrap}>
      <View style={styles.box}>
        <Text style={[styles.text, { fontSize: fs(14) }]}>{toast}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { position: 'absolute', top: 70, left: 0, right: 0, alignItems: 'center', zIndex: 999 },
  box: {
    backgroundColor: '#222',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 25,
    elevation: 8,
  },
  text: { color: '#fff', fontWeight: '600' },
});
