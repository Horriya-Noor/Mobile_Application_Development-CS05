// Screen.js
// Wrapper used by every screen: handles the safe area (notch), status bar and background colour.

import React from 'react';
import { View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { useTheme } from '../theme/ThemeContext';

export default function Screen({ children, bottom = false }) {
  const { colors, dark } = useTheme();
  return (
    <SafeAreaView
      style={{ flex: 1, backgroundColor: colors.primary }}
      edges={bottom ? ['top', 'bottom'] : ['top']}
    >
      <StatusBar style="light" />
      <View style={{ flex: 1, backgroundColor: colors.bg }}>{children}</View>
    </SafeAreaView>
  );
}
