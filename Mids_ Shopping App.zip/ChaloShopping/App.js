// App.js
// Entry point. Sets up the providers (theme, app state) and all navigation.
//
// Navigation layout:
//   Stack:  Splash -> Main (tabs) -> Login / Checkout / OrderSuccess / MyOrders
//   Tabs :  Home | Categories | Cart | Wish List | Profile   (bottom tab bar)
//           The other screens (Clothes, Accessories, Makeup, ProductList,
//           ProductDetails, ChaloSmart) are "hidden tabs": reachable by navigation
//           only, so the bottom bar stays visible on them like in the Figma design.
//   Each screen lives in its own folder:  src/screens/<Name>/<Name>Screen.js

import React from 'react';
import { View, StyleSheet } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useFonts, LilitaOne_400Regular } from '@expo-google-fonts/lilita-one';

import { ThemeProvider, useTheme } from './src/theme/ThemeContext';
import { AppProvider, useApp } from './src/context/AppContext';
import Toast from './src/components/Toast';

import SplashScreen from './src/screens/Splash/SplashScreen';
import HomeScreen from './src/screens/Home/HomeScreen';
import CategoriesScreen from './src/screens/Categories/CategoriesScreen';
import ClothesScreen from './src/screens/Clothes/ClothesScreen';
import AccessoriesScreen from './src/screens/Accessories/AccessoriesScreen';
import MakeupScreen from './src/screens/Makeup/MakeupScreen';
import ProductListScreen from './src/screens/ProductList/ProductListScreen';
import ProductDetailsScreen from './src/screens/ProductDetails/ProductDetailsScreen';
import LoginScreen from './src/screens/Login/LoginScreen';
import CartScreen from './src/screens/Cart/CartScreen';
import WishlistScreen from './src/screens/Wishlist/WishlistScreen';
import ProfileScreen from './src/screens/Profile/ProfileScreen';
import CheckoutScreen from './src/screens/Checkout/CheckoutScreen';
import OrderSuccessScreen from './src/screens/OrderSuccess/OrderSuccessScreen';
import MyOrdersScreen from './src/screens/MyOrders/MyOrdersScreen';
import ChaloSmartScreen from './src/screens/ChaloSmart/ChaloSmartScreen';

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

// options that hide a screen's button in the bottom bar
const hidden = { tabBarItemStyle: { display: 'none' } };

// ---------------- bottom tabs ----------------
function MainTabs() {
  const { colors, fs } = useTheme();
  const { cartCount } = useApp();

  // draws a tab icon; the active tab gets a white circle like in the design
  const icon = (name) => ({ focused }) => (
    <View style={[styles.iconWrap, focused && { backgroundColor: '#fff' }]}>
      <Ionicons name={name} size={22} color={focused ? colors.primary : '#fff'} />
    </View>
  );

  return (
    <Tab.Navigator
      backBehavior="history"
      screenOptions={{
        headerShown: false,
        tabBarHideOnKeyboard: true,
        tabBarStyle: { backgroundColor: colors.primary, height: 66, paddingTop: 4, borderTopWidth: 0 },
        tabBarLabelStyle: { color: '#fff', fontWeight: '700', fontSize: fs(10) },
        tabBarBadgeStyle: { backgroundColor: '#FFF200', color: '#1F1F1F', fontWeight: '900' },
      }}
    >
      {/* visible tabs: Home, Categories, Cart (with badge), Wish List, Profile */}
      <Tab.Screen name="Home" component={HomeScreen} options={{ tabBarIcon: icon('home-outline') }} />
      <Tab.Screen name="Categories" component={CategoriesScreen} options={{ tabBarIcon: icon('grid-outline') }} />
      <Tab.Screen
        name="Cart"
        component={CartScreen}
        options={{ tabBarIcon: icon('cart-outline'), tabBarBadge: cartCount > 0 ? cartCount : undefined }}
      />
      <Tab.Screen name="Wishlist" component={WishlistScreen} options={{ title: 'Wish List', tabBarIcon: icon('heart-outline') }} />
      <Tab.Screen name="Profile" component={ProfileScreen} options={{ tabBarIcon: icon('person-outline') }} />

      {/* hidden tabs (reachable by navigation only) */}
      <Tab.Screen name="Clothes" component={ClothesScreen} options={hidden} />
      <Tab.Screen name="Accessories" component={AccessoriesScreen} options={hidden} />
      <Tab.Screen name="Makeup" component={MakeupScreen} options={hidden} />
      <Tab.Screen name="ProductList" component={ProductListScreen} options={hidden} />
      <Tab.Screen name="ProductDetails" component={ProductDetailsScreen} options={hidden} />
      <Tab.Screen name="ChaloSmart" component={ChaloSmartScreen} options={hidden} />
    </Tab.Navigator>
  );
}

// ---------------- stack + toast ----------------
function Root() {
  return (
    <View style={{ flex: 1 }}>
      <NavigationContainer>
        <Stack.Navigator initialRouteName="Splash" screenOptions={{ headerShown: false }}>
          <Stack.Screen name="Splash" component={SplashScreen} />
          <Stack.Screen name="Main" component={MainTabs} />
          {/* Login slides up from the bottom; it only appears when it is needed */}
          <Stack.Screen name="Login" component={LoginScreen} options={{ animation: 'slide_from_bottom' }} />
          <Stack.Screen name="Checkout" component={CheckoutScreen} />
          <Stack.Screen name="OrderSuccess" component={OrderSuccessScreen} options={{ gestureEnabled: false }} />
          <Stack.Screen name="MyOrders" component={MyOrdersScreen} />
        </Stack.Navigator>
      </NavigationContainer>
      {/* "Added to Cart ✓" message floats above every screen */}
      <Toast />
    </View>
  );
}

export default function App() {
  // load the heading font before showing anything
  const [fontsLoaded] = useFonts({ LilitaOne_400Regular });
  if (!fontsLoaded) return null;

  return (
    <SafeAreaProvider>
      <ThemeProvider>
        <AppProvider>
          <Root />
        </AppProvider>
      </ThemeProvider>
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  iconWrap: { width: 34, height: 34, borderRadius: 17, alignItems: 'center', justifyContent: 'center' },
});
