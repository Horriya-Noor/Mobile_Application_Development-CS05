// Entry point: registers the root App component with Expo.
import { registerRootComponent } from 'expo';
import App from './App';

registerRootComponent(App);
