import React, { useEffect, useState } from 'react';
import { Modal, StyleSheet, Text, TextInput, View } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Ionicons } from '@expo/vector-icons';
import { todayKey } from '../utils/smartPlanner';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { colors, shadow } from '../theme';
import BubbleTouchable from './BubbleTouchable';

const noteKey = (uid, day) => `studyflow:dailyNote:${uid}:${day}`;

export default function QuickNotesToggle() {
  const { user } = useAuth();
  const toast = useToast();
  const [visible, setVisible] = useState(false);
  const [note, setNote] = useState('');
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const day = todayKey();

  useEffect(() => {
    if (!visible || !user?.uid) return undefined;
    let active = true;
    setLoading(true);
    AsyncStorage.getItem(noteKey(user.uid, day))
      .then((savedNote) => {
        if (active) setNote(savedNote || '');
      })
      .catch((error) => {
        if (active) toast(`Couldn't load today's note: ${error.message}`, 'error');
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [day, toast, user?.uid, visible]);

  const saveNote = async () => {
    if (!user?.uid) return;
    setSaving(true);
    try {
      await AsyncStorage.setItem(noteKey(user.uid, day), note);
      setVisible(false);
      toast('Daily note saved');
    } catch (error) {
      toast(`Couldn't save today's note: ${error.message}`, 'error');
    } finally {
      setSaving(false);
    }
  };

  return (
    <>
      <BubbleTouchable
        accessibilityRole="button"
        accessibilityLabel="Open today's notepad"
        onPress={() => setVisible(true)}
        style={styles.toggle}
      >
        <Ionicons name="document-text-outline" size={21} color="#fff" />
      </BubbleTouchable>
      <Modal visible={visible} transparent animationType="fade" onRequestClose={() => setVisible(false)}>
        <View style={styles.overlay}>
          <View style={[styles.modal, shadow]}>
            <View style={styles.modalHeader}>
              <View>
                <Text style={styles.title}>Daily notepad</Text>
                <Text style={styles.date}>{day}</Text>
              </View>
              <BubbleTouchable
                accessibilityRole="button"
                accessibilityLabel="Close notepad"
                onPress={() => setVisible(false)}
                style={styles.closeButton}
              >
                <Ionicons name="close" size={22} color={colors.muted} />
              </BubbleTouchable>
            </View>
            <TextInput
              multiline
              editable={!loading && !saving}
              value={note}
              onChangeText={setNote}
              placeholder={loading ? 'Loading your note…' : 'Write down what you want to remember today…'}
              placeholderTextColor={colors.muted}
              style={styles.input}
              textAlignVertical="top"
            />
            <BubbleTouchable
              accessibilityRole="button"
              disabled={loading || saving}
              onPress={saveNote}
              style={[styles.saveButton, (loading || saving) && styles.disabled]}
            >
              <Text style={styles.saveText}>{saving ? 'Saving…' : 'Save note'}</Text>
            </BubbleTouchable>
          </View>
        </View>
      </Modal>
    </>
  );
}

const styles = StyleSheet.create({
  toggle: { width: 42, height: 42, borderRadius: 14, backgroundColor: '#ffffff30', alignItems: 'center', justifyContent: 'center', marginLeft: 12 },
  overlay: { flex: 1, backgroundColor: '#15112A88', alignItems: 'center', justifyContent: 'center', padding: 22 },
  modal: { width: '100%', maxWidth: 480, backgroundColor: '#fff', borderRadius: 24, padding: 20 },
  modalHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 },
  title: { color: colors.ink, fontSize: 20, fontWeight: '800' },
  date: { color: colors.muted, fontSize: 12, marginTop: 3 },
  closeButton: { width: 38, height: 38, borderRadius: 12, backgroundColor: '#F4F2FB', alignItems: 'center', justifyContent: 'center' },
  input: { minHeight: 220, maxHeight: 360, borderWidth: 1, borderColor: colors.line, borderRadius: 16, padding: 14, color: colors.ink, fontSize: 15, lineHeight: 22 },
  saveButton: { minHeight: 48, borderRadius: 14, backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center', marginTop: 14 },
  saveText: { color: '#fff', fontSize: 14, fontWeight: '800' },
  disabled: { opacity: 0.5 },
});
