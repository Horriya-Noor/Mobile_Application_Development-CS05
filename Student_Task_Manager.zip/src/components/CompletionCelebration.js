import React, { useEffect, useRef } from 'react';
import { Modal, StyleSheet, Text, View } from 'react-native';
import { setAudioModeAsync, useAudioPlayer, useAudioPlayerStatus } from 'expo-audio';
import * as Speech from 'expo-speech';
import BubbleTouchable from './BubbleTouchable';

export default function CompletionCelebration({ visible, onDismiss }) {
  const player = useAudioPlayer(require('../../assets/completion-jingle.wav'));
  const playerStatus = useAudioPlayerStatus(player);
  const onDismissRef = useRef(onDismiss);
  onDismissRef.current = onDismiss;

  useEffect(() => {
    if (!visible) return undefined;

    const timeout = setTimeout(() => onDismissRef.current(), 5000);
    Speech.speak('Congratulations, you have done it!', {
      language: 'en-US',
      rate: 0.95,
      useApplicationAudioSession: false,
      onError: (error) => console.error('Could not speak the completion message:', error),
    });

    return () => {
      clearTimeout(timeout);
      Speech.stop().catch((error) => console.error('Could not stop the completion voice:', error));
    };
  }, [visible]);

  useEffect(() => {
    if (!visible || !playerStatus.isLoaded) return undefined;

    let active = true;
    const playJingle = async () => {
      try {
        await setAudioModeAsync({ playsInSilentMode: true });
        if (active) {
          player.volume = 0.18;
          player.play();
        }
      } catch (error) {
        console.error('Could not play the completion music:', error);
      }
    };

    playJingle();
    return () => {
      active = false;
      player.pause();
      player.seekTo(0).catch((error) => console.error('Could not reset the completion music:', error));
    };
  }, [visible, player, playerStatus.isLoaded]);

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onDismiss}>
      <BubbleTouchable style={styles.overlay} onPress={onDismiss} accessibilityRole="button" accessibilityLabel="Dismiss celebration">
        <View pointerEvents="none" style={styles.message}>
          <Text style={styles.emoji}>🎉</Text>
          <Text style={styles.title}>Congratulations!</Text>
          <Text style={styles.subtitle}>You have done it!</Text>
          <Text style={styles.hint}>Tap anywhere to continue</Text>
        </View>
      </BubbleTouchable>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: '#168A45', alignItems: 'center', justifyContent: 'center', padding: 28 },
  message: { alignItems: 'center' },
  emoji: { fontSize: 76, marginBottom: 20 },
  title: { color: '#fff', fontSize: 34, fontWeight: '900', textAlign: 'center' },
  subtitle: { color: '#E8FFEF', fontSize: 22, fontWeight: '700', marginTop: 10, textAlign: 'center' },
  hint: { color: '#D5F5DF', fontSize: 14, marginTop: 38 },
});
