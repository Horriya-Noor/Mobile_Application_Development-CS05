// Reusable UI pieces: gradient header, buttons, text field, chips, stat card, section title.
import React, { forwardRef } from 'react';
import { View, Text, TextInput, StyleSheet, ActivityIndicator } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { colors, gradient, shadow } from '../theme';
import BubbleTouchable from './BubbleTouchable';
import QuickNotesToggle from './QuickNotesToggle';

// Purple gradient header with a title and optional subtitle / right-side element.
export function Header({ title, subtitle, right, children }) {
  const insets = useSafeAreaInsets();
  return (
    <LinearGradient colors={gradient} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={[styles.header, { paddingTop: insets.top + 14 }]}>
      <View style={styles.headerRow}>
        <View style={{ flex: 1 }}>
          {subtitle ? <Text style={styles.headerSub}>{subtitle}</Text> : null}
          <Text style={styles.headerTitle}>{title}</Text>
        </View>
        <View style={styles.headerActions}>
          {right}
          <QuickNotesToggle />
        </View>
      </View>
      {children}
    </LinearGradient>
  );
}

// Big gradient button (or outlined/danger variants) with a loading spinner.
export function Button({ title, onPress, loading, variant = 'primary', style, disabled, small }) {
  const isPrimary = variant === 'primary';
  const bg = variant === 'danger' ? colors.danger : variant === 'outline' ? 'transparent' : null;
  const inner = loading ? (
    <ActivityIndicator color={variant === 'outline' ? colors.primary : '#fff'} />
  ) : (
    <Text style={[styles.btnText, variant === 'outline' && { color: colors.primary }]}>{title}</Text>
  );
  return (
    <BubbleTouchable activeOpacity={0.85} onPress={onPress} disabled={loading || disabled} style={[{ opacity: disabled ? 0.5 : 1 }, style]}>
      {isPrimary ? (
        <LinearGradient colors={gradient} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={[styles.btn, small && styles.btnSmall]}>{inner}</LinearGradient>
      ) : (
        <View style={[styles.btn, { backgroundColor: bg }, variant === 'outline' && { borderWidth: 1.5, borderColor: colors.primary }]}>{inner}</View>
      )}
    </BubbleTouchable>
  );
}

// Labeled text input; forwardRef lets a screen focus it using useRef.
export const Field = forwardRef(function Field({ label, error, multiline, ...props }, ref) {
  return (
    <View style={{ marginBottom: 14 }}>
      <Text style={styles.label}>{label}</Text>
      <TextInput
        ref={ref}
        multiline={multiline}
        placeholderTextColor={colors.muted}
        style={[styles.input, multiline && { height: 90, textAlignVertical: 'top' }, error && { borderColor: colors.danger }]}
        {...props}
      />
      {error ? <Text style={styles.error}>{error}</Text> : null}
    </View>
  );
});

// Row of selectable pill buttons (used for status, priority, due date, filters).
export function ChipRow({ options, value, onChange, tint = colors.primary }) {
  return (
    <View style={styles.chipRow}>
      {options.map((o) => {
        const label = typeof o === 'string' ? o : o.label;
        const val = typeof o === 'string' ? o : o.value;
        const active = val === value;
        return (
          <BubbleTouchable key={String(val)} onPress={() => onChange(val)} style={[styles.chip, active && { backgroundColor: tint, borderColor: tint }]}>
            <Text style={[styles.chipText, active && { color: '#fff' }]}>{label}</Text>
          </BubbleTouchable>
        );
      })}
    </View>
  );
}

// Small colored number card used on the dashboard.
export function StatCard({ label, value, icon, color }) {
  return (
    <View style={[styles.stat, shadow]}>
      <View style={[styles.statIcon, { backgroundColor: color + '22' }]}>
        <Text style={{ fontSize: 18 }}>{icon}</Text>
      </View>
      <Text style={styles.statValue}>{value}</Text>
      <Text style={styles.statLabel}>{label}</Text>
    </View>
  );
}

// Bold section title.
export const Section = ({ children }) => <Text style={styles.section}>{children}</Text>;

const styles = StyleSheet.create({
  header: { paddingHorizontal: 20, paddingBottom: 26, borderBottomLeftRadius: 28, borderBottomRightRadius: 28 },
  headerRow: { flexDirection: 'row', alignItems: 'center' },
  headerActions: { flexDirection: 'row', alignItems: 'center' },
  headerSub: { color: '#E3DBFF', fontSize: 14, marginBottom: 2 },
  headerTitle: { color: '#fff', fontSize: 26, fontWeight: '800' },
  btn: { height: 52, borderRadius: 16, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 18 },
  btnSmall: { height: 40, borderRadius: 12 },
  btnText: { color: '#fff', fontSize: 16, fontWeight: '700' },
  label: { fontSize: 13, fontWeight: '700', color: colors.ink, marginBottom: 6 },
  input: { backgroundColor: '#fff', borderWidth: 1.5, borderColor: colors.line, borderRadius: 14, paddingHorizontal: 14, paddingVertical: 12, fontSize: 15, color: colors.ink },
  error: { color: colors.danger, fontSize: 12, marginTop: 4 },
  chipRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 14 },
  chip: { paddingHorizontal: 14, paddingVertical: 9, borderRadius: 20, borderWidth: 1.5, borderColor: colors.line, backgroundColor: '#fff' },
  chipText: { color: colors.ink, fontWeight: '600', fontSize: 13 },
  stat: { flex: 1, backgroundColor: colors.card, borderRadius: 18, padding: 14 },
  statIcon: { width: 34, height: 34, borderRadius: 10, alignItems: 'center', justifyContent: 'center', marginBottom: 10 },
  statValue: { fontSize: 24, fontWeight: '800', color: colors.ink },
  statLabel: { fontSize: 12, color: colors.muted, marginTop: 2 },
  section: { fontSize: 17, fontWeight: '800', color: colors.ink, marginTop: 22, marginBottom: 10 },
});
