import React from 'react';
import { ActivityIndicator, StyleSheet, Text, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';

export default function AppSplash() {
  return (
    <LinearGradient colors={['#6C4DF6', '#9B6BFF']} style={styles.container}>
      <View style={styles.logo}><Text style={styles.logoText}>✦</Text></View>
      <Text style={styles.title}>StudyFlow</Text>
      <Text style={styles.subtitle}>Plan smart. Stay in your flow.</Text>
      <ActivityIndicator color="#fff" size="small" style={styles.loading} />
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  logo: { width: 82, height: 82, borderRadius: 28, backgroundColor: '#ffffff30', alignItems: 'center', justifyContent: 'center' },
  logoText: { color: '#fff', fontSize: 44, fontWeight: '800' },
  title: { color: '#fff', fontSize: 32, fontWeight: '900', marginTop: 16 },
  subtitle: { color: '#E3DBFF', fontSize: 14, marginTop: 5 },
  loading: { marginTop: 34 },
});
