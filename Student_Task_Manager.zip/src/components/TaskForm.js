// TaskForm: shared form for Add and Edit; useReducer holds all fields, useRef focuses the title.
import React, { useReducer, useRef, useEffect, useState } from 'react';
import { View, Text, ScrollView, StyleSheet } from 'react-native';
import { Field, ChipRow, Button } from './ui';
import { colors } from '../theme';
import { inDays } from '../utils/smartPlanner';

const emptyTask = { title: '', subject: '', description: '', status: 'Pending', priority: 'Medium', dueDate: '' };

// Reducer: one place that updates any form field or resets the form.
function formReducer(state, action) {
  switch (action.type) {
    case 'SET':
      return { ...state, [action.field]: action.value };
    case 'RESET':
      return { ...emptyTask };
    default:
      return state;
  }
}

export default function TaskForm({ initial, submitLabel, onSubmit, clearAfterSubmit }) {
  const [form, dispatch] = useReducer(formReducer, initial || emptyTask);
  const [errors, setErrors] = useState({});
  const [saving, setSaving] = useState(false);
  const titleRef = useRef(null);

  // useRef: automatically focus the Task Title field when the screen opens.
  useEffect(() => {
    const t = setTimeout(() => titleRef.current && titleRef.current.focus(), 300);
    return () => clearTimeout(t);
  }, []);

  // Update one field in the reducer.
  const set = (field) => (value) => dispatch({ type: 'SET', field, value });

  // Quick due-date buttons (plus the current date when editing an older task).
  const dueOptions = [
    { label: 'None', value: '' },
    { label: 'Today', value: inDays(0) },
    { label: 'Tomorrow', value: inDays(1) },
    { label: 'In 3 days', value: inDays(3) },
    { label: 'Next week', value: inDays(7) },
  ];
  if (form.dueDate && !dueOptions.some((o) => o.value === form.dueDate)) {
    dueOptions.push({ label: form.dueDate, value: form.dueDate });
  }

  // Validate the form, then pass the clean values to the parent to save in Firebase.
  const submit = async () => {
    const next = {};
    if (!form.title.trim()) next.title = 'Please enter a task title';
    if (!form.subject.trim()) next.subject = 'Please enter a subject name';
    setErrors(next);
    if (Object.keys(next).length) return;
    setSaving(true);
    try {
      await onSubmit({ ...form, title: form.title.trim(), subject: form.subject.trim(), description: form.description.trim() });
      if (clearAfterSubmit) {
        dispatch({ type: 'RESET' });
        titleRef.current && titleRef.current.focus();
      }
    } finally {
      setSaving(false);
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.wrap} keyboardShouldPersistTaps="handled">
      <Field ref={titleRef} label="Task Title" placeholder="e.g. Finish Chapter 4 notes" value={form.title} onChangeText={set('title')} error={errors.title} />
      <Field label="Subject Name" placeholder="e.g. Mobile App Development" value={form.subject} onChangeText={set('subject')} error={errors.subject} />
      <Field label="Description" placeholder="Add details (optional)" multiline value={form.description} onChangeText={set('description')} />
      <Text style={styles.label}>Status</Text>
      <ChipRow options={['Pending', 'Completed']} value={form.status} onChange={set('status')} tint={form.status === 'Completed' ? colors.success : colors.warning} />
      <Text style={styles.label}>Priority</Text>
      <ChipRow options={['Low', 'Medium', 'High']} value={form.priority} onChange={set('priority')} />
      <Text style={styles.label}>Deadline</Text>
      <ChipRow options={dueOptions} value={form.dueDate} onChange={set('dueDate')} tint={colors.accent} />
      <Button title={submitLabel} onPress={submit} loading={saving} style={{ marginTop: 6 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  wrap: { padding: 20, paddingBottom: 60 },
  label: { fontSize: 13, fontWeight: '700', color: colors.ink, marginBottom: 6 },
});
