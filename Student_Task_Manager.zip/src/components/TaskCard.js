// TaskCard: one task row; React.memo + stable callbacks (useCallback) stop needless re-renders.
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors, shadow, priorityColor } from '../theme';
import { dueLabel } from '../utils/smartPlanner';
import BubbleTouchable from './BubbleTouchable';

// Color for each due-date tone.
const tone = { danger: colors.danger, warning: colors.warning, muted: colors.muted };

function TaskCard({ task, onToggle, onEdit, onDelete }) {
  const done = task.status === 'Completed';
  const due = dueLabel(task);
  return (
    <View style={[styles.card, shadow]}>
      <BubbleTouchable onPress={() => onToggle(task)} style={styles.check}>
        <Ionicons name={done ? 'checkmark-circle' : 'ellipse-outline'} size={30} color={done ? colors.success : colors.muted} />
      </BubbleTouchable>
      <View style={{ flex: 1 }}>
        <Text style={[styles.title, done && styles.strike]} numberOfLines={1}>{task.title}</Text>
        <Text style={styles.subject}>📚 {task.subject}</Text>
        <View style={styles.meta}>
          <View style={[styles.badge, { backgroundColor: (done ? colors.success : colors.warning) + '22' }]}>
            <Text style={[styles.badgeText, { color: done ? colors.success : colors.warning }]}>{task.status}</Text>
          </View>
          <View style={[styles.dot, { backgroundColor: priorityColor[task.priority] || colors.muted }]} />
          <Text style={styles.small}>{task.priority}</Text>
          <Text style={[styles.small, { color: tone[due.tone], fontWeight: '600' }]}>· {due.text}</Text>
        </View>
      </View>
      <View>
        <BubbleTouchable onPress={() => onEdit(task)} style={styles.icon}>
          <Ionicons name="create-outline" size={21} color={colors.primary} />
        </BubbleTouchable>
        <BubbleTouchable onPress={() => onDelete(task)} style={styles.icon}>
          <Ionicons name="trash-outline" size={21} color={colors.danger} />
        </BubbleTouchable>
      </View>
    </View>
  );
}

export default React.memo(TaskCard);

const styles = StyleSheet.create({
  card: { flexDirection: 'row', alignItems: 'center', backgroundColor: colors.card, borderRadius: 18, padding: 14, marginBottom: 12 },
  check: { marginRight: 12 },
  title: { fontSize: 16, fontWeight: '700', color: colors.ink },
  strike: { textDecorationLine: 'line-through', color: colors.muted },
  subject: { fontSize: 13, color: colors.muted, marginTop: 2 },
  meta: { flexDirection: 'row', alignItems: 'center', marginTop: 6, flexWrap: 'wrap', gap: 6 },
  badge: { paddingHorizontal: 9, paddingVertical: 3, borderRadius: 10 },
  badgeText: { fontSize: 11, fontWeight: '800' },
  dot: { width: 8, height: 8, borderRadius: 4 },
  small: { fontSize: 12, color: colors.muted },
  icon: { padding: 6 },
});
