import React, { forwardRef, useRef } from 'react';
import { Animated, StyleSheet, TouchableOpacity, View } from 'react-native';

const particles = [
  { x: -13, y: -7, size: 6, color: '#FFD4BA' },
  { x: 10, y: -13, size: 5, color: '#D8CEFF' },
  { x: 15, y: 7, size: 4, color: '#BDEEDB' },
  { x: -9, y: 13, size: 5, color: '#FFE7A8' },
];

const BubbleTouchable = forwardRef(function BubbleTouchable({ children, onPressIn, ...props }, ref) {
  const progress = useRef(new Animated.Value(0)).current;

  const animateBubbles = (event) => {
    progress.stopAnimation();
    progress.setValue(0);
    Animated.timing(progress, { toValue: 1, duration: 1000, useNativeDriver: true }).start();
    if (onPressIn) onPressIn(event);
  };

  const fade = progress.interpolate({ inputRange: [0, 0.12, 0.65, 1], outputRange: [0, 0.9, 0.7, 0] });
  const rise = progress.interpolate({ inputRange: [0, 1], outputRange: [0, -24] });
  const scale = progress.interpolate({ inputRange: [0, 0.2, 1], outputRange: [0.35, 1.1, 1.5] });

  return (
    <TouchableOpacity ref={ref} {...props} onPressIn={animateBubbles}>
      {children}
      <View pointerEvents="none" style={StyleSheet.absoluteFill}>
        {particles.map((particle, index) => (
          <Animated.View
            key={index}
            style={[
              styles.bubble,
              {
                width: particle.size,
                height: particle.size,
                borderRadius: particle.size / 2,
                backgroundColor: particle.color,
                opacity: fade,
                left: '50%',
                top: '50%',
                transform: [{ translateX: particle.x }, { translateY: rise }, { scale }],
              },
            ]}
          />
        ))}
      </View>
    </TouchableOpacity>
  );
});

export default BubbleTouchable;

const styles = StyleSheet.create({
  bubble: { position: 'absolute' },
});
