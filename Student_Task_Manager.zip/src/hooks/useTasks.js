// useTasks: all Firestore task operations (Create, Read, Update, Delete) in one reusable hook.
import { useState, useEffect, useMemo, useCallback } from 'react';
import {
  collection, doc, addDoc, updateDoc, deleteDoc, onSnapshot,
} from 'firebase/firestore';
import { db } from '../firebase';

export function useTasks(uid) {
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);

  // READ: listen live to this user's tasks so the list always matches Firebase.
  useEffect(() => {
    if (!uid) return;
    const unsub = onSnapshot(
      collection(db, 'users', uid, 'tasks'),
      (snap) => {
        const list = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
        list.sort((a, b) => {
          const aTime = typeof a.createdAt === 'number' ? a.createdAt : 0;
          const bTime = typeof b.createdAt === 'number' ? b.createdAt : 0;
          return bTime - aTime;
        });
        setTasks(list);
        setLoading(false);
      },
      () => setLoading(false)
    );
    return unsub;
  }, [uid]);

  // CREATE: save a new task in Firestore.
  const addTask = useCallback(
    (data) => {
      const now = Date.now();
      return addDoc(collection(db, 'users', uid, 'tasks'), {
        ...data,
        createdAt: now,
        updatedAt: now,
        completedAt: data.status === 'Completed' ? now : null,
      });
    },
    [uid]
  );

  // UPDATE: change fields of an existing task.
  const updateTask = useCallback(
    (id, data) => {
      const current = tasks.find((task) => task.id === id);
      const nextStatus = data.status || current?.status;
      const now = Date.now();
      const completedAt = nextStatus === 'Completed'
        ? current?.status === 'Completed'
          ? current.completedAt || current.updatedAt || now
          : now
        : null;
      return updateDoc(doc(db, 'users', uid, 'tasks', id), { ...data, completedAt, updatedAt: now });
    },
    [uid, tasks]
  );

  // UPDATE: quickly mark a task as Completed (or back to Pending).
  const toggleDone = useCallback(
    (task) =>
      updateDoc(doc(db, 'users', uid, 'tasks', task.id), {
        status: task.status === 'Completed' ? 'Pending' : 'Completed',
        completedAt: task.status === 'Completed' ? null : Date.now(),
        updatedAt: Date.now(),
      }),
    [uid]
  );

  // DELETE: remove a task from Firestore.
  const deleteTask = useCallback((id) => deleteDoc(doc(db, 'users', uid, 'tasks', id)), [uid]);

  // useMemo: count total / completed / pending only when the task list changes.
  const stats = useMemo(() => {
    const completed = tasks.filter((t) => t.status === 'Completed').length;
    return { total: tasks.length, completed, pending: tasks.length - completed };
  }, [tasks]);

  return { tasks, loading, stats, addTask, updateTask, toggleDone, deleteTask };
}
