// useBackup: create and restore manual Firestore snapshots.
import { useState, useEffect, useCallback } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {
  collection, doc, addDoc, deleteDoc, writeBatch, onSnapshot, getDocs,
} from 'firebase/firestore';
import { db } from '../firebase';

const MAX_BACKUPS = 10; // keep only the newest 10 backups

export function useBackup(uid, tasks) {
  const [backups, setBackups] = useState([]);
  const [busy, setBusy] = useState(false);

  // Listen to the user's saved snapshots, newest first.
  useEffect(() => {
    if (!uid) {
      setBackups([]);
      return;
    }

    setBackups([]);
    let active = true;
    let cachedBackups = [];
    let hasLocalCache = false;
    let unsubscribe;
    const cacheKey = `@studyflow/backups/${uid}`;

    const loadBackups = async () => {
      try {
        const cached = await AsyncStorage.getItem(cacheKey);
        if (cached) {
          const parsed = JSON.parse(cached);
          if (Array.isArray(parsed)) {
            cachedBackups = parsed;
            hasLocalCache = true;
            if (active) setBackups(parsed);
          }
        }
      } catch (error) {
        console.warn('Unable to load cached backups.', error);
      }

      if (!active) return;

      unsubscribe = onSnapshot(
        collection(db, 'users', uid, 'backups'),
        { includeMetadataChanges: true },
        (snap) => {
          const list = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
          list.sort((a, b) => b.createdAt - a.createdAt);

          // An empty in-memory Firestore cache should not hide saved local data while offline.
          if (snap.metadata.fromCache && hasLocalCache && cachedBackups.length && !list.length) return;

          cachedBackups = list;
          hasLocalCache = true;
          setBackups(list);
          AsyncStorage.setItem(cacheKey, JSON.stringify(list)).catch((error) => {
            console.warn('Unable to save cached backups.', error);
          });
        }
      );
    };

    loadBackups();
    return () => {
      active = false;
      unsubscribe && unsubscribe();
    };
  }, [uid]);

  // Save a snapshot of every task in a new backup document, then delete the oldest ones.
  const createBackup = useCallback(
    async (type = 'manual') => {
      setBusy(true);
      try {
        await addDoc(collection(db, 'users', uid, 'backups'), {
          type,
          createdAt: Date.now(),
          taskCount: tasks.length,
          tasks,
        });
        const all = await getDocs(collection(db, 'users', uid, 'backups'));
        const sorted = all.docs.map((d) => ({ id: d.id, at: d.data().createdAt })).sort((a, b) => b.at - a.at);
        await Promise.all(sorted.slice(MAX_BACKUPS).map((b) => deleteDoc(doc(db, 'users', uid, 'backups', b.id))));
      } finally {
        setBusy(false);
      }
    },
    [uid, tasks]
  );

  // RESTORE: write every task of a backup back into Firestore (existing tasks are kept, same ones overwritten).
  const restoreBackup = useCallback(
    async (backup) => {
      setBusy(true);
      try {
        if (!Array.isArray(backup.tasks)) throw new Error('This backup contains no task data.');
        const batch = writeBatch(db);
        backup.tasks.forEach(({ id, ...data }) => batch.set(doc(db, 'users', uid, 'tasks', id), data));
        await batch.commit();
      } finally {
        setBusy(false);
      }
    },
    [uid]
  );

  // DELETE: remove one backup.
  const deleteBackup = useCallback((id) => deleteDoc(doc(db, 'users', uid, 'backups', id)), [uid]);

  return { backups, busy, createBackup, restoreBackup, deleteBackup };
}
