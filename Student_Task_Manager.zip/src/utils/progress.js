function asDate(value) {
  if (!value) return null;
  const date = typeof value.toDate === 'function' ? value.toDate() : new Date(value);
  return Number.isNaN(date.getTime()) ? null : date;
}

function completionDate(task) {
  if (task.status !== 'Completed') return null;
  return asDate(task.completedAt) || asDate(task.updatedAt) || asDate(task.createdAt);
}

export function getCompletionSummary(tasks, today = new Date()) {
  const monthStart = new Date(today.getFullYear(), today.getMonth(), 1);
  const weekStart = new Date(today.getFullYear(), today.getMonth(), today.getDate());
  const dayOfWeek = weekStart.getDay();
  weekStart.setDate(weekStart.getDate() - ((dayOfWeek + 6) % 7));

  const completedTasks = tasks
    .map((task) => ({ task, completedAt: completionDate(task) }))
    .filter(({ completedAt }) => completedAt && completedAt <= today);
  const thisMonth = completedTasks
    .filter(({ completedAt }) => completedAt >= monthStart)
    .sort((a, b) => b.completedAt - a.completedAt);
  const thisWeek = completedTasks.filter(({ completedAt }) => completedAt >= weekStart);

  return {
    monthCount: thisMonth.length,
    weekCount: thisWeek.length,
    monthTasks: thisMonth.map(({ task, completedAt }) => ({ ...task, completedAt })),
  };
}
