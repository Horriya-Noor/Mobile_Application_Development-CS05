// Smart Planner (unique feature 1): ranks tasks by urgency so students know exactly what to study next.

// Return today's date as text like 2026-11-11 (local time).
export const todayKey = () => dateKey(new Date());

// Convert a Date into a YYYY-MM-DD text.
export function dateKey(d) {
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${d.getFullYear()}-${m}-${day}`;
}

// Return the date key for "today + n days" (used by the quick due-date buttons).
export function inDays(n) {
  const d = new Date();
  d.setDate(d.getDate() + n);
  return dateKey(d);
}

// Count how many days from today until the due date (negative = overdue).
export function daysLeft(dueDate) {
  if (!dueDate) return null;
  const [y, m, d] = dueDate.split('-').map(Number);
  const due = new Date(y, m - 1, d);
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  return Math.round((due - today) / 86400000);
}

// Turn a due date into a short human label and a tone for coloring.
export function dueLabel(task) {
  const n = daysLeft(task.dueDate);
  if (n === null) return { text: 'No deadline', tone: 'muted' };
  if (task.status === 'Completed') return { text: task.dueDate, tone: 'muted' };
  if (n < 0) return { text: `Overdue by ${-n}d`, tone: 'danger' };
  if (n === 0) return { text: 'Due today', tone: 'warning' };
  if (n === 1) return { text: 'Due tomorrow', tone: 'warning' };
  return { text: `Due in ${n} days`, tone: 'muted' };
}

// Give a task an urgency score from its priority and deadline (higher = do it sooner).
export function urgencyScore(task) {
  if (task.status === 'Completed') return -1;
  const weight = { High: 3, Medium: 2, Low: 1 }[task.priority] || 2;
  const n = daysLeft(task.dueDate);
  let dueScore = 0;
  if (n !== null) {
    if (n < 0) dueScore = 8;
    else if (n === 0) dueScore = 6;
    else if (n === 1) dueScore = 4;
    else if (n <= 3) dueScore = 3;
    else if (n <= 7) dueScore = 1;
  }
  return weight + dueScore;
}

// Pick the single most urgent pending task (or null when everything is done).
export function pickNextTask(tasks) {
  const pending = tasks.filter((t) => t.status !== 'Completed');
  if (!pending.length) return null;
  return pending.reduce((best, t) => (urgencyScore(t) > urgencyScore(best) ? t : best));
}
