// confirm: asks "are you sure?" on both phone (Alert) and web (window.confirm).
import { Alert, Platform } from 'react-native';

// Show a confirmation box and run onYes only if the user agrees.
export function confirm(title, message, onYes) {
  if (Platform.OS === 'web') {
    if (window.confirm(`${title}\n${message}`)) onYes();
    return;
  }
  Alert.alert(title, message, [
    { text: 'Cancel', style: 'cancel' },
    { text: 'Yes', style: 'destructive', onPress: onYes },
  ]);
}

// Turn a Firestore timestamp or milliseconds into a readable date and time.
export function formatDateTime(value) {
  if (!value) return '—';
  const d = value.toDate ? value.toDate() : new Date(value);
  return d.toLocaleString([], { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
}
