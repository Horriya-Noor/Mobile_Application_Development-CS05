// Firebase setup for the StudyFlow web and native apps.
import { Platform } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { getApp, getApps, initializeApp } from 'firebase/app';
import { getAuth, initializeAuth, getReactNativePersistence } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: 'AIzaSyA7prXpWlMKMmOwNAjVJrRIpoisy7ViGuI',
  authDomain: 'student-task-manager-5cbee.firebaseapp.com',
  projectId: 'student-task-manager-5cbee',
  storageBucket: 'student-task-manager-5cbee.firebasestorage.app',
  messagingSenderId: '1015175495374',
  appId: '1:1015175495374:web:a17fc5a4842a7e7fdbda9f',
  measurementId: 'G-RSCYXE4SB8',
};

const app = getApps().length ? getApp() : initializeApp(firebaseConfig);

const auth = Platform.OS === 'web'
  ? getAuth(app)
  : (() => {
    try {
      return initializeAuth(app, { persistence: getReactNativePersistence(AsyncStorage) });
    } catch (error) {
      if (error?.code !== 'auth/already-initialized') throw error;
      return getAuth(app);
    }
  })();

export { auth };

export const db = getFirestore(app);
