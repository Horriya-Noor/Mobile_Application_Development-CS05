// Auth context: shares the logged-in user and login/signup/logout functions with every screen.
import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { Platform } from 'react-native';
import {
  onAuthStateChanged,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  updateProfile,
  signOut,
} from 'firebase/auth';
import { doc, setDoc, addDoc, collection, serverTimestamp, increment } from 'firebase/firestore';
import { auth, db } from '../firebase';

const AuthContext = createContext(null);

// Saves WHO logged in and WHEN: updates the user profile doc and adds a row to loginHistory.
async function recordLogin(user, name) {
  try {
    await setDoc(
      doc(db, 'users', user.uid),
      {
        uid: user.uid,
        name: name || user.displayName || 'Student',
        email: user.email,
        lastLogin: serverTimestamp(),
        loginCount: increment(1),
      },
      { merge: true }
    );
    await addDoc(collection(db, 'users', user.uid, 'loginHistory'), {
      email: user.email,
      name: name || user.displayName || 'Student',
      loggedInAt: serverTimestamp(),
      device: Platform.OS,
    });
  } catch (error) {
    console.warn('Could not record login history:', error);
  }
}

// Provider wraps the app and keeps track of the current user.
export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  // Listen to Firebase so the user stays logged in after reopening the app.
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (u) => {
      setUser(u);
      setLoading(false);
    });
    return unsub;
  }, []);

  // Log in with email and password, then record the login in Firestore.
  const login = useCallback(async (email, password) => {
    const cred = await signInWithEmailAndPassword(auth, email.trim(), password);
    await recordLogin(cred.user);
  }, []);

  // Create a new account with a display name, then record the first login.
  const signup = useCallback(async (name, email, password) => {
    const cred = await createUserWithEmailAndPassword(auth, email.trim(), password);
    await updateProfile(cred.user, { displayName: name.trim() });
    await setDoc(doc(db, 'users', cred.user.uid), { createdAt: serverTimestamp() }, { merge: true });
    await recordLogin(cred.user, name.trim());
  }, []);

  // Log the user out.
  const logout = useCallback(() => signOut(auth), []);

  return (
    <AuthContext.Provider value={{ user, loading, login, signup, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

// Small helper hook so screens can call useAuth().
export const useAuth = () => useContext(AuthContext);
