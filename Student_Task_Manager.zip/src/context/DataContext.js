// DataContext: loads tasks and backups once and shares them with every screen.
import React, { createContext, useContext } from 'react';
import { useAuth } from './AuthContext';
import { useTasks } from '../hooks/useTasks';
import { useBackup } from '../hooks/useBackup';

const DataContext = createContext(null);

// Provider: runs the hooks for the logged-in user.
export function DataProvider({ children }) {
  const { user } = useAuth();
  const tasksApi = useTasks(user.uid);
  const backupApi = useBackup(user.uid, tasksApi.tasks);

  return <DataContext.Provider value={{ ...tasksApi, ...backupApi }}>{children}</DataContext.Provider>;
}

// Small helper hook so screens can call useData().
export const useData = () => useContext(DataContext);
