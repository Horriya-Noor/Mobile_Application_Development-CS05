// ToastContext: shows a short success/error message on any platform (Alert does not work on web).
import React, { createContext, useContext, useState, useRef, useCallback } from 'react';
import { Animated, Text, StyleSheet } from 'react-native';
import { colors } from '../theme';

const ToastContext = createContext(() => {});

// Provider: renders the toast bubble above the app.
export function ToastProvider({ children }) {
  const [toast, setToast] = useState(null);
  const opacity = useRef(new Animated.Value(0)).current;

  // Show a message for 2.2 seconds with a fade in/out.
  const show = useCallback(
    (text, type = 'success') => {
      setToast({ text, type });
      Animated.sequence([
        Animated.timing(opacity, { toValue: 1, duration: 200, useNativeDriver: true }),
        Animated.delay(2000),
        Animated.timing(opacity, { toValue: 0, duration: 250, useNativeDriver: true }),
      ]).start();
    },
    [opacity]
  );

  return (
    <ToastContext.Provider value={show}>
      {children}
      {toast && (
        <Animated.View
          pointerEvents="none"
          style={[styles.toast, { opacity, backgroundColor: toast.type === 'error' ? colors.danger : colors.ink }]}
        >
          <Text style={styles.text}>{toast.type === 'error' ? '⚠️ ' : '✅ '}{toast.text}</Text>
        </Animated.View>
      )}
    </ToastContext.Provider>
  );
}

// Helper hook: const toast = useToast(); toast('Saved!');
export const useToast = () => useContext(ToastContext);

const styles = StyleSheet.create({
  toast: { position: 'absolute', bottom: 86, left: 20, right: 20, padding: 14, borderRadius: 14, zIndex: 99 },
  text: { color: '#fff', fontWeight: '600', textAlign: 'center' },
});
