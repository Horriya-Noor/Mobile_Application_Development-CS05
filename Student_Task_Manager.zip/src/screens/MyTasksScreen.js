// MyTasksScreen: lists all Firebase tasks with search, filter, complete, edit and delete.
import React, { useState, useMemo, useCallback } from 'react';
import { View, Text, FlatList, TextInput, ActivityIndicator, StyleSheet } from 'react-native';
import { Header, ChipRow } from '../components/ui';
import TaskCard from '../components/TaskCard';
import CompletionCelebration from '../components/CompletionCelebration';
import { useData } from '../context/DataContext';
import { useToast } from '../context/ToastContext';
import { confirm } from '../utils/confirm';
import { urgencyScore } from '../utils/smartPlanner';
import { colors } from '../theme';

export default function MyTasksScreen({ navigation }) {
  const { tasks, loading, toggleDone, deleteTask, stats } = useData();
  const toast = useToast();
  const [filter, setFilter] = useState('All');
  const [query, setQuery] = useState('');
  const [celebrationVisible, setCelebrationVisible] = useState(false);

  // useMemo: filter + search + sort by urgency only when tasks, filter or search text change.
  const visible = useMemo(() => {
    const q = query.trim().toLowerCase();
    return tasks
      .filter((t) => filter === 'All' || t.status === filter)
      .filter((t) => !q || t.title.toLowerCase().includes(q) || t.subject.toLowerCase().includes(q))
      .sort((a, b) => urgencyScore(b) - urgencyScore(a));
  }, [tasks, filter, query]);

  // useCallback: stable function to mark a task Completed/Pending (keeps TaskCard from re-rendering).
  const handleToggle = useCallback(
    async (task) => {
      const completing = task.status !== 'Completed';
      if (completing) setCelebrationVisible(true);
      try {
        await toggleDone(task);
        if (!completing) toast('Moved back to Pending');
      } catch (e) {
        if (completing) setCelebrationVisible(false);
        toast(e.message, 'error');
      }
    },
    [toggleDone, toast]
  );

  // useCallback: open the Edit screen for a task.
  const handleEdit = useCallback((task) => navigation.navigate('EditTask', { task }), [navigation]);

  // useCallback: ask for confirmation, then delete the task from Firebase.
  const handleDelete = useCallback(
    (task) =>
      confirm('Delete task?', `"${task.title}" will be removed permanently.`, async () => {
        try {
          await deleteTask(task.id);
          toast('Task deleted');
        } catch (e) {
          toast(e.message, 'error');
        }
      }),
    [deleteTask, toast]
  );

  return (
    <View style={{ flex: 1, backgroundColor: colors.bg }}>
      <Header subtitle={`${stats.total} total · ${stats.pending} pending`} title="My Tasks">
        <TextInput style={styles.search} placeholder="🔍  Search title or subject" placeholderTextColor="#ffffffAA" value={query} onChangeText={setQuery} />
      </Header>
      <View style={{ paddingHorizontal: 20, paddingTop: 16 }}>
        <ChipRow options={['All', 'Pending', 'Completed']} value={filter} onChange={setFilter} />
      </View>
      {loading ? (
        <ActivityIndicator color={colors.primary} style={{ marginTop: 40 }} />
      ) : (
        <FlatList
          data={visible}
          keyExtractor={(t) => t.id}
          contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 30 }}
          renderItem={({ item }) => <TaskCard task={item} onToggle={handleToggle} onEdit={handleEdit} onDelete={handleDelete} />}
          ListEmptyComponent={<Text style={styles.empty}>No tasks found. Tap Home → Add New Task.</Text>}
        />
      )}
      <CompletionCelebration visible={celebrationVisible} onDismiss={() => setCelebrationVisible(false)} />
    </View>
  );
}

const styles = StyleSheet.create({
  search: { marginTop: 16, backgroundColor: '#ffffff33', borderRadius: 14, paddingHorizontal: 14, paddingVertical: 11, color: '#fff', fontSize: 15 },
  empty: { textAlign: 'center', color: colors.muted, marginTop: 40 },
});
