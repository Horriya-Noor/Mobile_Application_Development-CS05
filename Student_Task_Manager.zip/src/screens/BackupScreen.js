// BackupScreen: manually create, restore, and delete task backups.
import React from 'react';
import { View, Text, ScrollView, StyleSheet } from 'react-native';
import { Header, Button, Section } from '../components/ui';
import { useData } from '../context/DataContext';
import { useToast } from '../context/ToastContext';
import { confirm, formatDateTime } from '../utils/confirm';
import { colors, shadow } from '../theme';

export default function BackupScreen() {
  const { tasks, backups, busy, createBackup, restoreBackup, deleteBackup } = useData();
  const toast = useToast();

  // Create a manual cloud backup of every task.
  const onBackup = async () => {
    try {
      await createBackup('manual');
      toast('Backup saved to Firebase');
    } catch (e) {
      toast(e.message, 'error');
    }
  };

  // Ask first, then restore tasks from the chosen backup.
  const onRestore = (b) =>
    confirm('Restore backup?', `${b.taskCount} tasks from ${formatDateTime(b.createdAt)} will be restored. Your current tasks stay safe.`, async () => {
      try {
        await restoreBackup(b);
        toast('Backup restored');
      } catch (e) {
        toast(e.message, 'error');
      }
    });

  // Ask first, then delete the chosen backup.
  const onDelete = (b) =>
    confirm('Delete backup?', 'This backup will be removed permanently.', async () => {
      try {
        await deleteBackup(b.id);
        toast('Backup deleted');
      } catch (e) {
        toast(e.message, 'error');
      }
    });

  return (
    <View style={{ flex: 1, backgroundColor: colors.bg }}>
      <Header subtitle={`${tasks.length} ${tasks.length === 1 ? 'task' : 'tasks'} protected`} title="Backup & Restore" />
      <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 40 }}>
        <View style={[styles.info, shadow]}>
          <Text style={styles.infoTitle}>🛡 Your tasks are in Firebase</Text>
          <Text style={styles.infoText}>Create a cloud snapshot when you need one.</Text>
        </View>
        <Button title="Create backup" onPress={onBackup} disabled={busy} style={{ marginTop: 16 }} />

        <Section>Saved backups ({backups.length})</Section>
        {backups.length === 0 && <Text style={{ color: colors.muted }}>No backups yet.</Text>}
        {backups.map((b) => (
          <View key={b.id} style={[styles.item, shadow]}>
            <View style={{ flex: 1 }}>
              <Text style={styles.itemTitle}>{formatDateTime(b.createdAt)}</Text>
              <Text style={styles.itemSub}>{b.taskCount} {b.taskCount === 1 ? 'task' : 'tasks'} · {b.type === 'auto' ? 'Automatic' : 'Manual'}</Text>
            </View>
            <Button title="Restore" onPress={() => onRestore(b)} style={{ width: 92 }} disabled={busy} small />
            <Text style={[styles.del, busy && { opacity: 0.4 }]} onPress={() => !busy && onDelete(b)}>🗑</Text>
          </View>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  info: { backgroundColor: '#fff', borderRadius: 18, padding: 16 },
  infoTitle: { fontSize: 16, fontWeight: '800', color: colors.ink },
  infoText: { color: colors.muted, marginTop: 6, lineHeight: 20 },
  item: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#fff', borderRadius: 16, padding: 14, marginBottom: 10 },
  itemTitle: { fontWeight: '700', color: colors.ink },
  itemSub: { color: colors.muted, fontSize: 12, marginTop: 2 },
  del: { fontSize: 22, marginLeft: 12 },
});
