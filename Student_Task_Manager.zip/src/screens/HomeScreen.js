// HomeScreen (Dashboard): daily progress and the Smart Planner's next suggestion.
import React, { useMemo } from 'react';
import { View, Text, ScrollView, Image, StyleSheet } from 'react-native';
import { Header, StatCard, Section, Button } from '../components/ui';
import { useAuth } from '../context/AuthContext';
import { useData } from '../context/DataContext';
import { colors, shadow, priorityColor } from '../theme';
import { pickNextTask, dueLabel, daysLeft } from '../utils/smartPlanner';
import { getCompletionSummary } from '../utils/progress';
import BubbleTouchable from '../components/BubbleTouchable';

export default function HomeScreen({ navigation }) {
  const { user } = useAuth();
  const { tasks, stats } = useData();
  const next = useMemo(() => pickNextTask(tasks), [tasks]);

  const urgentCount = useMemo(
    () => tasks.filter((t) => t.status !== 'Completed' && daysLeft(t.dueDate) !== null && daysLeft(t.dueDate) <= 0).length,
    [tasks]
  );
  const completionSummary = useMemo(() => getCompletionSummary(tasks), [tasks]);
  const monthLabel = new Date().toLocaleDateString(undefined, { month: 'long', year: 'numeric' });

  const percent = stats.total ? Math.round((stats.completed / stats.total) * 100) : 0;
  const firstName = (user.displayName || 'Student').split(' ')[0];

  return (
    <View style={{ flex: 1, backgroundColor: colors.bg }}>
      <Header subtitle="READY FOR A GREAT STUDY DAY?" title={`Hi, ${firstName} ✨`}>
        <View style={styles.progressBox}>
          <View style={styles.row}>
            <Text style={styles.progressText}>Overall progress</Text>
            <Text style={styles.progressText}>{percent}%</Text>
          </View>
          <View style={styles.bar}><View style={[styles.fill, { width: `${percent}%` }]} /></View>
        </View>
      </Header>

      <ScrollView contentContainerStyle={styles.content}>
        <View style={[styles.hero, shadow]}>
          <View style={styles.heroCopy}>
            <Text style={styles.eyebrow}>YOUR STUDY SPACE</Text>
            <Text style={styles.heroTitle}>A little progress adds up.</Text>
            <Text style={styles.heroSub}>Make today count, one task at a time.</Text>
          </View>
          <Image
            source={{ uri: 'https://images.unsplash.com/photo-1434030216411-0b793f4b4173?auto=format&fit=crop&w=480&q=85' }}
            style={styles.heroImage}
            accessibilityLabel="Books and notes on a study desk"
          />
          <View style={styles.sparkle}><Text style={styles.sparkleText}>✦</Text></View>
        </View>

        <View style={styles.row}>
          <StatCard label="Total Tasks" value={stats.total} icon="📋" color={colors.primary} />
          <View style={{ width: 10 }} />
          <StatCard label="Completed" value={stats.completed} icon="✅" color={colors.success} />
          <View style={{ width: 10 }} />
          <StatCard label="Pending" value={stats.pending} icon="⏳" color={colors.warning} />
        </View>

        <View style={[styles.trackingCard, shadow]}>
          <View style={styles.trackingHeader}>
            <View>
              <Text style={styles.trackingTitle}>📈  Your progress</Text>
              <Text style={styles.trackingMonth}>{monthLabel}</Text>
            </View>
            <Text style={styles.trackingMark}>✦</Text>
          </View>
          <View style={styles.progressStats}>
            <View style={[styles.progressStat, styles.monthStat]}>
              <Text style={styles.progressNumber}>{completionSummary.monthCount}</Text>
              <Text style={styles.progressLabel}>completed this month</Text>
            </View>
            <View style={[styles.progressStat, styles.weekStat]}>
              <Text style={[styles.progressNumber, { color: colors.success }]}>{completionSummary.weekCount}</Text>
              <Text style={styles.progressLabel}>completed this week</Text>
            </View>
          </View>
          <Text style={styles.completedHeading}>Recent wins</Text>
          {completionSummary.monthTasks.length ? completionSummary.monthTasks.slice(0, 3).map((task) => (
            <View key={task.id} style={styles.completedTask}>
              <Text style={styles.completedCheck}>✓</Text>
              <Text style={styles.completedTitle} numberOfLines={1}>{task.title}</Text>
              <Text style={styles.completedDate}>{task.completedAt.toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}</Text>
            </View>
          )) : (
            <Text style={styles.noCompleted}>Complete a task to see your progress here.</Text>
          )}
        </View>

        {urgentCount > 0 && (
          <View style={styles.alert}><Text style={styles.alertText}>⚠️ {urgentCount} task{urgentCount > 1 ? 's are' : ' is'} overdue or due today</Text></View>
        )}

        <Section>🎯 Do this next</Section>
        {next ? (
          <View style={[styles.next, shadow]}>
            <View style={styles.row}>
              <View style={[styles.dot, { backgroundColor: priorityColor[next.priority] }]} />
              <Text style={styles.nextTitle} numberOfLines={1}>{next.title}</Text>
            </View>
            <Text style={styles.nextSub}>{next.subject} · {dueLabel(next).text} · {next.priority} priority</Text>
            <Text style={styles.why}>Smart Planner picked this because it has the highest urgency score.</Text>
          </View>
        ) : (
          <View style={[styles.next, shadow]}><Text style={styles.nextTitle}>{stats.total ? '🎉 All tasks completed!' : 'No tasks yet'}</Text><Text style={styles.nextSub}>{stats.total ? 'Great work. Add a new task to keep going.' : 'Add your first study task to begin.'}</Text></View>
        )}

        <Button title="＋  Add New Task" onPress={() => navigation.navigate('AddTask')} style={{ marginTop: 22 }} />
        <BubbleTouchable onPress={() => navigation.navigate('Tasks')} style={{ marginTop: 14 }}>
          <Text style={styles.link}>View all tasks →</Text>
        </BubbleTouchable>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  content: { padding: 20, paddingBottom: 120 },
  row: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  progressBox: { marginTop: 18 },
  progressText: { color: '#fff', fontWeight: '600', fontSize: 13 },
  bar: { height: 10, backgroundColor: '#ffffff40', borderRadius: 6, marginTop: 8, overflow: 'hidden' },
  fill: { height: 10, backgroundColor: '#fff', borderRadius: 6 },
  hero: { minHeight: 150, backgroundColor: '#fff', borderRadius: 22, padding: 18, marginBottom: 16, overflow: 'hidden', flexDirection: 'row', alignItems: 'center' },
  heroCopy: { flex: 1, paddingRight: 8 },
  eyebrow: { color: colors.primary, fontSize: 10, fontWeight: '800', letterSpacing: 1.1 },
  heroTitle: { color: colors.ink, fontSize: 19, lineHeight: 24, fontWeight: '800', marginTop: 8 },
  heroSub: { color: colors.muted, fontSize: 12, lineHeight: 17, marginTop: 6 },
  heroImage: { width: 112, height: 122, borderRadius: 18, backgroundColor: '#E8E3FF' },
  sparkle: { position: 'absolute', top: 10, right: 10, width: 27, height: 27, borderRadius: 14, alignItems: 'center', justifyContent: 'center', backgroundColor: '#FFF1E6' },
  sparkleText: { color: colors.accent, fontSize: 17, fontWeight: '800' },
  trackingCard: { backgroundColor: '#fff', borderRadius: 22, padding: 18, marginTop: 18 },
  trackingHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  trackingTitle: { color: colors.ink, fontSize: 17, fontWeight: '800' },
  trackingMonth: { color: colors.muted, fontSize: 12, marginTop: 3 },
  trackingMark: { color: colors.accent, fontSize: 22 },
  progressStats: { flexDirection: 'row', marginTop: 14 },
  progressStat: { flex: 1, borderRadius: 15, padding: 12 },
  monthStat: { backgroundColor: '#F1EEFF', marginRight: 8 },
  weekStat: { backgroundColor: '#EAF8F2', marginLeft: 8 },
  progressNumber: { color: colors.primary, fontSize: 24, fontWeight: '900' },
  progressLabel: { color: colors.muted, fontSize: 11, marginTop: 3 },
  completedHeading: { color: colors.ink, fontSize: 13, fontWeight: '800', marginTop: 16, marginBottom: 6 },
  completedTask: { flexDirection: 'row', alignItems: 'center', paddingVertical: 7 },
  completedCheck: { width: 22, height: 22, borderRadius: 11, backgroundColor: '#EAF8F2', color: colors.success, textAlign: 'center', lineHeight: 22, fontSize: 13, fontWeight: '900', marginRight: 8 },
  completedTitle: { color: colors.ink, fontSize: 12, fontWeight: '600', flex: 1 },
  completedDate: { color: colors.muted, fontSize: 10, marginLeft: 8 },
  noCompleted: { color: colors.muted, fontSize: 12, paddingVertical: 8 },
  alert: { backgroundColor: '#FFF1E6', borderRadius: 14, padding: 12, marginTop: 14, borderWidth: 1, borderColor: '#FFD3B0' },
  alertText: { color: '#B4541A', fontWeight: '700', fontSize: 13 },
  next: { backgroundColor: '#fff', borderRadius: 20, padding: 18 },
  nextTitle: { fontSize: 18, fontWeight: '800', color: colors.ink, flex: 1 },
  nextSub: { color: colors.muted, marginTop: 6, fontSize: 13 },
  why: { color: colors.primary, marginTop: 8, fontSize: 12, fontStyle: 'italic' },
  dot: { width: 10, height: 10, borderRadius: 5, marginRight: 8 },
  link: { textAlign: 'center', color: colors.primary, fontWeight: '700' },
});
