// AddTaskScreen: form to create a new task and save it to Firestore with a success message.
import React, { useCallback } from 'react';
import { View } from 'react-native';
import TaskForm from '../components/TaskForm';
import { Header } from '../components/ui';
import { useData } from '../context/DataContext';
import { useToast } from '../context/ToastContext';
import { colors } from '../theme';

export default function AddTaskScreen({ navigation }) {
  const { addTask } = useData();
  const toast = useToast();

  // Save the task to Firebase, show a success message, and go back to the dashboard.
  const handleSubmit = useCallback(
    async (values) => {
      try {
        await addTask(values);
        toast('Task saved successfully!');
        navigation.goBack();
      } catch (e) {
        toast('Could not save task: ' + e.message, 'error');
      }
    },
    [addTask, toast, navigation]
  );

  return (
    <View style={{ flex: 1, backgroundColor: colors.bg }}>
      <Header subtitle="New" title="Add Task" />
      <TaskForm submitLabel="Save Task" onSubmit={handleSubmit} />
    </View>
  );
}
