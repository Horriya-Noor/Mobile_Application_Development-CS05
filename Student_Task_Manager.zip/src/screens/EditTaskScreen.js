// EditTaskScreen: loads an existing task into the form and saves the changes back to Firestore.
import React, { useCallback } from 'react';
import { View } from 'react-native';
import TaskForm from '../components/TaskForm';
import { Header } from '../components/ui';
import { useData } from '../context/DataContext';
import { useToast } from '../context/ToastContext';
import { colors } from '../theme';

export default function EditTaskScreen({ route, navigation }) {
  const task = route.params?.task;
  const { updateTask } = useData();
  const toast = useToast();

  React.useEffect(() => {
    if (!task) {
      toast('Task not found.', 'error');
      navigation.replace('Main', { screen: 'Tasks' });
    }
  }, [navigation, task, toast]);

  if (!task) return null;

  // Update the task in Firebase, show a success message, and go back.
  const handleSubmit = useCallback(
    async ({ title, subject, description, status, priority, dueDate }) => {
      try {
        await updateTask(task.id, { title, subject, description, status, priority, dueDate });
        toast('Task updated!');
        navigation.goBack();
      } catch (e) {
        toast('Could not update: ' + e.message, 'error');
      }
    },
    [task.id, updateTask, toast, navigation]
  );

  return (
    <View style={{ flex: 1, backgroundColor: colors.bg }}>
      <Header subtitle="Update" title="Edit Task" />
      <TaskForm initial={{ ...task }} submitLabel="Save Changes" onSubmit={handleSubmit} />
    </View>
  );
}
