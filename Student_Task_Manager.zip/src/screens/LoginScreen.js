// LoginScreen: login and sign-up in one screen; every successful login is recorded in Firestore.
import React, { useState, useRef } from 'react';
import { View, Text, KeyboardAvoidingView, ScrollView, Platform, StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Field, Button } from '../components/ui';
import BubbleTouchable from '../components/BubbleTouchable';
import { useAuth } from '../context/AuthContext';
import { colors, gradient, shadow } from '../theme';

// Convert Firebase error codes into friendly messages.
function friendly(e) {
  const c = e.code || '';
  if (c.includes('invalid-credential') || c.includes('wrong-password') || c.includes('user-not-found')) return 'Wrong email or password.';
  if (c.includes('email-already-in-use')) return 'This email is already registered. Try logging in.';
  if (c.includes('weak-password')) return 'Password must be at least 6 characters.';
  if (c.includes('invalid-email')) return 'Please enter a valid email address.';
  if (c.includes('network')) return 'No internet connection.';
  if (c.includes('api-key') || c.includes('configuration')) return 'Firebase keys are missing. Edit src/firebase.js.';
  return e.message || 'Something went wrong.';
}

export default function LoginScreen() {
  const { login, signup } = useAuth();
  const [mode, setMode] = useState('login');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const emailRef = useRef(null);
  const passRef = useRef(null);

  // Check the inputs, then log in or sign up with Firebase Auth.
  const submit = async () => {
    setError('');
    if (mode === 'signup' && !name.trim()) return setError('Please enter your name.');
    if (!email.trim() || !password) return setError('Please enter email and password.');
    setLoading(true);
    try {
      if (mode === 'login') await login(email, password);
      else await signup(name, email, password);
    } catch (e) {
      setError(friendly(e));
    } finally {
      setLoading(false);
    }
  };

  const isLogin = mode === 'login';
  return (
    <LinearGradient colors={gradient} style={{ flex: 1 }}>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <ScrollView contentContainerStyle={styles.wrap} keyboardShouldPersistTaps="handled">
          <View style={styles.logo}><Text style={{ fontSize: 40 }}>🎓</Text></View>
          <Text style={styles.brand}>StudyFlow</Text>
          <Text style={styles.tag}>Plan smart. Stay on top of every task.</Text>

          <View style={[styles.card, shadow]}>
            <Text style={styles.h}>{isLogin ? 'Welcome back' : 'Create account'}</Text>
            {!isLogin && <Field label="Full Name" placeholder="Your name" value={name} onChangeText={setName} returnKeyType="next" onSubmitEditing={() => emailRef.current?.focus()} />}
            <Field ref={emailRef} label="Email" placeholder="you@email.com" autoCapitalize="none" keyboardType="email-address" value={email} onChangeText={setEmail} returnKeyType="next" onSubmitEditing={() => passRef.current?.focus()} />
            <Field ref={passRef} label="Password" placeholder="At least 6 characters" secureTextEntry value={password} onChangeText={setPassword} onSubmitEditing={submit} />
            {error ? <Text style={styles.error}>{error}</Text> : null}
            <Button title={isLogin ? 'Log In' : 'Sign Up'} onPress={submit} loading={loading} />
            <BubbleTouchable onPress={() => { setMode(isLogin ? 'signup' : 'login'); setError(''); }} style={{ marginTop: 16 }}>
              <Text style={styles.switch}>
                {isLogin ? "New here? " : 'Already have an account? '}
                <Text style={{ color: colors.primary, fontWeight: '800' }}>{isLogin ? 'Create account' : 'Log in'}</Text>
              </Text>
            </BubbleTouchable>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  wrap: { flexGrow: 1, justifyContent: 'center', padding: 24 },
  logo: { alignSelf: 'center', width: 84, height: 84, borderRadius: 28, backgroundColor: '#ffffff33', alignItems: 'center', justifyContent: 'center' },
  brand: { color: '#fff', fontSize: 34, fontWeight: '900', textAlign: 'center', marginTop: 12 },
  tag: { color: '#E3DBFF', textAlign: 'center', marginBottom: 26, marginTop: 4 },
  card: { backgroundColor: '#fff', borderRadius: 24, padding: 22, width: '100%', maxWidth: 460, alignSelf: 'center' },
  h: { fontSize: 22, fontWeight: '800', color: colors.ink, marginBottom: 16 },
  error: { color: colors.danger, marginBottom: 12, fontSize: 13 },
  switch: { textAlign: 'center', color: colors.muted },
});
