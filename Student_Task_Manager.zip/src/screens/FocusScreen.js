// FocusScreen: a customizable study timer that remembers the last selected task.
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { ScrollView, Text, TextInput, View, StyleSheet } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Ionicons } from '@expo/vector-icons';
import { setAudioModeAsync, useAudioPlayer, useAudioPlayerStatus } from 'expo-audio';
import { Header } from '../components/ui';
import BubbleTouchable from '../components/BubbleTouchable';
import { useAuth } from '../context/AuthContext';
import { useData } from '../context/DataContext';
import { useToast } from '../context/ToastContext';
import CompletionCelebration from '../components/CompletionCelebration';
import { colors, priorityColor, shadow } from '../theme';
import { pickNextTask } from '../utils/smartPlanner';

const DEFAULT_SECONDS = 25 * 60;
const focusStorageKey = (uid) => `studyflow:previousFocus:${uid}`;
const soundStorageKey = (uid) => `studyflow:focusSound:${uid}`;

function formatTime(seconds) {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const remainder = seconds % 60;
  return [hours, minutes, remainder].map((value) => String(value).padStart(2, '0')).join(':');
}

function ClockDecoration({ durationSeconds, secondsRemaining, isRunning }) {
  const marks = Array.from({ length: 12 }, (_, index) => {
    const angle = (index * Math.PI) / 6;
    return {
      left: 72 + Math.sin(angle) * 62 - 1,
      top: 72 - Math.cos(angle) * 62 - 4,
      transform: [{ rotate: `${index * 30}deg` }],
    };
  });
  const elapsed = durationSeconds > 0
    ? (durationSeconds - secondsRemaining) / durationSeconds
    : 0;
  const restAngle = isRunning || elapsed > 0 ? elapsed * 360 : 0;
  const hourAngle = restAngle / 12;

  return (
    <View style={styles.clockFace} accessibilityLabel="Decorative analog clock">
      {marks.map((mark, index) => <View key={index} style={[styles.clockMark, mark]} />)}
      <View style={[styles.handPivot, { transform: [{ rotate: `${hourAngle}deg` }] }]}>
        <View style={styles.hourHand} />
      </View>
      <View style={[styles.handPivot, { transform: [{ rotate: `${restAngle}deg` }] }]}>
        <View style={styles.minuteHand} />
      </View>
      <View style={styles.clockCenter} />
      <Text style={[styles.clockNumber, styles.clockTwelve]}>12</Text>
      <Text style={[styles.clockNumber, styles.clockThree]}>3</Text>
      <Text style={[styles.clockNumber, styles.clockSix]}>6</Text>
      <Text style={[styles.clockNumber, styles.clockNine]}>9</Text>
    </View>
  );
}

function DurationField({ label, value, onChangeText, maximum }) {
  return (
    <View style={styles.durationField}>
      <Text style={styles.durationFieldLabel}>{label}</Text>
      <TextInput
        accessibilityLabel={label}
        value={value}
        onChangeText={(text) => onChangeText(text.replace(/\D/g, '').slice(0, 2))}
        keyboardType="number-pad"
        maxLength={2}
        placeholder="00"
        placeholderTextColor={colors.muted}
        style={styles.durationInput}
      />
      <Text style={styles.durationFieldHint}>max {maximum}</Text>
    </View>
  );
}

export default function FocusScreen() {
  const { user } = useAuth();
  const { tasks } = useData();
  const toast = useToast();
  const tickPlayer = useAudioPlayer(require('../../assets/focus-tick.wav'));
  const tockPlayer = useAudioPlayer(require('../../assets/focus-tock.wav'));
  const completionPlayer = useAudioPlayer(require('../../assets/completion-jingle.wav'));
  const tickStatus = useAudioPlayerStatus(tickPlayer);
  const tockStatus = useAudioPlayerStatus(tockPlayer);
  const completionStatus = useAudioPlayerStatus(completionPlayer);
  const tickErrorReported = useRef(false);
  const beatIndex = useRef(0);
  const [lastFocusId, setLastFocusId] = useState(null);
  const [hoursInput, setHoursInput] = useState('0');
  const [minutesInput, setMinutesInput] = useState('25');
  const [secondsInput, setSecondsInput] = useState('0');
  const [durationError, setDurationError] = useState('');
  const [durationSeconds, setDurationSeconds] = useState(DEFAULT_SECONDS);
  const [secondsRemaining, setSecondsRemaining] = useState(DEFAULT_SECONDS);
  const [isRunning, setIsRunning] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [showCompletion, setShowCompletion] = useState(false);

  const pendingTasks = useMemo(() => tasks.filter((task) => task.status !== 'Completed'), [tasks]);
  const previousFocus = useMemo(
    () => pendingTasks.find((task) => task.id === lastFocusId) || null,
    [pendingTasks, lastFocusId]
  );
  const focusTask = previousFocus || pickNextTask(pendingTasks);

  useEffect(() => {
    let active = true;
    Promise.all([
      AsyncStorage.getItem(focusStorageKey(user.uid)),
      AsyncStorage.getItem(soundStorageKey(user.uid)),
    ])
      .then(([taskId, soundSetting]) => {
        if (!active) return;
        setLastFocusId(taskId);
        if (soundSetting !== null) setSoundEnabled(soundSetting !== 'false');
      })
      .catch((error) => {
        if (active) toast(`Couldn't load focus settings: ${error.message}`, 'error');
      });
    return () => {
      active = false;
    };
  }, [toast, user.uid]);

  useEffect(() => {
    setAudioModeAsync({ playsInSilentMode: true }).catch((error) => {
      console.error('Could not enable focus audio:', error);
    });
  }, []);

  const playSound = async (player, volume, isCompletion = false) => {
    try {
      await player.seekTo(0);
      player.volume = volume;
      player.play();
    } catch (error) {
      if (isCompletion) toast(`Couldn't play the focus completion sound: ${error.message}`, 'error');
      if (isCompletion || !tickErrorReported.current) {
        console.error('Could not play a focus sound:', error);
        tickErrorReported.current = true;
      }
    }
  };

  const playTick = () => {
    if (!soundEnabled) return;
    const player = beatIndex.current % 2 === 0 ? tickPlayer : tockPlayer;
    const isLoaded = beatIndex.current % 2 === 0 ? tickStatus.isLoaded : tockStatus.isLoaded;
    beatIndex.current += 1;
    if (isLoaded) playSound(player, 0.12);
  };

  useEffect(() => {
    if (!isRunning || secondsRemaining <= 0) return undefined;
    const timer = setInterval(() => {
      if (secondsRemaining <= 1) {
        setSecondsRemaining(0);
        setIsRunning(false);
        setShowCompletion(true);
        if (completionStatus.isLoaded) playSound(completionPlayer, 0.35, true);
        toast('Focus session complete. Great work!');
      } else {
        playTick();
        setSecondsRemaining((remaining) => remaining - 1);
      }
    }, 1000);
    return () => clearInterval(timer);
  }, [completionPlayer, completionStatus.isLoaded, isRunning, secondsRemaining, soundEnabled, tickPlayer, tickStatus.isLoaded, tockPlayer, tockStatus.isLoaded, toast]);

  const rememberFocus = async (task) => {
    setLastFocusId(task.id);
    try {
      await AsyncStorage.setItem(focusStorageKey(user.uid), task.id);
    } catch (error) {
      toast(`Couldn't save your previous focus: ${error.message}`, 'error');
    }
  };

  const startFocus = async () => {
    if (!focusTask) return;
    await rememberFocus(focusTask);
    if (secondsRemaining === 0) setSecondsRemaining(durationSeconds);
    tickErrorReported.current = false;
    playTick();
    setIsRunning(true);
  };

  const setManualDuration = () => {
    const hours = Number(hoursInput || 0);
    const minutes = Number(minutesInput || 0);
    const seconds = Number(secondsInput || 0);
    if (hours > 23 || minutes > 59 || seconds > 59 || hours + minutes + seconds === 0) {
      setDurationError('Enter a duration between 00:00:01 and 23:59:59.');
      return;
    }
    const totalSeconds = hours * 3600 + minutes * 60 + seconds;
    setDurationError('');
    setDurationSeconds(totalSeconds);
    setSecondsRemaining(totalSeconds);
    beatIndex.current = 0;
    tickErrorReported.current = false;
    setShowCompletion(false);
    playTick();
    setIsRunning(true);
  };

  const resetTimer = () => {
    setIsRunning(false);
    setShowCompletion(false);
    setSecondsRemaining(durationSeconds);
  };

  const toggleSound = async () => {
    const enabled = !soundEnabled;
    setSoundEnabled(enabled);
    try {
      await AsyncStorage.setItem(soundStorageKey(user.uid), String(enabled));
    } catch (error) {
      toast(`Couldn't save the sound setting: ${error.message}`, 'error');
    }
  };

  return (
    <View style={styles.screen}>
      <Header subtitle="MAKE SPACE FOR WHAT MATTERS" title="Focus Mode" />
      <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
        <View style={[styles.timerCard, shadow]}>
          <View style={styles.cardTop}>
            <View>
              <Text style={styles.eyebrow}>✦  YOUR FOCUS SESSION</Text>
              <Text style={styles.cardTitle}>Stay in your zone</Text>
            </View>
            <View style={styles.durationBadge}>
              <Text style={styles.durationBadgeText}>{formatTime(durationSeconds)}</Text>
            </View>
          </View>

          {focusTask ? (
            <View style={styles.taskPanel}>
              <View style={[styles.taskDot, { backgroundColor: priorityColor[focusTask.priority] || colors.primary }]} />
              <View style={styles.taskCopy}>
                <Text style={styles.taskTitle} numberOfLines={1}>{focusTask.title}</Text>
                <Text style={styles.taskSubject} numberOfLines={1}>{focusTask.subject}</Text>
              </View>
            </View>
          ) : (
            <Text style={styles.emptyTask}>Add a study task to start your first focus session.</Text>
          )}

          <Text style={styles.timer}>{formatTime(secondsRemaining)}</Text>
          <Text style={styles.timerCaption}>{isRunning ? 'FOCUS IN PROGRESS' : 'TIME TO FOCUS'}</Text>
          <ClockDecoration
            durationSeconds={durationSeconds}
            secondsRemaining={secondsRemaining}
            isRunning={isRunning}
          />

          <View style={styles.soundRow}>
            <Text style={styles.soundLabel}>Ticking sound</Text>
            <BubbleTouchable
              accessibilityRole="button"
              accessibilityLabel={soundEnabled ? 'Mute ticking sound' : 'Turn on ticking sound'}
              onPress={toggleSound}
              style={[styles.soundToggle, !soundEnabled && styles.soundMuted]}
            >
              <Ionicons name={soundEnabled ? 'volume-high-outline' : 'volume-mute-outline'} size={17} color={soundEnabled ? colors.primary : colors.muted} />
              <Text style={[styles.soundToggleText, !soundEnabled && { color: colors.muted }]}>{soundEnabled ? 'On' : 'Muted'}</Text>
            </BubbleTouchable>
          </View>

          <View style={styles.actions}>
            <BubbleTouchable
              accessibilityRole="button"
              onPress={isRunning ? () => setIsRunning(false) : startFocus}
              disabled={!focusTask}
              style={[styles.startButton, !focusTask && styles.disabled]}
            >
              <Text style={styles.startButtonText}>
                {isRunning ? 'Ⅱ  Pause session' : secondsRemaining < durationSeconds ? '▶  Resume session' : '▶  Start session'}
              </Text>
            </BubbleTouchable>
            <BubbleTouchable accessibilityRole="button" onPress={resetTimer} style={styles.resetButton}>
              <Text style={styles.resetButtonText}>↺</Text>
            </BubbleTouchable>
          </View>

          {previousFocus ? (
            <BubbleTouchable
              accessibilityRole="button"
              disabled={isRunning}
              onPress={startFocus}
              style={[styles.previousButton, isRunning && styles.disabled]}
            >
              <Text style={styles.previousButtonText}>↻  Resume previous focus</Text>
            </BubbleTouchable>
          ) : null}
        </View>

        <View style={[styles.settingsCard, shadow]}>
          <Text style={styles.sectionTitle}>Set your timer</Text>
          <Text style={styles.helperText}>Set hours, minutes, and seconds (up to 23:59:59).</Text>
          <View style={styles.durationInputs}>
            <DurationField label="Hours" value={hoursInput} onChangeText={setHoursInput} maximum="23" />
            <Text style={styles.timeSeparator}>:</Text>
            <DurationField label="Minutes" value={minutesInput} onChangeText={setMinutesInput} maximum="59" />
            <Text style={styles.timeSeparator}>:</Text>
            <DurationField label="Seconds" value={secondsInput} onChangeText={setSecondsInput} maximum="59" />
          </View>
          {durationError ? <Text style={styles.errorText}>{durationError}</Text> : null}
          <BubbleTouchable accessibilityRole="button" onPress={setManualDuration} style={styles.setButton}>
            <Text style={styles.setButtonText}>Set timer</Text>
          </BubbleTouchable>
        </View>

        {pendingTasks.length > 0 ? (
          <View style={[styles.settingsCard, shadow]}>
            <Text style={styles.sectionTitle}>Choose a task</Text>
            <Text style={styles.helperText}>Your last focus is saved so you can pick up where you left off.</Text>
            <View style={styles.taskList}>
              {pendingTasks.map((task) => {
                const selected = task.id === focusTask?.id;
                return (
                  <BubbleTouchable
                    key={task.id}
                    accessibilityRole="button"
                    disabled={isRunning}
                    onPress={() => rememberFocus(task)}
                    style={[styles.taskOption, selected && styles.selectedTaskOption, isRunning && styles.disabled]}
                  >
                    <View style={[styles.taskDot, { backgroundColor: priorityColor[task.priority] || colors.primary }]} />
                    <View style={styles.taskCopy}>
                      <Text style={[styles.taskTitle, selected && styles.selectedTaskTitle]} numberOfLines={1}>{task.title}</Text>
                      <Text style={styles.taskSubject} numberOfLines={1}>{task.subject}</Text>
                    </View>
                    {selected ? <Text style={styles.selectedCheck}>✓</Text> : null}
                  </BubbleTouchable>
                );
              })}
            </View>
          </View>
        ) : null}
      </ScrollView>
      <CompletionCelebration
        visible={showCompletion}
        onDismiss={() => setShowCompletion(false)}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.bg },
  content: { padding: 20, paddingBottom: 120 },
  timerCard: { backgroundColor: '#fff', borderRadius: 24, padding: 20, alignItems: 'center' },
  cardTop: { width: '100%', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 18 },
  eyebrow: { color: colors.primary, fontSize: 10, fontWeight: '800', letterSpacing: 1 },
  cardTitle: { color: colors.ink, fontSize: 19, fontWeight: '800', marginTop: 5 },
  durationBadge: { backgroundColor: '#F1EEFF', paddingHorizontal: 10, paddingVertical: 7, borderRadius: 12 },
  durationBadgeText: { color: colors.primary, fontSize: 11, fontWeight: '800', fontVariant: ['tabular-nums'] },
  taskPanel: { width: '100%', flexDirection: 'row', alignItems: 'center', backgroundColor: '#F8F7FC', borderRadius: 14, padding: 12 },
  taskDot: { width: 9, height: 9, borderRadius: 5, marginRight: 10 },
  taskCopy: { flex: 1 },
  taskTitle: { color: colors.ink, fontSize: 14, fontWeight: '700' },
  taskSubject: { color: colors.muted, fontSize: 11, marginTop: 3 },
  emptyTask: { width: '100%', color: colors.muted, backgroundColor: '#F8F7FC', borderRadius: 14, padding: 14, fontSize: 13 },
  timer: { color: colors.ink, fontSize: 48, fontWeight: '800', letterSpacing: 1, fontVariant: ['tabular-nums'], marginTop: 20 },
  timerCaption: { color: colors.muted, fontSize: 10, letterSpacing: 1.6, fontWeight: '800', marginTop: 2 },
  clockFace: { width: 148, height: 148, borderRadius: 74, borderWidth: 7, borderColor: '#E8E2FF', backgroundColor: '#FAF9FF', marginTop: 19, alignItems: 'center', justifyContent: 'center', shadowColor: colors.primary, shadowOpacity: 0.1, shadowRadius: 12, shadowOffset: { width: 0, height: 5 }, elevation: 3 },
  clockMark: { position: 'absolute', width: 2, height: 8, borderRadius: 1, backgroundColor: '#C8BDFB' },
  handPivot: { position: 'absolute', left: '50%', top: '50%', width: 0, height: 0, zIndex: 1 },
  hourHand: { position: 'absolute', width: 4, height: 28, left: -2, bottom: 0, borderRadius: 2, backgroundColor: colors.primary },
  minuteHand: { position: 'absolute', width: 2, height: 45, left: -1, bottom: 0, borderRadius: 1, backgroundColor: colors.accent },
  clockCenter: { width: 10, height: 10, borderRadius: 5, backgroundColor: colors.ink, zIndex: 2 },
  clockNumber: { position: 'absolute', color: colors.muted, fontSize: 8, fontWeight: '700' },
  clockTwelve: { top: 17 },
  clockThree: { right: 18, top: 68 },
  clockSix: { bottom: 17 },
  clockNine: { left: 18, top: 68 },
  soundRow: { width: '100%', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 17 },
  soundLabel: { color: colors.muted, fontSize: 12, fontWeight: '600' },
  soundToggle: { flexDirection: 'row', alignItems: 'center', borderRadius: 12, backgroundColor: '#F1EEFF', paddingHorizontal: 11, paddingVertical: 7 },
  soundMuted: { backgroundColor: '#F4F2FB' },
  soundToggleText: { color: colors.primary, fontSize: 11, fontWeight: '800', marginLeft: 5 },
  actions: { width: '100%', flexDirection: 'row', marginTop: 12 },
  startButton: { flex: 1, minHeight: 48, borderRadius: 15, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.primary },
  startButtonText: { color: '#fff', fontSize: 14, fontWeight: '800' },
  resetButton: { width: 50, minHeight: 48, marginLeft: 9, borderRadius: 15, alignItems: 'center', justifyContent: 'center', backgroundColor: '#F1EEFF' },
  resetButtonText: { color: colors.primary, fontSize: 23, fontWeight: '700' },
  previousButton: { marginTop: 12, paddingVertical: 5 },
  previousButtonText: { color: colors.primary, fontSize: 12, fontWeight: '700' },
  disabled: { opacity: 0.5 },
  settingsCard: { backgroundColor: '#fff', borderRadius: 20, padding: 18, marginTop: 16 },
  sectionTitle: { color: colors.ink, fontSize: 16, fontWeight: '800' },
  helperText: { color: colors.muted, fontSize: 12, lineHeight: 17, marginTop: 4 },
  durationInputs: { flexDirection: 'row', alignItems: 'flex-end', justifyContent: 'space-between', marginTop: 14 },
  durationField: { flex: 1, alignItems: 'center' },
  durationFieldLabel: { color: colors.muted, fontSize: 11, fontWeight: '700', marginBottom: 6 },
  durationInput: { width: '100%', height: 46, borderWidth: 1.5, borderColor: colors.line, borderRadius: 12, textAlign: 'center', color: colors.ink, fontSize: 17, fontWeight: '700', paddingHorizontal: 4 },
  durationFieldHint: { color: colors.muted, fontSize: 9, marginTop: 4 },
  timeSeparator: { color: colors.primary, fontSize: 22, fontWeight: '700', paddingHorizontal: 7, paddingBottom: 15 },
  setButton: { minHeight: 46, borderRadius: 13, backgroundColor: '#F1EEFF', alignItems: 'center', justifyContent: 'center', marginTop: 14 },
  setButtonText: { color: colors.primary, fontSize: 13, fontWeight: '800' },
  errorText: { color: colors.danger, fontSize: 12, marginTop: 8 },
  taskList: { marginTop: 10 },
  taskOption: { flexDirection: 'row', alignItems: 'center', borderWidth: 1, borderColor: colors.line, borderRadius: 13, padding: 11, marginTop: 8 },
  selectedTaskOption: { borderColor: colors.primary, backgroundColor: '#F9F7FF' },
  selectedTaskTitle: { color: colors.primary },
  selectedCheck: { color: colors.primary, fontSize: 18, fontWeight: '800', marginLeft: 8 },
});
