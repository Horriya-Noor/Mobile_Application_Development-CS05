// ProfileScreen: shows who is logged in, last login time, recent login history from Firebase, and Log Out.
import React, { useEffect, useState } from 'react';
import { View, Text, ScrollView, StyleSheet } from 'react-native';
import { doc, collection, onSnapshot, query, orderBy, limit } from 'firebase/firestore';
import { db } from '../firebase';
import { Header, Button, Section } from '../components/ui';
import { useAuth } from '../context/AuthContext';
import { formatDateTime } from '../utils/confirm';
import { colors, shadow } from '../theme';

export default function ProfileScreen() {
  const { user, logout } = useAuth();
  const [profile, setProfile] = useState(null);
  const [history, setHistory] = useState([]);

  // Read the user document (name, email, last login, login count) live from Firestore.
  useEffect(() => {
    return onSnapshot(doc(db, 'users', user.uid), (s) => setProfile(s.data({ serverTimestamps: 'estimate' })));
  }, [user.uid]);

  // Read the 10 most recent logins from the loginHistory collection.
  useEffect(() => {
    const q = query(collection(db, 'users', user.uid, 'loginHistory'), orderBy('loggedInAt', 'desc'), limit(10));
    return onSnapshot(q, (s) => setHistory(s.docs.map((d) => ({ id: d.id, ...d.data({ serverTimestamps: 'estimate' }) }))));
  }, [user.uid]);

  const name = user.displayName || profile?.name || 'Student';
  return (
    <View style={{ flex: 1, backgroundColor: colors.bg }}>
      <Header subtitle={user.email} title="Profile" />
      <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 40 }}>
        <View style={[styles.card, shadow]}>
          <View style={styles.avatar}><Text style={styles.avatarText}>{name[0].toUpperCase()}</Text></View>
          <Text style={styles.name}>{name}</Text>
          <Text style={styles.sub}>Last login: {formatDateTime(profile?.lastLogin)}</Text>
          <Text style={styles.sub}>Total logins: {profile?.loginCount || 1}</Text>
        </View>

        <Section>Login history</Section>
        {history.map((h) => (
          <View key={h.id} style={[styles.item, shadow]}>
            <Text style={styles.itemTitle}>{formatDateTime(h.loggedInAt)}</Text>
            <Text style={styles.itemSub}>{h.email} · {h.device}</Text>
          </View>
        ))}
        <Button title="Log Out" variant="danger" onPress={logout} style={{ marginTop: 20 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  card: { backgroundColor: '#fff', borderRadius: 22, padding: 22, alignItems: 'center' },
  avatar: { width: 72, height: 72, borderRadius: 36, backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center' },
  avatarText: { color: '#fff', fontSize: 30, fontWeight: '800' },
  name: { fontSize: 20, fontWeight: '800', color: colors.ink, marginTop: 10 },
  sub: { color: colors.muted, marginTop: 4 },
  item: { backgroundColor: '#fff', borderRadius: 14, padding: 14, marginBottom: 8 },
  itemTitle: { fontWeight: '700', color: colors.ink },
  itemSub: { color: colors.muted, fontSize: 12, marginTop: 2 },
});
