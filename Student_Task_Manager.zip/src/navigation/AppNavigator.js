// AppNavigator: shows Login when logged out, or bottom tabs + Add/Edit screens when logged in.
import React from 'react';
import { Platform, StyleSheet, View } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useAuth } from '../context/AuthContext';
import { DataProvider } from '../context/DataContext';
import AppSplash from '../components/AppSplash';
import BubbleTouchable from '../components/BubbleTouchable';
import LoginScreen from '../screens/LoginScreen';
import HomeScreen from '../screens/HomeScreen';
import FocusScreen from '../screens/FocusScreen';
import MyTasksScreen from '../screens/MyTasksScreen';
import BackupScreen from '../screens/BackupScreen';
import ProfileScreen from '../screens/ProfileScreen';
import AddTaskScreen from '../screens/AddTaskScreen';
import EditTaskScreen from '../screens/EditTaskScreen';
import { colors } from '../theme';

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

const webOrigin = Platform.OS === 'web' && typeof window !== 'undefined'
  ? window.location.origin
  : null;

const linking = {
  prefixes: webOrigin ? [webOrigin] : ['studyflow://'],
  config: {
    screens: {
      Main: {
        screens: {
          Home: '',
          Tasks: 'tasks',
          Focus: 'focus',
          Backup: 'backup',
          Profile: 'profile',
        },
      },
      AddTask: 'tasks/add',
      EditTask: 'tasks/edit',
    },
  },
};

// Icon for each bottom tab.
const icons = { Home: 'home', Tasks: 'list', Focus: 'timer-outline', Backup: 'cloud-upload', Profile: 'person' };

function TabIcon({ name, color, size, focused }) {
  const icon = <Ionicons name={name} size={size} color={focused ? '#fff' : color} />;

  return focused ? (
    <LinearGradient colors={['#6C4DF6', '#9B6BFF']} style={styles.activeIcon}>
      {icon}
    </LinearGradient>
  ) : (
    <View style={styles.inactiveIcon}>{icon}</View>
  );
}

// Floating bottom tab bar with a lifted active icon.
function Tabs() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.muted,
        tabBarStyle: styles.tabBar,
        tabBarItemStyle: styles.tabBarItem,
        tabBarLabelStyle: styles.tabBarLabel,
        tabBarButton: (props) => <BubbleTouchable {...props} />,
        tabBarIcon: ({ color, size, focused }) => (
          <TabIcon name={icons[route.name]} color={color} size={size} focused={focused} />
        ),
      })}
    >
      <Tab.Screen name="Home" component={HomeScreen} />
      <Tab.Screen name="Tasks" component={MyTasksScreen} />
      <Tab.Screen name="Focus" component={FocusScreen} />
      <Tab.Screen name="Backup" component={BackupScreen} />
      <Tab.Screen name="Profile" component={ProfileScreen} />
    </Tab.Navigator>
  );
}

const styles = StyleSheet.create({
  tabBar: {
    position: 'absolute',
    left: 16,
    right: 16,
    bottom: 12,
    height: 76,
    paddingTop: 7,
    paddingBottom: 8,
    paddingHorizontal: 8,
    backgroundColor: '#fff',
    borderTopWidth: 0,
    borderRadius: 28,
    shadowColor: '#34236E',
    shadowOpacity: 0.18,
    shadowRadius: 18,
    shadowOffset: { width: 0, height: 7 },
    elevation: 14,
  },
  tabBarItem: { height: 60 },
  tabBarLabel: { fontSize: 10, fontWeight: '700', marginTop: 1 },
  activeIcon: {
    width: 46,
    height: 46,
    borderRadius: 23,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: -18,
    borderWidth: 4,
    borderColor: '#fff',
    shadowColor: '#6C4DF6',
    shadowOpacity: 0.28,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 4 },
    elevation: 8,
  },
  inactiveIcon: {
    width: 38,
    height: 38,
    alignItems: 'center',
    justifyContent: 'center',
  },
});

export default function AppNavigator() {
  const { user, loading } = useAuth();

  // Wait until Firebase tells us if someone is already logged in.
  if (loading) {
    return <AppSplash />;
  }

  return (
    <NavigationContainer linking={linking}>
      {user ? (
        <DataProvider>
          <Stack.Navigator screenOptions={{ headerShown: false }}>
            <Stack.Screen name="Main" component={Tabs} />
            <Stack.Screen name="AddTask" component={AddTaskScreen} />
            <Stack.Screen name="EditTask" component={EditTaskScreen} />
          </Stack.Navigator>
        </DataProvider>
      ) : (
        <LoginScreen />
      )}
    </NavigationContainer>
  );
}
