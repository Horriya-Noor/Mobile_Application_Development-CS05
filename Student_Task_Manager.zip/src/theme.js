// Design tokens: one place for colors, spacing and shadows so the whole app looks consistent.
export const colors = {
  bg: '#F4F2FB',
  card: '#FFFFFF',
  ink: '#1E1B3A',
  muted: '#7A7899',
  line: '#E6E3F3',
  primary: '#6C4DF6',
  primaryDark: '#4B2FD1',
  accent: '#FF8A5B',
  success: '#22B07D',
  danger: '#E5484D',
  warning: '#F5A524',
};

// Gradient colors used by headers and primary buttons.
export const gradient = ['#6C4DF6', '#9B6BFF'];

// Soft shadow used on cards.
export const shadow = {
  shadowColor: '#2B1F7A',
  shadowOpacity: 0.08,
  shadowRadius: 14,
  shadowOffset: { width: 0, height: 6 },
  elevation: 3,
};

// Colors for each priority level.
export const priorityColor = { High: '#E5484D', Medium: '#F5A524', Low: '#22B07D' };
