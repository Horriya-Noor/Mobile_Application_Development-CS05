# 🎓 StudyFlow – Student Task Manager (React Native + Firebase)

A professional study planner built with **Expo / React Native**, **Firebase Auth** and **Cloud Firestore**.
It covers every requirement of the MAD assignment (4 screens, CRUD, 4 hooks) and adds Login, Backup & Restore, login tracking and two original features.

## 1. Setup (5 minutes)

1. Create a project at <https://console.firebase.google.com> → **Add app → Web (`</>`)** → copy the config.
2. Paste it into `src/firebase.js` (replace the `YOUR_...` values).
3. Firebase Console → **Build → Authentication → Sign-in method → Email/Password → Enable**.
4. Firebase Console → **Build → Firestore Database → Create database**, then open **Rules** and paste the contents of `firestore.rules` → **Publish**.
5. In this folder run:
   ```bash
   npm install
   npx expo start        # scan the QR code with the Expo Go app (or press w for web)
   ```

## 2. Screens

| Screen | File | What it does |
|---|---|---|
| Login / Sign up | `LoginScreen.js` | Email + password login; each login is saved in Firebase |
| Home / Dashboard | `HomeScreen.js` | Total, Completed, Pending, progress bar, streak, **Do this next**, Add button |
| Add Task | `AddTaskScreen.js` | Title, Subject, Description, Status (+ Priority, Deadline); success message |
| My Tasks | `MyTasksScreen.js` | All tasks, search, filter, tick to complete, Edit, Delete, and a spoken music celebration |
| Edit Task | `EditTaskScreen.js` | Update every field and save to Firebase |
| Focus Mode | `FocusScreen.js` | Manually set hours, minutes, and seconds; ticking pocket-watch display; mute control; red end-of-session alert |
| Backup & Restore | `BackupScreen.js` | Manual cloud backups, restore, and PDF export (web print dialog or mobile share sheet) |
| Profile | `ProfileScreen.js` | Last login, login history, log out |

## 3. React Hooks (assignment Part 3)

| Hook | Where | Purpose |
|---|---|---|
| `useRef` | `TaskForm.js` | Auto-focus the Task Title field when Add/Edit opens (also keeps the timer interval in `useFocus.js`) |
| `useReducer` | `TaskForm.js` | Manages title, subject, description, status, priority, deadline in one place |
| `useMemo` | `useTasks.js`, `MyTasksScreen.js`, `HomeScreen.js`, `useFocus.js` | Pending/Completed totals, filtered list, next task, streak – recalculated only when data changes |
| `useCallback` | `useTasks.js`, `AddTaskScreen.js`, `MyTasksScreen.js` | add / update / delete functions with stable references (passed to memoized `TaskCard`) |

`useState`, `useEffect` and `useContext` are used for state, live Firebase listeners and shared data.

## 4. Two unique features (solve daily problems)

1. **🎯 Smart Planner – "What should I study first?"**
   Every task gets an urgency score from its priority and deadline (`utils/smartPlanner.js`). The dashboard shows the single most urgent task, warns about overdue work, and My Tasks is sorted by urgency.
2. **⏱ Focus Mode + Study Streak – "I can't concentrate / stay consistent."**
   Set a focus timer in hours, minutes, and seconds. A ticking pocket watch shows the countdown; when time is up, a red alert sounds and speaks, and retry starts another session. Finished sessions are added to the task and to a daily log in Firebase, which builds a 🔥 day streak.

## 5. Firebase data structure

```
users/{uid}                      name, email, lastLogin, loginCount
users/{uid}/loginHistory/{id}    email, name, loggedInAt, device      ← WHO logged in and WHEN
users/{uid}/tasks/{id}           title, subject, description, status, priority, dueDate, focusMinutes, createdAt, updatedAt
users/{uid}/focusLog/{date}      minutes studied that day
users/{uid}/backups/{id}         type (manual), createdAt, taskCount, tasks[]
```
Open **Firestore Database → Data → users** in the Firebase Console to see every user who logged in and the time of each login.

## 5b. Backup system

- **Manual**: create a cloud snapshot when needed.
- **Restore**: puts all tasks of a chosen backup back (current tasks are never deleted).
- **Export**: create a PDF report (web opens the print dialog; mobile opens the share sheet).
- Only the newest 10 backups are kept.

## 6. Process list (one line each)

| Process | One-line description |
|---|---|
| Sign up | Creates a Firebase account and saves the user profile. |
| Log in | Checks email/password with Firebase Auth and records the login time. |
| Stay logged in | Firebase restores the session when the app is reopened. |
| Create task | Saves a new task document in Firestore. |
| Read tasks | A live listener streams the user's tasks into the app. |
| Update task | Writes edited fields (or the Completed tick) to the same document. |
| Delete task | Asks for confirmation, then removes the document. |
| Dashboard stats | Counts total / completed / pending with `useMemo`. |
| Smart Planner | Scores tasks by priority + deadline to suggest the next task. |
| Focus session | Counts down, then saves the minutes to the task and the daily log. |
| Study streak | Counts consecutive days that have focus minutes. |
| Manual backup | Saves a snapshot when the user presses the button. |
| Restore | Writes the tasks from a snapshot back to Firestore. |
| Export | Creates a PDF copy of all tasks. |
| Log out | Ends the session and returns to the login screen. |

Every function in the source code also has a one-line comment explaining what it does.

## 7. Project structure

```
App.js                     root (auth + toast + navigation)
src/firebase.js            Firebase config
src/theme.js               colors and shadows
src/context/               AuthContext (login + login log), DataContext, ToastContext
src/hooks/                 useTasks, useBackup, useFocus
src/utils/                 smartPlanner, confirm/date helpers
src/components/            ui (Header, Button, Field, ChipRow…), TaskForm, TaskCard
src/screens/               all screens
src/navigation/            AppNavigator
firestore.rules            security rules (each user sees only their data)
```
